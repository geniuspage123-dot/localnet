import { AppState, PermissionsAndroid, Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo-modules-core';

// Native module (Android). It owns the network engine (discovery + receiving), the always-on
// background service, notifications, ringing on the lock screen, encryption and Wi-Fi Direct.
let M = null;
try {
  M = Platform.OS === 'android' ? requireOptionalNativeModule('LocalNetService') : null;
} catch (e) {
  M = null;
}

const safe = (fn, fallback) => {
  try { return M ? fn() : fallback; } catch (e) { return fallback; }
};
const safeAsync = async (fn, fallback) => {
  try { return M ? await fn() : fallback; } catch (e) { return fallback; }
};

export const available = !!M;

/* ---- background service ---- */
export const startService = () => safe(() => M.start('LocalNet Connect', 'Ready for messages and calls on your Wi-Fi'), false);
export const stopService = () => safe(() => M.stop(), false);
export const isRunning = () => !!safe(() => M.isRunning(), false);
export const setCallMode = (on) => safe(() => M.setCallMode(!!on), false);

/* ---- identity and security ---- */
export const setIdentity = (me, session) => safe(() => M.setIdentity(String(me.id), String(me.name), String(me.username), !!session), false);
export const getRoom = () => safe(() => M.getRoom(), '');
export const setRoom = (pin) => safeAsync(() => M.setRoom(String(pin || '')), false);
export const hashPassword = (u, p) => safeAsync(() => M.hashPassword(String(u), String(p)), null);

/* ---- network ---- */
// attach(): install listeners first, then call this; it returns everything received while the app was closed.
export const attach = () => safe(() => M.attach(), []);
export const detach = () => safe(() => M.detach(), false);
export const onLine = (cb) => {
  if (!M) return () => {};
  const sub = M.addListener('onLine', (e) => cb(e.line));
  return () => { try { sub.remove(); } catch (e) {} };
};
export const send = (ip, payload, ackId, timeoutMs) => safeAsync(() => M.send(String(ip), payload, ackId || '', timeoutMs || 6000), false);
export const sendVoice = (ip, header, uri, timeoutMs) => safeAsync(() => M.sendVoice(String(ip), header, String(uri), timeoutMs || 25000), false);
export const setKnownPeers = (ips) => safe(() => M.setKnownPeers(ips), false);
export const localIps = () => safe(() => M.localIps(), []);

/* ---- Wi-Fi Direct: connect phones with NO router and NO hotspot ---- */
export const p2pStart = () => safe(() => M.p2pStart(), false);
export const p2pConnect = (address) => safe(() => M.p2pConnect(String(address)), false);
export const p2pStop = () => safe(() => M.p2pStop(), false);
export const onP2p = (cb) => {
  if (!M) return () => {};
  const sub = M.addListener('onP2p', (e) => { try { cb(JSON.parse(e.data)); } catch (err) {} });
  return () => { try { sub.remove(); } catch (e) {} };
};
export async function ensureP2pPermission() {
  if (Platform.OS !== 'android') return true;
  try {
    const perm = Platform.Version >= 33 ? 'android.permission.NEARBY_WIFI_DEVICES' : PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION;
    const r = await PermissionsAndroid.request(perm);
    return r === PermissionsAndroid.RESULTS.GRANTED;
  } catch (e) { return false; }
}

/* ---- ringing / notifications ---- */
export const ring = (name, peerId) => safe(() => M.showIncomingCall(String(name), String(peerId)), false);
export const cancelRing = () => safe(() => M.cancelIncomingCall(), false);
export const lockScreen = (on) => safe(() => M.setLockScreenMode(!!on), false);
export const dismissMessages = (peerId) => safe(() => M.cancelMessage(String(peerId)), false);

/* ---- reliability settings ---- */
export const batteryExempt = () => !!safe(() => M.isIgnoringBatteryOptimizations(), true);
export const askBatteryExemption = () => safe(() => M.requestIgnoreBatteryOptimizations(), false);
export const fullScreenAllowed = () => !!safe(() => M.canUseFullScreenIntent(), true);
export const openFullScreenSettings = () => safe(() => M.openFullScreenIntentSettings(), false);
export const openAutostartSettings = () => safe(() => M.openAutostartSettings(), false);
export const manufacturer = () => String(safe(() => M.manufacturer(), '') || '').toLowerCase();

// Message / missed-call notification, only when the app is not on screen.
export const notifyMessage = (name, text, peerId) => {
  if (AppState.currentState === 'active') return false;
  return safe(() => M.showMessage(String(name), String(text), String(peerId)), false);
};

export async function ensurePermissions() {
  if (Platform.OS !== 'android') return;
  try {
    if (Platform.Version >= 33) await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS');
    await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
  } catch (e) {
    // ignore
  }
}
