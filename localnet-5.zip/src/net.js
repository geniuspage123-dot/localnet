import * as SQLite from 'expo-sqlite';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { AppState } from 'react-native';
import * as native from './native';

const BEAT_MS = 3000;
const PAGE = 40;
export const ONLINE_MS = 10000;

let me = null;
let contacts = {};
let messages = {};
let unread = {};
let more = {};
let ready = false;
let session = false;
let activePeer = null;
let started = false;
let tickTimer = null;
let unsubLine = null;
let signalHandler = null;
let appHooked = false;
let db = null;
let snapshot = { me: null, contacts: {}, messages: {}, unread: {}, more: {}, ready: false, session: false };
const listeners = new Set();
const onlineMap = {};
const inflight = new Set();
const backoff = new Map();
const staleCalls = new Set();

export const genId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);

/* ---------- state publishing (batched, so low-end phones re-render rarely) ---------- */
let pubTimer = null;
function flush() {
  pubTimer = null;
  snapshot = { me, contacts, messages, unread, more, ready, session };
  listeners.forEach((f) => f());
}
function publish(now) {
  if (now) { clearTimeout(pubTimer); flush(); return; }
  if (pubTimer) return;
  pubTimer = setTimeout(flush, 50);
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snapshot;
export const getContact = (id) => contacts[id];
export const setSignalHandler = (f) => { signalHandler = f; };
export const addLocalMessage = (peerId, msg) => addMessage(peerId, msg);

/* ---------- SQLite storage (fast, only touches what changed) ---------- */
function openDb() {
  db = SQLite.openDatabaseSync('localnet.db');
  db.execSync(
    'PRAGMA journal_mode = WAL;' +
    'CREATE TABLE IF NOT EXISTS messages (id TEXT PRIMARY KEY NOT NULL, peer TEXT NOT NULL, kind TEXT NOT NULL, mine INTEGER NOT NULL, text TEXT, uri TEXT, dur INTEGER, ts INTEGER NOT NULL, status TEXT, read INTEGER NOT NULL DEFAULT 0);' +
    'CREATE INDEX IF NOT EXISTS idx_peer_ts ON messages (peer, ts);' +
    'CREATE TABLE IF NOT EXISTS contacts (id TEXT PRIMARY KEY NOT NULL, name TEXT, username TEXT, ip TEXT, lastSeen INTEGER);'
  );
}

const rowToMsg = (r) => ({
  id: r.id, kind: r.kind, mine: !!r.mine, text: r.text == null ? undefined : r.text,
  uri: r.uri == null ? undefined : r.uri, dur: r.dur == null ? undefined : r.dur,
  ts: r.ts, status: r.status == null ? undefined : r.status, read: !!r.read,
});

function dbInsert(peer, m) {
  if (!db) return true;
  try {
    const r = db.runSync(
      'INSERT OR IGNORE INTO messages (id, peer, kind, mine, text, uri, dur, ts, status, read) VALUES (?,?,?,?,?,?,?,?,?,?)',
      [m.id, peer, m.kind, m.mine ? 1 : 0, m.text == null ? null : m.text, m.uri == null ? null : m.uri, m.dur == null ? null : m.dur, m.ts, m.status == null ? null : m.status, m.read ? 1 : 0]
    );
    return r.changes > 0;
  } catch (e) { return true; }
}
function dbStatus(id, status) { try { db && db.runSync('UPDATE messages SET status = ? WHERE id = ?', [status, id]); } catch (e) {} }
function dbMarkRead(peer) { try { db && db.runSync('UPDATE messages SET read = 1 WHERE peer = ? AND mine = 0 AND read = 0', [peer]); } catch (e) {} }
function dbSaveContact(c) {
  try { db && db.runSync('INSERT OR REPLACE INTO contacts (id, name, username, ip, lastSeen) VALUES (?,?,?,?,?)', [c.id, c.name || '', c.username || '', c.ip || '', c.lastSeen || 0]); } catch (e) {}
}
function dbLoad(peer, limit, beforeTs) {
  if (!db) return [];
  try {
    const rows = beforeTs
      ? db.getAllSync('SELECT * FROM messages WHERE peer = ? AND ts < ? ORDER BY ts DESC LIMIT ?', [peer, beforeTs, limit])
      : db.getAllSync('SELECT * FROM messages WHERE peer = ? ORDER BY ts DESC LIMIT ?', [peer, limit]);
    return rows.reverse().map(rowToMsg);
  } catch (e) { return []; }
}

async function migrateOldStorage() {
  // one-time import of data saved by older versions (AsyncStorage JSON)
  try {
    if (!db) return;
    const done = await AsyncStorage.getItem('ln_sql_migrated');
    if (done) return;
    const c = await AsyncStorage.getItem('ln_contacts');
    const m = await AsyncStorage.getItem('ln_messages');
    const oldC = c ? JSON.parse(c) : {};
    const oldM = m ? JSON.parse(m) : {};
    db.withTransactionSync(() => {
      Object.values(oldC).forEach((x) => dbSaveContact(x));
      Object.keys(oldM).forEach((peer) => (oldM[peer] || []).forEach((x) => dbInsert(peer, x)));
    });
    await AsyncStorage.setItem('ln_sql_migrated', '1');
    await AsyncStorage.removeItem('ln_contacts');
    await AsyncStorage.removeItem('ln_messages');
  } catch (e) {}
}

function loadAll() {
  contacts = {};
  messages = {};
  unread = {};
  more = {};
  if (!db) return;
  try {
    db.getAllSync('SELECT * FROM contacts').forEach((r) => {
      contacts[r.id] = { id: r.id, name: r.name || 'Unknown', username: r.username || '', ip: r.ip || undefined, lastSeen: r.lastSeen || 0 };
      onlineMap[r.id] = false;
    });
    Object.keys(contacts).forEach((id) => {
      const list = dbLoad(id, PAGE);
      messages[id] = list;
      more[id] = list.length >= PAGE;
    });
    db.getAllSync("SELECT peer, COUNT(*) AS n FROM messages WHERE mine = 0 AND read = 0 AND kind != 'call' GROUP BY peer").forEach((r) => { unread[r.peer] = r.n; });
    db.runSync("UPDATE messages SET status = 'failed' WHERE mine = 1 AND status = 'sending'");
  } catch (e) {}
}

export function loadOlder(peerId) {
  const list = messages[peerId] || [];
  if (!list.length) return;
  const older = dbLoad(peerId, PAGE, list[0].ts);
  more = { ...more, [peerId]: older.length >= PAGE };
  const have = new Set(list.map((m) => m.id));
  messages = { ...messages, [peerId]: [...older.filter((m) => !have.has(m.id)), ...list] };
  publish();
}

/* ---------- account ---------- */
const legacyHash = (str) => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0; return String(h); };

export async function init() {
  try {
    openDb();
    await migrateOldStorage();
    const p = await AsyncStorage.getItem('ln_account');
    const ss = await AsyncStorage.getItem('ln_session');
    me = p ? JSON.parse(p) : null;
    session = !!(me && ss === '1');
    loadAll();
  } catch (e) {}
  ready = true;
  if (!appHooked) {
    appHooked = true;
    AppState.addEventListener('change', (st) => { if (st === 'active') markViewed(); });
  }
  if (session) start(); // sets the identity for the native service BEFORE the UI asks it to start
  publish(true);
}

export async function register({ name, username, password }) {
  const n = String(name || '').trim();
  const u = String(username || '').trim().toLowerCase().replace(/\s+/g, '');
  if (!n || !u || !password) return 'Please fill in all fields.';
  if (String(password).length < 4) return 'Password must be at least 4 characters.';
  if (me) return 'An account already exists on this phone. Please log in.';
  const ph2 = await native.hashPassword(u, password);
  me = { id: genId(), name: n, username: u };
  if (ph2) me.ph2 = ph2; else me.ph = legacyHash(u + ':' + password);
  session = true;
  try {
    await AsyncStorage.setItem('ln_account', JSON.stringify(me));
    await AsyncStorage.setItem('ln_session', '1');
  } catch (e) {}
  start();
  publish(true);
  return null;
}

export async function login({ username, password }) {
  const u = String(username || '').trim().toLowerCase();
  if (!me || me.username !== u) return 'Invalid username or password.';
  let ok = false;
  if (me.ph2) {
    ok = (await native.hashPassword(u, password)) === me.ph2;
  } else {
    ok = me.ph === legacyHash(u + ':' + password);
    if (ok) {
      // upgrade the old weak hash to the strong one
      const ph2 = await native.hashPassword(u, password);
      if (ph2) {
        me = { ...me, ph2 };
        delete me.ph;
        try { await AsyncStorage.setItem('ln_account', JSON.stringify(me)); } catch (e) {}
      }
    }
  }
  if (!ok) return 'Invalid username or password.';
  session = true;
  try { await AsyncStorage.setItem('ln_session', '1'); } catch (e) {}
  start();
  publish(true);
  return null;
}

export async function logout() {
  session = false;
  stop();
  try { await AsyncStorage.setItem('ln_session', '0'); } catch (e) {}
  publish(true);
}

export const getRoom = () => native.getRoom();
export const setRoom = (pin) => native.setRoom(pin);

/* ---------- start / stop ---------- */
function pushKnownPeers() {
  native.setKnownPeers(Object.values(contacts).map((c) => c.ip).filter(Boolean));
}

function start() {
  if (started || !me) return;
  started = true;
  native.setIdentity(me, true);
  unsubLine = native.onLine(onLine);
  // everything that arrived while the app was closed (messages, missed calls)
  native.attach().forEach(onLine);
  pushKnownPeers();
  tickTimer = setInterval(tick, BEAT_MS);
}

function stop() {
  clearInterval(tickTimer);
  tickTimer = null;
  try { unsubLine && unsubLine(); } catch (e) {}
  unsubLine = null;
  native.detach();
  if (me) native.setIdentity(me, false);
  started = false;
}

/* ---------- incoming ---------- */
function onLine(line) {
  let d;
  try { d = JSON.parse(line); } catch (e) { return; }
  if (!d || !me) return;
  if (d.t === 'hi') { touchContact(d.id, d.name, d.ip, d.username); return; }
  // Private: only accept anything addressed to this device.
  if (d.to !== me.id || !d.from) return;
  touchContact(d.from, d.fromName, d.ip, d.fromUsername);
  if (d.t === 'msg' && d.id) {
    const isNew = addMessage(d.from, { id: d.id, kind: 'text', mine: false, text: String(d.text || ''), ts: d.ts || Date.now(), read: viewing(d.from) });
    if (isNew) incoming(d.from, String(d.text || ''));
  } else if (d.t === 'voice' && d.id && d.path) {
    const isNew = addMessage(d.from, { id: d.id, kind: 'voice', mine: false, uri: 'file://' + d.path, dur: d.dur || 0, ts: d.ts || Date.now(), read: viewing(d.from) });
    if (isNew) incoming(d.from, '🎤 Voice note');
  } else if (typeof d.t === 'string' && d.t.indexOf('call-') === 0) {
    const age = Date.now() - (d.rx || Date.now());
    if (staleCalls.has(d.callId)) return;
    if (d.t === 'call-offer' && age > 50000) {
      // the call came while the app was closed and has already stopped ringing
      staleCalls.add(d.callId);
      addMessage(d.from, { id: genId(), kind: 'call', mine: false, text: '📞 Missed call', ts: d.rx || Date.now(), read: false, status: 'delivered' });
      return;
    }
    if (signalHandler) { try { signalHandler(d); } catch (e) {} }
  }
}

const viewing = (id) => activePeer === id && AppState.currentState === 'active';

function incoming(peerId, text) {
  const c = contacts[peerId];
  native.notifyMessage(c ? c.name : 'LocalNet', text, peerId);
}

/* ---------- contacts ---------- */
function touchContact(id, name, ip, username) {
  if (!id || (me && id === me.id)) return;
  const now = Date.now();
  const old = contacts[id];
  if (!old) {
    const c = { id, name: name || 'Unknown', username: username || '', ip, lastSeen: now };
    contacts = { ...contacts, [id]: c };
    messages = { ...messages, [id]: messages[id] || [] };
    onlineMap[id] = true;
    dbSaveContact(c);
    pushKnownPeers();
    publish();
    return;
  }
  const wasOffline = now - old.lastSeen > ONLINE_MS;
  const ipChanged = !!ip && old.ip !== ip;
  const changed = ipChanged || (!!name && old.name !== name) || (!!username && old.username !== username);
  if (!changed && !wasOffline) { old.lastSeen = now; return; } // heartbeat: no re-render
  const next = { ...old, name: name || old.name, username: username || old.username, ip: ip || old.ip, lastSeen: now };
  contacts = { ...contacts, [id]: next };
  onlineMap[id] = true;
  if (changed) dbSaveContact(next);
  if (ipChanged) pushKnownPeers();
  publish();
  if (wasOffline || ipChanged) retryFailed(id);
}

function tick() {
  const now = Date.now();
  const flipped = [];
  Object.keys(contacts).forEach((id) => {
    const on = now - contacts[id].lastSeen < ONLINE_MS;
    if (onlineMap[id] !== on) { onlineMap[id] = on; flipped.push(id); }
  });
  if (flipped.length) {
    const next = { ...contacts };
    flipped.forEach((id) => { next[id] = { ...next[id] }; });
    contacts = next;
    publish();
  }
  // gentle automatic retry (with back-off) for messages that failed while the other phone was away
  Object.keys(contacts).forEach((id) => { if (onlineMap[id]) retryFailed(id); });
}

/* ---------- messages ---------- */
function addMessage(peerId, msg) {
  const list = messages[peerId] || [];
  if (list.some((m) => m.id === msg.id)) return false;
  if (!dbInsert(peerId, msg)) return false;
  messages = { ...messages, [peerId]: [...list, msg] };
  if (!msg.mine && !msg.read && msg.kind !== 'call') unread = { ...unread, [peerId]: (unread[peerId] || 0) + 1 };
  publish();
  return true;
}

function setStatus(peerId, msgId, status) {
  dbStatus(msgId, status);
  const list = messages[peerId];
  if (list) messages = { ...messages, [peerId]: list.map((m) => (m.id === msgId ? { ...m, status } : m)) };
  publish();
}

async function deliver(peerId, msg) {
  const c = contacts[peerId];
  if (!c || !c.ip || !me) { setStatus(peerId, msg.id, 'failed'); return; }
  if (inflight.has(msg.id)) return;
  inflight.add(msg.id);
  let ok = false;
  try {
    const base = { id: msg.id, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId, ts: msg.ts };
    if (msg.kind === 'voice') {
      ok = await native.sendVoice(c.ip, JSON.stringify({ ...base, t: 'voice', dur: msg.dur }), msg.uri, 25000);
    } else {
      ok = await native.send(c.ip, JSON.stringify({ ...base, t: 'msg', text: msg.text }), msg.id, 6000);
    }
  } catch (e) { ok = false; }
  inflight.delete(msg.id);
  if (ok) backoff.delete(msg.id);
  else {
    const b = backoff.get(msg.id) || { n: 0, at: 0 };
    b.n += 1;
    b.at = Date.now() + Math.min(60000, 3000 * Math.pow(2, b.n));
    backoff.set(msg.id, b);
  }
  setStatus(peerId, msg.id, ok ? 'delivered' : 'failed');
}

export function sendSignal(peerId, obj, tries) {
  const c = contacts[peerId];
  if (!c || !c.ip || !me) return;
  const payload = JSON.stringify({ ...obj, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId });
  native.send(c.ip, payload, '', 3000).then((ok) => {
    const n = tries || 0;
    if (!ok && n < 2 && obj.t !== 'call-ice') setTimeout(() => sendSignal(peerId, obj, n + 1), 700);
  });
}

export function sendMessage(peerId, text) {
  const t = String(text || '').trim();
  if (!t || !contacts[peerId]) return;
  const msg = { id: genId(), kind: 'text', mine: true, text: t, ts: Date.now(), status: 'sending' };
  addMessage(peerId, msg);
  deliver(peerId, msg);
}

export async function sendVoice(peerId, uri, dur) {
  if (!contacts[peerId]) return;
  let dest = uri;
  try {
    // keep our own copy: the recorder's cache file can be cleaned up by Android
    dest = FileSystem.documentDirectory + 'vn_' + genId() + '.m4a';
    await FileSystem.copyAsync({ from: uri, to: dest });
  } catch (e) { dest = uri; }
  const msg = { id: genId(), kind: 'voice', mine: true, uri: dest, dur, ts: Date.now(), status: 'sending' };
  addMessage(peerId, msg);
  deliver(peerId, msg);
}

export function retry(peerId, msgId) {
  const m = (messages[peerId] || []).find((x) => x.id === msgId);
  if (!m || m.kind === 'call' || m.status === 'sending' || m.status === 'delivered') return;
  backoff.delete(msgId);
  setStatus(peerId, msgId, 'sending');
  deliver(peerId, m);
}

function retryFailed(peerId) {
  if (!db) return;
  try {
    const now = Date.now();
    db.getAllSync("SELECT * FROM messages WHERE peer = ? AND mine = 1 AND status = 'failed' AND kind != 'call' ORDER BY ts LIMIT 20", [peerId]).forEach((r) => {
      const b = backoff.get(r.id);
      if (b && b.at > now) return;
      if (inflight.has(r.id)) return;
      const m = rowToMsg(r);
      setStatus(peerId, m.id, 'sending');
      deliver(peerId, m);
    });
  } catch (e) {}
}

export function setActive(id) {
  activePeer = id;
  markViewed();
}

function markViewed() {
  const id = activePeer;
  if (!id || AppState.currentState !== 'active') return;
  if (!(unread[id] > 0)) { native.dismissMessages(id); return; }
  dbMarkRead(id);
  messages = { ...messages, [id]: (messages[id] || []).map((m) => (m.mine || m.read ? m : { ...m, read: true })) };
  unread = { ...unread, [id]: 0 };
  publish();
  native.dismissMessages(id);
}
