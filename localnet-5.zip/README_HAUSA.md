# LocalNet Connect 2.0 — Abin da aka inganta

## 1. Kira da saƙo suna shiga koda app a rufe (mafi muhimmanci)
- Yanzu **Kotlin service** ne ke sauraro (UDP + TCP) ba JavaScript ba. Idan ka goge app daga Recent apps, service yana nan yana raye.
- Idan kira ya shigo alhali app a rufe: wayar tana ƙara (ringtone + vibration) kuma ana nuna full-screen call notification wanda yake tada app.
- Saƙonni da suka shigo alhali app a rufe ana ajiye su, sannan a loda su idan app ya buɗe.
- Service yana sake tashi bayan an kashe/kunna waya (BootReceiver) da bayan update.
- An gyara bug na microphone foreground type (Android 14+): service ɗin yana amfani da `connectedDevice` kawai, microphone sai lokacin kira.
- Wake lock yana da timeout kuma ana sabunta shi — ba zai zubar da baturi har abada ba.
- A Settings akwai maɓallin **Allow Autostart** (Tecno/Infinix/itel/Xiaomi/Oppo/Vivo...).

## 2. Wi-Fi kaɗai, babu router ko hotspot
- **Wi-Fi Direct**: Settings → "Search nearby phones" a wayoyi biyu → Connect → ɗayan ya karɓi gayyata.
- Discovery yanzu yana amfani da ainihin broadcast address na kowane interface (Wi-Fi, Wi-Fi Direct, hotspot) da kuma unicast zuwa wayoyin da aka sani.

## 3. Sauri a ƙananan Android
- Duk saƙonni a **SQLite** (ba JSON guda ɗaya ba), ana loda 40 na ƙarshe kawai, "Load earlier messages" don tsofaffi.
- Heartbeat ba ya sake zana UI; sai idan wani ya shiga/fita.
- Lissafi masu `memo`, FlatList mai tsari, chat `inverted`.
- An cire `react-native-tcp-socket`, `react-native-udp`, `expo-network` (APK ya ragu).
- R8/minify + shrinkResources + ABI guda biyu (arm64-v8a, armeabi-v7a).
- Voice note ana sarrafa shi a native (ba a JS base64 ba).

## 4. Tsaro
- Komai (saƙo, voice, kira, discovery) **AES-256-GCM** ne, key daga **Room code** (PBKDF2). Wayoyi masu code daban ba sa ganin juna.
  (Idan babu code, ana amfani da default na jama'a — saita code don sirri na gaske.)
- Password hash: PBKDF2 maimakon djb2 (ana haɓaka asusun tsoho idan an shiga).

## 5. Sauran gyare-gyare
- Outbox mai retry da back-off; ana sake aika saƙon da bai tafi ba idan wayar ta dawo.
- Kira: noise suppression / echo cancellation, timeout idan haɗin ya ƙi, missed call idan an kira alhali app a rufe.

---
## Yadda ake build
```
npm install
npx expo install --fix        # yana daidaita versions
npx expo prebuild --clean
npx expo run:android --variant release     # ko: eas build -p android --profile preview
```
**Muhimmi:** wannan ba zai yi aiki a Expo Go ba (native module ne). Ina ba da shawarar gwada a wayoyi 2–3 na gaske:
1. kira alhali app a rufe (swipe daga Recent), allon a kulle;
2. bayan restart na waya;
3. Wi-Fi Direct ba tare da router ba;
4. Android 14/15 da ƙaramar waya (Tecno/itel).
