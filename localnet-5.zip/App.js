import React, { memo, useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList, ScrollView, StyleSheet,
  BackHandler, Platform, StatusBar as RNStatusBar,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Audio } from 'expo-av';
import * as net from './src/net';
import * as call from './src/call';
import * as native from './src/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const C = {
  bg: '#f8f9fb', card: '#ffffff', line: '#e8ebef', primary: '#246bfd', soft: '#edf3ff',
  dangerBg: '#ffe9ea', danger: '#d92d3b', greenBg: '#eaf8f1', green: '#15945d',
  muted: '#7b8593', text: '#17202a', dotOn: '#22b573', dotOff: '#b7c0ca', inputLine: '#dfe4ea',
};
const TOP = Platform.OS === 'android' ? (RNStatusBar.currentHeight || 24) : 44;
const AUTH = ['welcome', 'register', 'login'];

const isOnline = (c) => Date.now() - c.lastSeen < net.ONLINE_MS;
const hhmm = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const mmss = (secs) => Math.floor(secs / 60) + ':' + String(Math.max(0, Math.floor(secs % 60))).padStart(2, '0');
const preview = (m) => (m.kind === 'voice' ? '🎤 Voice note' : m.text);

const REC_OPTS = {
  isMeteringEnabled: false,
  android: { extension: '.m4a', outputFormat: Audio.AndroidOutputFormat.MPEG_4, audioEncoder: Audio.AndroidAudioEncoder.AAC, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  ios: { extension: '.m4a', outputFormat: Audio.IOSOutputFormat.MPEG4AAC, audioQuality: Audio.IOSAudioQuality.LOW, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  web: {},
};

/* ---------- small shared pieces ---------- */
function Avatar({ name, size = 45, radius = 15, font = 18 }) {
  return (
    <View style={{ width: size, height: size, borderRadius: radius, backgroundColor: '#3f7bfd', alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: font }}>{String(name || '?').slice(0, 1).toUpperCase()}</Text>
    </View>
  );
}

function Btn({ title, onPress, kind = 'primary', style, disabled }) {
  const k = {
    primary: [C.primary, '#fff', null], soft: [C.soft, C.primary, null], danger: [C.dangerBg, C.danger, null],
    green: [C.greenBg, C.green, null], outline: ['#fff', '#172033', '#dfe4ec'],
  }[kind];
  return (
    <TouchableOpacity
      disabled={disabled}
      onPress={onPress}
      style={[{ backgroundColor: k[0], borderRadius: 13, paddingVertical: 12, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.6 : 1 }, k[2] && { borderWidth: 1, borderColor: k[2] }, style]}
    >
      <Text style={{ color: k[1], fontWeight: '700', fontSize: 15 }}>{title}</Text>
    </TouchableOpacity>
  );
}

const Card = ({ children, style }) => <View style={[st.card, style]}>{children}</View>;

function Field({ label, ...props }) {
  return (
    <View style={{ marginBottom: 13 }}>
      <Text style={st.label}>{label}</Text>
      <TextInput style={st.input} placeholderTextColor="#a3acb9" autoCapitalize="none" autoCorrect={false} {...props} />
    </View>
  );
}

function TopBar() {
  return (
    <View style={st.top}>
      <Text style={st.brand}>LocalNet Connect</Text>
      <Text style={st.sub}>Private • Local Wi-Fi</Text>
    </View>
  );
}

function Dot({ on }) {
  return <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: on ? C.dotOn : C.dotOff }} />;
}

/* ---------- root ---------- */
export default function App() {
  const s = useSyncExternalStore(net.subscribe, net.getSnapshot);
  const cs = useSyncExternalStore(call.subscribe, call.getSnapshot);
  const [route, setRoute] = useState({ name: 'welcome' });
  const [toastTxt, setToastTxt] = useState('');
  const toastTimer = useRef(null);
  const prevCall = useRef(null);

  const toast = (t) => {
    setToastTxt(t);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastTxt(''), 2200);
  };

  let r = route;
  if (s.session && AUTH.includes(r.name)) r = { name: 'contacts' };
  if (!s.session && !AUTH.includes(r.name)) r = { name: 'welcome' };
  const rRef = useRef(r);
  rRef.current = r;
  const go = useCallback((name, id) => setRoute({ name, id }), []);

  useEffect(() => { call.init(); net.init(); }, []);
  // background service + permissions while signed in
  useEffect(() => {
    if (!s.session) { native.stopService(); return; }
    (async () => {
      await native.ensurePermissions();
      native.startService();
      try {
        const asked = await AsyncStorage.getItem('ln_battery_asked');
        if (!asked && !native.batteryExempt()) {
          await AsyncStorage.setItem('ln_battery_asked', '1');
          native.askBatteryExemption();
        }
      } catch (e) {}
    })();
  }, [s.session]);
  const chatId = r.name === 'chat' ? r.id : null;
  useEffect(() => { net.setActive(chatId); }, [chatId]);
  useEffect(() => {
    if (prevCall.current && !cs.call) toast('Call ended');
    prevCall.current = cs.call;
  }, [cs.call]);
  useEffect(() => {
    const h = BackHandler.addEventListener('hardwareBackPress', () => {
      const cur = rRef.current.name;
      if (cur === 'chat') { setRoute({ name: 'messages' }); return true; }
      if (cur === 'register' || cur === 'login') { setRoute({ name: 'welcome' }); return true; }
      return false;
    });
    return () => h.remove();
  }, []);

  if (!s.ready) return <View style={st.flex} />;

  let body;
  if (r.name === 'welcome') body = <Welcome go={go} />;
  else if (r.name === 'register') body = <Register go={go} />;
  else if (r.name === 'login') body = <Login go={go} />;
  else if (r.name === 'chat' && s.contacts[r.id]) body = <Chat s={s} id={r.id} go={go} toast={toast} />;
  else if (r.name === 'messages') body = <Messages s={s} go={go} />;
  else if (r.name === 'calls') body = <Calls s={s} />;
  else if (r.name === 'settings') body = <Settings s={s} />;
  else body = <Contacts s={s} go={go} />;

  const tab = r.name === 'chat' ? 'messages' : r.name;
  return (
    <View style={st.flex}>
      <StatusBar style="dark" backgroundColor={AUTH.includes(r.name) ? C.bg : '#ffffff'} />
      <View style={st.flex}>{body}</View>
      {s.session && <Nav tab={tab} go={go} />}
      {s.session && cs.call && <CallPanel cs={cs} />}
      {!!toastTxt && <View style={st.toast}><Text style={st.toastTxt}>{toastTxt}</Text></View>}
    </View>
  );
}

function Nav({ tab, go }) {
  const items = [['contacts', '◉', 'Contacts'], ['messages', '◌', 'Messages'], ['calls', '⌕', 'Calls'], ['settings', '⚙', 'Settings']];
  return (
    <View style={st.nav}>
      {items.map(([k, ic, label]) => (
        <TouchableOpacity key={k} style={[st.navItem, tab === k && { backgroundColor: C.soft }]} onPress={() => go(k)}>
          <Text style={[st.navIcon, { color: tab === k ? C.primary : '#8a94a2' }]}>{ic}</Text>
          <Text style={[st.navLbl, { color: tab === k ? C.primary : '#8a94a2' }]}>{label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

/* ---------- auth screens ---------- */
function Welcome({ go }) {
  return (
    <ScrollView style={{ backgroundColor: C.bg }} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24, paddingTop: TOP + 20 }}>
      <View style={{ alignItems: 'center' }}>
        <View style={st.heroIcon}><Text style={{ color: '#fff', fontSize: 38, fontWeight: '900' }}>⌁</Text></View>
        <Text style={st.h1Big}>LocalNet Connect</Text>
        <Text style={[st.mutedTxt, { textAlign: 'center', lineHeight: 24, marginTop: 8 }]}>Private chat and voice calls on the same local Wi-Fi network.</Text>
      </View>
      <Card style={{ padding: 18, marginTop: 22 }}>
        <View style={st.row}>
          <Text style={{ fontSize: 20 }}>📲</Text>
          <View style={st.flex}><Text style={st.bold}>Share the app</Text><Text style={st.smallMuted}>Send this APK to friends with Xender or Bluetooth.</Text></View>
        </View>
        <View style={{ height: 1, backgroundColor: '#eee', marginVertical: 16 }} />
        <View style={st.row}>
          <Text style={{ fontSize: 20 }}>🔒</Text>
          <View style={st.flex}><Text style={st.bold}>No server needed</Text><Text style={st.smallMuted}>Phones on the same Wi-Fi find each other automatically.</Text></View>
        </View>
      </Card>
      <Btn title="Create account" onPress={() => go('register')} style={{ marginTop: 22 }} />
      <Btn title="Log in" kind="outline" onPress={() => go('login')} style={{ marginTop: 14 }} />
      <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 18 }]}>
        Already registered? <Text style={{ fontWeight: '700', color: C.primary }} onPress={() => go('login')}>Sign in here</Text>
      </Text>
    </ScrollView>
  );
}

function ErrorBox({ text }) {
  if (!text) return null;
  return <View style={[st.card, { padding: 12, marginVertical: 15, backgroundColor: '#fff1f2' }]}><Text style={{ color: '#c62838' }}>{text}</Text></View>;
}

function Register({ go }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  return (
    <ScrollView style={{ backgroundColor: C.bg }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 18, paddingTop: TOP + 14 }}>
      <Text style={st.mutedTxt} onPress={() => go('welcome')}>‹ Back</Text>
      <Text style={st.h1}>Create account</Text>
      <Text style={st.mutedTxt}>Your local identity appears to other users on this Wi-Fi.</Text>
      <ErrorBox text={error} />
      <Card style={{ padding: 18, marginTop: 18 }}>
        <Field label="Full name" value={name} onChangeText={setName} maxLength={60} autoCapitalize="words" />
        <Field label="Username" value={username} onChangeText={setUsername} maxLength={30} placeholder="e.g. ahmad" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        <Btn title="Create account" onPress={async () => setError((await net.register({ name, username, password })) || '')} style={{ marginTop: 5 }} />
        <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 15 }]}>
          Already have an account? <Text style={{ fontWeight: '700', color: C.primary }} onPress={() => go('login')}>Log in</Text>
        </Text>
      </Card>
    </ScrollView>
  );
}

function Login({ go }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  return (
    <ScrollView style={{ backgroundColor: C.bg }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 18, paddingTop: TOP + 30 }}>
      <Text style={st.mutedTxt} onPress={() => go('welcome')}>‹ Back</Text>
      <View style={{ alignItems: 'center', marginVertical: 26 }}>
        <View style={{ width: 70, height: 70, borderRadius: 22, backgroundColor: '#3f7bfd', alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontSize: 25, fontWeight: '800' }}>⌁</Text>
        </View>
        <Text style={st.h1}>Welcome back</Text>
        <Text style={st.mutedTxt}>Sign in to your LocalNet account.</Text>
      </View>
      <ErrorBox text={error} />
      <Card style={{ padding: 18 }}>
        <Field label="Username" value={username} onChangeText={setUsername} />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        <Btn title="Sign in" onPress={async () => setError((await net.login({ username, password })) || '')} />
      </Card>
    </ScrollView>
  );
}

/* ---------- main tabs ---------- */
function Header({ title, subtitle, right }) {
  return (
    <View style={[st.row, { justifyContent: 'space-between', marginBottom: 14 }]}>
      <View style={st.flex}>
        <Text style={st.h2}>{title}</Text>
        {!!subtitle && <Text style={st.smallMuted}>{subtitle}</Text>}
      </View>
      {right}
    </View>
  );
}

const sortContacts = (s) => Object.values(s.contacts).sort((a, b) => (isOnline(b) - isOnline(a)) || (b.lastSeen - a.lastSeen));

const listPerf = { initialNumToRender: 12, windowSize: 7, maxToRenderPerBatch: 8, removeClippedSubviews: true };

const ContactRow = memo(function ContactRow({ u, online, go }) {
  return (
    <Card style={{ padding: 13 }}>
      <View style={st.row}>
        <Avatar name={u.name} />
        <View style={st.flex}>
          <Text style={st.bold}>{u.name}</Text>
          <View style={[st.row, { gap: 6 }]}><Dot on={online} /><Text style={st.smallMuted}>{online ? 'Online' : 'Offline'} · {u.username}</Text></View>
        </View>
        <Btn title="Chat" kind="soft" onPress={() => go('chat', u.id)} />
        <Btn title="Call" kind="green" onPress={() => call.startCall(u.id)} />
      </View>
    </Card>
  );
});

function Contacts({ s, go }) {
  const [q, setQ] = useState('');
  const list = useMemo(
    () => sortContacts(s).filter((u) => (u.name + ' ' + u.username).toLowerCase().includes(q.trim().toLowerCase())),
    [s.contacts, q]
  );
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar />
      <FlatList
        {...listPerf}
        data={list}
        keyExtractor={(u) => u.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={
          <View style={{ marginBottom: 4 }}>
            <Header title="Contacts" subtitle="Everyone nearby on this Wi-Fi." right={<Avatar name={s.me.name} />} />
            <TextInput style={st.input} placeholder="Search people…" placeholderTextColor="#a3acb9" value={q} onChangeText={setQ} />
          </View>
        }
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{ fontSize: 42, color: C.muted }}>◎</Text>
            <Text style={st.bold}>No other users yet</Text>
            <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 6 }]}>Open the app on another phone on this same Wi-Fi with the same room code. No router? Use Settings → Wi-Fi Direct.</Text>
          </View>
        }
        renderItem={({ item: u }) => <ContactRow u={u} online={isOnline(u)} go={go} />}
      />
    </View>
  );
}

const ConvRow = memo(function ConvRow({ c, last, unread, go }) {
  return (
    <TouchableOpacity onPress={() => go('chat', c.id)}>
      <Card style={{ padding: 14 }}>
        <View style={st.row}>
          <Avatar name={c.name} />
          <View style={st.flex}>
            <View style={[st.row, { justifyContent: 'space-between' }]}>
              <Text style={st.bold}>{c.name}</Text>
              <Text style={st.smallMuted}>{hhmm(last.ts)}</Text>
            </View>
            <View style={[st.row, { justifyContent: 'space-between' }]}>
              <Text numberOfLines={1} style={[st.smallMuted, st.flex]}>{preview(last)}</Text>
              {unread > 0 && <View style={st.badge}><Text style={st.badgeTxt}>{unread}</Text></View>}
            </View>
          </View>
        </View>
      </Card>
    </TouchableOpacity>
  );
});

function Messages({ s, go }) {
  const convs = useMemo(() => Object.keys(s.messages)
    .filter((id) => s.contacts[id] && (s.messages[id] || []).some((m) => m.kind !== 'call'))
    .map((id) => { const list = s.messages[id].filter((m) => m.kind !== 'call'); return { c: s.contacts[id], last: list[list.length - 1], unread: s.unread[id] || 0 }; })
    .sort((a, b) => b.last.ts - a.last.ts), [s.messages, s.contacts, s.unread]);
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar />
      <FlatList
        {...listPerf}
        data={convs}
        keyExtractor={(x) => x.c.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={<Header title="Messages" subtitle="Your private conversations." />}
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{ fontSize: 42, color: C.muted }}>◌</Text>
            <Text style={st.bold}>No conversations yet</Text>
            <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 6 }]}>Open Contacts and start a private chat.</Text>
          </View>
        }
        renderItem={({ item }) => <ConvRow c={item.c} last={item.last} unread={item.unread} go={go} />}
      />
    </View>
  );
}

const CallRow = memo(function CallRow({ u, online }) {
  return (
    <Card style={{ padding: 13 }}>
      <View style={st.row}>
        <Avatar name={u.name} />
        <View style={st.flex}>
          <Text style={st.bold}>{u.name}</Text>
          <Text style={st.smallMuted}>{online ? '● Online' : '○ Offline'} · {u.username}</Text>
        </View>
        <Btn title="Call" kind="green" onPress={() => call.startCall(u.id)} />
      </View>
    </Card>
  );
});

function Calls({ s }) {
  const list = useMemo(() => sortContacts(s), [s.contacts]);
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar />
      <FlatList
        {...listPerf}
        data={list}
        keyExtractor={(u) => u.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={<Header title="Voice Calls" subtitle="Select one person. Calls stay on the local network." />}
        ListEmptyComponent={<View style={st.empty}><Text style={st.bold}>No contacts available</Text></View>}
        renderItem={({ item: u }) => <CallRow u={u} online={isOnline(u)} />}
      />
    </View>
  );
}

const P2P_TXT = {
  idle: 'Not searching.',
  searching: 'Searching for nearby phones… Open this screen on the other phone too.',
  connecting: 'Connecting… accept the invitation on the other phone.',
  connected: 'Connected ✓ Phones will appear in Contacts in a few seconds.',
  'group-owner': 'Connected ✓ (this phone is the host). Phones will appear in Contacts.',
  off: 'Wi-Fi is off. Turn Wi-Fi on first.',
  nopermission: 'Permission needed. Allow "Nearby devices" (or Location on older Android).',
  unsupported: 'This phone does not support Wi-Fi Direct.',
};
const p2pText = (state) => P2P_TXT[state] || (String(state).indexOf('failed') === 0 ? 'Could not search. Turn Wi-Fi on (and Location on older Android), then try again.' : '');

function Settings({ s }) {
  const [ips, setIps] = useState([]);
  const [bg, setBg] = useState({ on: native.isRunning(), ok: native.batteryExempt(), fs: native.fullScreenAllowed() });
  const refreshBg = () => setBg({ on: native.isRunning(), ok: native.batteryExempt(), fs: native.fullScreenAllowed() });
  const [room, setRoomTxt] = useState(net.getRoom() || '');
  const [roomMsg, setRoomMsg] = useState('');
  const [p2p, setP2p] = useState({ state: 'idle', peers: [] });
  const offP2p = useRef(null);
  useEffect(() => { setIps(native.localIps()); }, []);
  useEffect(() => () => { offP2p.current && offP2p.current(); }, []);

  const saveRoom = async () => {
    await net.setRoom(room);
    setRoomMsg(room.trim() ? 'Room code saved. Only phones with the same code can see you.' : 'Using the open default room (anyone with the app can see you).');
  };
  const startP2p = async () => {
    if (!(await native.ensureP2pPermission())) { setP2p({ state: 'nopermission', peers: [] }); return; }
    offP2p.current && offP2p.current();
    offP2p.current = native.onP2p(setP2p);
    native.p2pStart();
  };
  const peers = (p2p.peers || []).filter((p) => p.status !== 4);

  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }} keyboardShouldPersistTaps="handled">
        <Text style={[st.h2, { marginBottom: 14 }]}>Settings</Text>
        <Card style={{ padding: 16 }}>
          <View style={st.row}>
            <Avatar name={s.me.name} />
            <View><Text style={st.bold}>{s.me.name}</Text><Text style={st.smallMuted}>@{s.me.username}</Text></View>
          </View>
        </Card>

        <Card style={{ padding: 16, marginTop: 12 }}>
          <Text style={st.bold}>🔒 Room code (privacy)</Text>
          <Text style={[st.smallMuted, { marginVertical: 8 }]}>Everything you send is encrypted with this code. Choose a secret code and share it only with the people you want to talk to. Phones with a different code cannot read or even see you.</Text>
          <TextInput style={st.input} placeholder="Room code (leave empty for open room)" placeholderTextColor="#a3acb9" value={room} onChangeText={setRoomTxt} autoCapitalize="none" autoCorrect={false} />
          <Btn title="Save room code" kind="soft" style={{ marginTop: 10 }} onPress={saveRoom} />
          {!!roomMsg && <Text style={[st.smallMuted, { marginTop: 8 }]}>{roomMsg}</Text>}
        </Card>

        <Card style={{ padding: 16, marginTop: 12 }}>
          <Text style={st.bold}>📡 Wi-Fi Direct (no router, no hotspot)</Text>
          <Text style={[st.smallMuted, { marginVertical: 8 }]}>Connect phones straight to each other. Tap Search on both phones, then tap Connect on one of them and accept the invitation on the other.</Text>
          <View style={[st.row, { gap: 8 }]}>
            <Btn title="Search nearby phones" kind="soft" style={st.flex} onPress={startP2p} />
            <Btn title="Stop" kind="outline" onPress={() => native.p2pStop()} />
          </View>
          {!!p2pText(p2p.state) && <Text style={[st.smallMuted, { marginTop: 10 }]}>{p2pText(p2p.state)}</Text>}
          {peers.map((p) => (
            <View key={p.address} style={[st.row, { marginTop: 10, justifyContent: 'space-between' }]}>
              <View style={st.flex}><Text style={st.bold}>{p.name || p.address}</Text><Text style={st.smallMuted}>{p.status === 0 ? 'Connected' : p.status === 1 ? 'Invited' : 'Available'}</Text></View>
              {p.status !== 0 && <Btn title="Connect" kind="green" onPress={() => native.p2pConnect(p.address)} />}
            </View>
          ))}
        </Card>

        <Card style={{ padding: 16, marginTop: 12 }}>
          <Text style={st.bold}>Local network</Text>
          <Text style={[st.smallMuted, { marginVertical: 8 }]}>Your phone's address on the local network:</Text>
          <View style={{ padding: 12, backgroundColor: '#f1f4f8', borderRadius: 12 }}><Text style={{ fontWeight: '700', color: C.text }}>{ips.length ? ips.join('  ·  ') : 'Not connected'}</Text></View>
          <Text style={[st.smallMuted, { marginTop: 8 }]}>No host or server needed. Phones on the same Wi-Fi or hotspot find each other automatically{native.available && bg.on ? ', even when the app is closed.' : ' while the app is open.'}</Text>
        </Card>

        <Card style={{ padding: 16, marginTop: 12 }}>
          <Text style={st.bold}>Always reachable</Text>
          <Text style={[st.smallMuted, { marginVertical: 8 }]}>So calls and messages arrive even when the app is closed: {bg.on ? '✓ background service running' : '✗ background service stopped'}.</Text>
          {native.available && !bg.ok && (
            <Btn title="Allow in background (battery)" kind="soft" style={{ marginTop: 6 }} onPress={() => { native.askBatteryExemption(); setTimeout(refreshBg, 4000); }} />
          )}
          {native.available && !bg.fs && (
            <Btn title="Allow calls on lock screen" kind="soft" style={{ marginTop: 10 }} onPress={() => { native.openFullScreenSettings(); setTimeout(refreshBg, 4000); }} />
          )}
          {native.available && (
            <Btn title="Allow Autostart" kind="soft" style={{ marginTop: 10 }} onPress={() => native.openAutostartSettings()} />
          )}
          <Text style={[st.smallMuted, { marginTop: 10 }]}>Tecno, Infinix, itel, Xiaomi, Oppo, Vivo: also turn on Autostart for this app, and lock it in Recent apps (pull the app card down or tap the lock icon).</Text>
        </Card>
        <Btn title="Sign out" kind="danger" onPress={() => net.logout()} style={{ marginTop: 14 }} />
      </ScrollView>
    </View>
  );
}

/* ---------- voice + chat ---------- */
function VoiceBubble({ uri, dur, mine }) {
  const [playing, setPlaying] = useState(false);
  const snd = useRef(null);
  useEffect(() => () => { snd.current && snd.current.unloadAsync().catch(() => {}); }, []);
  const toggle = async () => {
    try {
      if (snd.current) {
        const t = await snd.current.getStatusAsync();
        if (t.isLoaded && t.isPlaying) { await snd.current.pauseAsync(); setPlaying(false); return; }
        if (t.isLoaded) {
          if (t.positionMillis >= (t.durationMillis || 1) - 50) await snd.current.setPositionAsync(0);
          await snd.current.playAsync();
          setPlaying(true);
          return;
        }
      }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
      const { sound } = await Audio.Sound.createAsync({ uri }, { shouldPlay: true }, (u) => {
        if (u.isLoaded && u.didJustFinish) setPlaying(false);
      });
      snd.current = sound;
      setPlaying(true);
    } catch (e) { setPlaying(false); }
  };
  const fg = mine ? '#fff' : C.primary;
  return (
    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', minWidth: 190 }} onPress={toggle}>
      <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: mine ? '#fff' : C.soft, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: C.primary, fontSize: 13 }}>{playing ? '❚❚' : '▶'}</Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, marginHorizontal: 10, height: 20 }}>
        {[6, 12, 8, 16, 10, 14, 7, 12, 9, 15, 6, 11].map((h, i) => (
          <View key={i} style={{ width: 3, height: h, borderRadius: 2, marginRight: 3, backgroundColor: fg, opacity: 0.75 }} />
        ))}
      </View>
      <Text style={{ fontSize: 12, color: mine ? '#ffffffcc' : C.muted }}>{mmss((dur || 0) / 1000)}</Text>
    </TouchableOpacity>
  );
}

const Bubble = memo(function Bubble({ item, id }) {
  if (item.kind === 'call') return <Text style={st.callNote}>{item.text} · {hhmm(item.ts)}</Text>;
  const failed = item.mine && item.status === 'failed';
  const mark = !item.mine ? '' : item.status === 'delivered' ? ' ✓' : failed ? ' ! tap to retry' : ' …';
  return (
    <TouchableOpacity
      activeOpacity={failed ? 0.6 : 1}
      onPress={() => failed && net.retry(id, item.id)}
      style={[st.bubble, item.mine ? st.mine : st.theirs]}
    >
      {item.kind === 'voice'
        ? <VoiceBubble uri={item.uri} dur={item.dur} mine={item.mine} />
        : <Text style={{ fontSize: 14, lineHeight: 20, color: item.mine ? '#fff' : C.text }}>{item.text}</Text>}
      <Text style={{ fontSize: 9, opacity: 0.65, marginTop: 4, color: item.mine ? '#fff' : C.text }}>{hhmm(item.ts)}{mark}</Text>
    </TouchableOpacity>
  );
});

function Chat({ s, id, go, toast }) {
  const c = s.contacts[id];
  const list = s.messages[id] || [];
  const data = useMemo(() => list.slice().reverse(), [list]);
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [voice, setVoice] = useState(null);
  const recRef = useRef(null);
  const ref = useRef(null);
  const on = isOnline(c);

  useEffect(() => {
    if (!recording) return undefined;
    const t = setInterval(() => setRecSecs((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);
  useEffect(() => () => { if (recRef.current) recRef.current.stopAndUnloadAsync().catch(() => {}); }, []);

  const send = () => {
    if (!text.trim()) return;
    net.sendMessage(id, text);
    setText('');
  };

  const toggleRec = async () => {
    if (recording) {
      const r = recRef.current;
      recRef.current = null;
      setRecording(false);
      if (!r) return;
      try {
        const t = await r.getStatusAsync();
        await r.stopAndUnloadAsync();
        await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
        const uri = r.getURI();
        if (!uri || !(t.durationMillis > 700)) { toast('No audio was recorded. Please try again.'); return; }
        setVoice({ uri, dur: t.durationMillis });
      } catch (e) { toast('Could not finish recording.'); }
      return;
    }
    try {
      const p = await Audio.requestPermissionsAsync();
      if (!p.granted) { toast('Microphone permission is blocked. Allow Microphone in phone settings for this app.'); return; }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const r = new Audio.Recording();
      await r.prepareToRecordAsync(REC_OPTS);
      await r.startAsync();
      recRef.current = r;
      setRecSecs(0);
      setRecording(true);
      toast('Recording… tap ■ to finish and preview');
    } catch (e) { setRecording(false); toast('Could not start microphone.'); }
  };

  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <View style={[st.top, st.row]}>
        <Text style={{ fontSize: 25, color: C.text }} onPress={() => go('messages')}>‹</Text>
        <Avatar name={c.name} size={38} radius={12} font={16} />
        <View>
          <Text style={st.bold}>{c.name}</Text>
          <Text style={st.smallMuted}>@{c.username || 'user'} · {on ? 'online' : 'offline'}</Text>
        </View>
      </View>
      <FlatList
        inverted
        data={data}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: 16, gap: 8 }}
        initialNumToRender={15}
        windowSize={7}
        maxToRenderPerBatch={8}
        removeClippedSubviews
        onEndReachedThreshold={0.4}
        onEndReached={() => { if (s.more[id]) net.loadOlder(id); }}
        ListFooterComponent={s.more[id] ? <Text style={st.callNote} onPress={() => net.loadOlder(id)}>Load earlier messages</Text> : null}
        renderItem={({ item }) => <Bubble item={item} id={id} />}
      />
      {voice ? (
        <View style={st.voicePanel}>
          <Text style={st.bold}>Voice note preview</Text>
          <View style={{ marginVertical: 10 }}><VoiceBubble uri={voice.uri} dur={voice.dur} mine={false} /></View>
          <View style={[st.row, { gap: 8 }]}>
            <Btn title="Cancel" kind="soft" style={st.flex} onPress={() => setVoice(null)} />
            <Btn title="Send voice note" style={st.flex} onPress={() => { net.sendVoice(id, voice.uri, voice.dur); setVoice(null); }} />
          </View>
        </View>
      ) : (
        <View style={st.composer}>
          <TouchableOpacity onPress={toggleRec} style={[st.record, recording && { backgroundColor: C.dangerBg }]}>
            <Text style={{ fontSize: 18, color: recording ? C.danger : C.primary }}>{recording ? '■' : '🎙'}</Text>
          </TouchableOpacity>
          <TextInput
            style={[st.input, { flex: 1 }]}
            placeholder={recording ? 'Recording… ' + mmss(recSecs) : 'Message…'}
            placeholderTextColor={recording ? C.danger : '#a3acb9'}
            value={text}
            onChangeText={setText}
            onSubmitEditing={send}
            editable={!recording}
          />
          <Btn title="Send" onPress={send} />
        </View>
      )}
    </View>
  );
}

/* ---------- call panel ---------- */
function CallPanel({ cs }) {
  const c = cs.call;
  const incoming = c.dir === 'in' && c.status === 'ringing';
  const label = {
    preparing: 'Preparing call…',
    calling: 'Ringing… waiting for answer',
    ringing: 'Incoming call — tap Answer to enable microphone',
    connecting: 'Connecting…',
    connected: 'Connected · ' + mmss((cs.now - c.since) / 1000),
    lost: 'Connection lost — check both phones are on the same Wi-Fi',
  }[c.status] || '';
  return (
    <View style={st.callDim}>
      <Card style={st.callCard}>
        <Avatar name={c.name} size={80} radius={25} font={28} />
        <Text style={[st.h2, { marginTop: 14 }]}>{c.name}</Text>
        <Text style={[st.mutedTxt, { textAlign: 'center', marginVertical: 10 }]}>{label}</Text>
        {incoming && <Btn title="Answer" kind="green" onPress={call.answer} style={{ marginBottom: 10, alignSelf: 'stretch' }} />}
        {!incoming && (c.status === 'connected' || c.status === 'connecting' || c.status === 'lost') && (
          <View style={[st.row, { gap: 10, marginBottom: 10 }]}>
            <Btn title={c.muted ? 'Unmute' : 'Mute'} kind="soft" onPress={call.toggleMute} />
            <Btn title={c.speaker ? 'Earpiece' : 'Speaker'} kind="soft" onPress={call.toggleSpeaker} />
          </View>
        )}
        <Btn title="End call" kind="danger" onPress={call.hangup} style={{ alignSelf: 'stretch' }} />
      </Card>
    </View>
  );
}

/* ---------- styles ---------- */
const st = StyleSheet.create({
  flex: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 20, elevation: 2, shadowColor: '#1c2733', shadowOpacity: 0.07, shadowRadius: 12, shadowOffset: { width: 0, height: 6 } },
  top: { paddingTop: TOP + 12, paddingBottom: 12, paddingHorizontal: 18, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: C.line },
  brand: { fontWeight: '800', fontSize: 16, color: C.text, letterSpacing: -0.4 },
  sub: { fontSize: 12, color: '#7a8491', marginTop: 3 },
  h1: { fontSize: 28, fontWeight: '800', color: C.text, marginTop: 12, marginBottom: 4, letterSpacing: -0.6 },
  h1Big: { fontSize: 30, fontWeight: '800', color: C.text, marginTop: 20, letterSpacing: -1 },
  h2: { fontSize: 22, fontWeight: '800', color: C.text },
  bold: { fontWeight: '700', fontSize: 15, color: C.text },
  mutedTxt: { color: C.muted, fontSize: 15 },
  smallMuted: { color: C.muted, fontSize: 12 },
  label: { fontSize: 12, fontWeight: '700', color: '#657080', marginBottom: 7, marginLeft: 3 },
  input: { borderWidth: 1, borderColor: C.inputLine, backgroundColor: '#fff', borderRadius: 13, paddingVertical: 12, paddingHorizontal: 14, fontSize: 15, color: C.text },
  heroIcon: { width: 88, height: 88, borderRadius: 27, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', elevation: 8, shadowColor: C.primary, shadowOpacity: 0.3, shadowRadius: 18 },
  empty: { alignItems: 'center', paddingVertical: 55, paddingHorizontal: 20 },
  badge: { backgroundColor: C.primary, minWidth: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, marginLeft: 8 },
  badgeTxt: { color: '#fff', fontSize: 11, fontWeight: '700' },
  nav: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e7eaee', paddingHorizontal: 7, paddingTop: 8, paddingBottom: 12 },
  navItem: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: 7, borderRadius: 12 },
  navIcon: { fontSize: 20, lineHeight: 22 },
  navLbl: { fontSize: 10, fontWeight: '700' },
  bubble: { maxWidth: '82%', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 16 },
  mine: { alignSelf: 'flex-end', backgroundColor: C.primary, borderBottomRightRadius: 5 },
  theirs: { alignSelf: 'flex-start', backgroundColor: '#fff', borderWidth: 1, borderColor: '#e7eaee', borderBottomLeftRadius: 5 },
  callNote: { alignSelf: 'center', backgroundColor: '#e8ecf2', color: C.muted, fontSize: 12, paddingVertical: 4, paddingHorizontal: 12, borderRadius: 10, overflow: 'hidden' },
  composer: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: C.bg, borderTopWidth: 1, borderTopColor: C.line, paddingVertical: 9, paddingHorizontal: 12 },
  record: { width: 44, height: 44, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' },
  voicePanel: { backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: C.line, padding: 12 },
  callDim: { ...StyleSheet.absoluteFillObject, backgroundColor: '#17202a66', justifyContent: 'flex-end', paddingHorizontal: 12, paddingBottom: 90 },
  callCard: { padding: 25, alignItems: 'center' },
  toast: { position: 'absolute', left: 20, right: 20, bottom: 82, alignItems: 'center' },
  toastTxt: { backgroundColor: C.text, color: '#fff', paddingVertical: 11, paddingHorizontal: 15, borderRadius: 12, fontSize: 12, overflow: 'hidden', textAlign: 'center' },
});
