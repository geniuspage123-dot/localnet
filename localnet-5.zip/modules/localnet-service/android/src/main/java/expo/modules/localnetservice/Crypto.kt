package expo.modules.localnetservice

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Everything that travels over the network (messages, voice notes, call signalling,
 * discovery) is encrypted with AES-256-GCM.
 * The key is derived (PBKDF2) from the "room code". Phones with a different room code
 * can neither read nor even see each other.
 * NOTE: with an empty room code the public default key is used, so set a room code for real privacy.
 */
object Crypto {
  private const val DEFAULT_ROOM = "localnet"
  private val rng = SecureRandom()

  @Volatile private var key: SecretKeySpec? = null
  @Volatile private var app: Context? = null

  fun init(c: Context) {
    app = c.applicationContext
  }

  private fun build(room: String) {
    val pin = if (room.isBlank()) DEFAULT_ROOM else room.trim()
    val spec = PBEKeySpec(pin.toCharArray(), "localnet-room-v2".toByteArray(Charsets.UTF_8), 20000, 256)
    // SHA1 variant on purpose: it exists on every Android version, so all phones derive the same key.
    val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
    key = SecretKeySpec(raw, "AES")
  }

  @Synchronized
  fun setRoom(room: String) {
    build(room)
  }

  private fun k(): SecretKeySpec? {
    key?.let { return it }
    synchronized(this) {
      if (key == null) {
        val c = app ?: return null
        build(Store.room(c))
      }
      return key
    }
  }

  /** Returns "" when no key is available. Output is "E" + base64(iv + ciphertext). */
  fun encrypt(plain: String): String {
    val kk = k() ?: return ""
    return try {
      val iv = ByteArray(12)
      rng.nextBytes(iv)
      val c = Cipher.getInstance("AES/GCM/NoPadding")
      c.init(Cipher.ENCRYPT_MODE, kk, GCMParameterSpec(128, iv))
      val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
      val out = ByteArray(iv.size + ct.size)
      System.arraycopy(iv, 0, out, 0, iv.size)
      System.arraycopy(ct, 0, out, iv.size, ct.size)
      "E" + Base64.encodeToString(out, Base64.NO_WRAP)
    } catch (e: Exception) {
      ""
    }
  }

  /** Returns null when the line is not valid for our room (wrong key, tampered, garbage). */
  fun decrypt(line: String): String? {
    val kk = k() ?: return null
    if (!line.startsWith("E")) return null
    return try {
      val raw = Base64.decode(line.substring(1), Base64.NO_WRAP)
      if (raw.size < 13) return null
      val c = Cipher.getInstance("AES/GCM/NoPadding")
      c.init(Cipher.DECRYPT_MODE, kk, GCMParameterSpec(128, raw, 0, 12))
      String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    } catch (e: Exception) {
      null
    }
  }

  /** Slow, salted password hash (PBKDF2) for the local account. Returns hex. */
  fun hashPassword(username: String, password: String): String {
    val spec = PBEKeySpec(password.toCharArray(), ("ln-user:" + username).toByteArray(Charsets.UTF_8), 30000, 256)
    val raw = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
    val sb = StringBuilder()
    for (b in raw) sb.append(String.format("%02x", b))
    return sb.toString()
  }
}
