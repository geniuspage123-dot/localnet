package expo.modules.localnetservice

import android.Manifest
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * Always-on foreground service. Owns the network engine (discovery + receiving), so messages and calls
 * arrive even when the app screen is closed, swiped away, or the phone was restarted.
 */
class LocalNetService : Service(), Engine.Sink {
  companion object {
    const val ACTION_CALLMODE = "expo.modules.localnetservice.CALLMODE"

    @Volatile var running: Boolean = false
    @Volatile var engine: Engine? = null

    private val seenIds = LinkedHashSet<String>()

    /** true the first time an id is seen (used to avoid duplicate notifications). */
    fun firstSeen(id: String): Boolean {
      if (id.isEmpty()) return true
      synchronized(seenIds) {
        if (!seenIds.add(id)) return false
        if (seenIds.size > 400) {
          val iter = seenIds.iterator()
          iter.next()
          iter.remove()
        }
        return true
      }
    }
  }

  private var wifiLock: WifiManager.WifiLock? = null
  private var multicastLock: WifiManager.MulticastLock? = null
  private var wakeLock: PowerManager.WakeLock? = null
  private val handler = Handler(Looper.getMainLooper())
  private var ringTimeout: Runnable? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    Crypto.init(this)
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    Notif.ensureChannels(this)
    Crypto.init(this)
    val title = intent?.getStringExtra("title") ?: "LocalNet Connect"
    val text = intent?.getStringExtra("text") ?: "Ready for messages and calls on your Wi-Fi"
    val callMode = intent?.action == ACTION_CALLMODE && intent.getBooleanExtra("on", false)
    val n = Notif.serviceNotification(this, title, text)

    // Must call startForeground quickly after startForegroundService(), so do it first.
    if (!enterForeground(n, callMode)) {
      running = false
      stopSelf()
      return START_NOT_STICKY
    }
    if (!Store.session(this)) {
      // signed out: nothing to run
      running = false
      stopForeground(true)
      stopSelf()
      return START_NOT_STICKY
    }
    running = true
    acquireLocks()
    startEngine()
    return START_STICKY
  }

  private fun micGranted(): Boolean =
    ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

  /**
   * The standing service only uses the "connectedDevice" type. The microphone type is added only while a call
   * is active and the user is looking at the app (Android 14+ refuses to start it from the background).
   */
  private fun enterForeground(n: Notification, withMic: Boolean): Boolean {
    return try {
      if (Build.VERSION.SDK_INT >= 29) {
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        if (withMic && Build.VERSION.SDK_INT >= 30 && micGranted()) {
          type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        startForeground(Notif.ID_SERVICE, n, type)
      } else {
        startForeground(Notif.ID_SERVICE, n)
      }
      true
    } catch (e: Exception) {
      if (withMic) enterForeground(n, false) else false
    }
  }

  private fun startEngine() {
    if (engine != null) return
    val e = Engine(this, this)
    e.onBeat = { renewWakeLock() }
    engine = e
    e.start()
  }

  /* ---------------- Engine.Sink ---------------- */

  override fun onPeer(d: JSONObject) {
    engine?.addKnown(d.optString("ip"))
    Bridge.emitIfReady(d.toString())
  }

  override fun onData(d: JSONObject) {
    val delivered = Bridge.dispatchOrQueue(this, d.toString())
    if (!delivered) nativeNotify(d)
  }

  /** The JS app is not running: show notifications / ring ourselves. */
  private fun nativeNotify(d: JSONObject) {
    val t = d.optString("t")
    val from = d.optString("from")
    val name = d.optString("fromName").ifEmpty { "LocalNet" }
    when (t) {
      "msg" -> if (firstSeen(d.optString("id"))) Notif.message(this, name, d.optString("text"), from)
      "voice" -> if (firstSeen(d.optString("id"))) Notif.message(this, name, "\uD83C\uDFA4 Voice note", from)
      "call-offer" -> startNativeRing(d, name, from)
      "call-end" -> stopNativeRing(d.optString("callId"), true)
      "call-reject" -> stopNativeRing(d.optString("callId"), false)
    }
  }

  private fun startNativeRing(d: JSONObject, name: String, from: String) {
    val callId = d.optString("callId")
    if (callId.isEmpty()) return
    if (Ringer.callId == callId) return
    if (Ringer.callId != null) {
      // already ringing for someone else: tell the caller we are busy
      val ip = d.optString("ip")
      val reply = JSONObject()
        .put("t", "call-reject").put("callId", callId).put("busy", true)
        .put("from", Store.id(this)).put("fromName", Store.name(this)).put("fromUsername", Store.username(this))
        .put("to", from).toString()
      Thread { Transport.send(ip, reply, "", 3000) }.start()
      return
    }
    Ringer.callId = callId
    Ringer.peer = from
    Ringer.name = name
    Bridge.lockMode = true
    Ringer.start(this)
    Notif.incomingCall(this, name, from)
    val r = Runnable {
      if (Ringer.callId == callId) {
        val n = Ringer.name
        val p = Ringer.peer
        Ringer.stop(this)
        Bridge.lockMode = false
        Notif.cancel(this, Notif.ID_CALL)
        Notif.message(this, "Missed call", n, p)
      }
    }
    ringTimeout?.let { handler.removeCallbacks(it) }
    ringTimeout = r
    handler.postDelayed(r, 45000)
  }

  private fun stopNativeRing(callId: String, missed: Boolean) {
    if (Ringer.callId == null || Ringer.callId != callId) return
    val n = Ringer.name
    val p = Ringer.peer
    ringTimeout?.let { handler.removeCallbacks(it) }
    Ringer.stop(this)
    Bridge.lockMode = false
    Notif.cancel(this, Notif.ID_CALL)
    if (missed) Notif.message(this, "Missed call", n, p)
  }

  /* ---------------- locks ---------------- */

  @Suppress("DEPRECATION")
  private fun acquireLocks() {
    try {
      val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
      if (wifiLock == null) {
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "localnet:wifi")
        wifiLock?.setReferenceCounted(false)
      }
      if (wifiLock?.isHeld != true) wifiLock?.acquire()
      if (multicastLock == null) {
        multicastLock = wm.createMulticastLock("localnet:multicast")
        multicastLock?.setReferenceCounted(false)
      }
      if (multicastLock?.isHeld != true) multicastLock?.acquire()
      val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
      if (wakeLock == null) {
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "localnet:cpu")
        wakeLock?.setReferenceCounted(false)
      }
      renewWakeLock()
    } catch (e: Exception) {
      // locks are an optimisation only
    }
  }

  /** The CPU lock has a timeout and is renewed every few seconds, so it can never leak if we get killed. */
  private fun renewWakeLock() {
    try { wakeLock?.acquire(10 * 60 * 1000L) } catch (e: Exception) { }
  }

  private fun releaseLocks() {
    try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { multicastLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
  }

  override fun onDestroy() {
    try { engine?.stop() } catch (e: Exception) { }
    engine = null
    ringTimeout?.let { handler.removeCallbacks(it) }
    Ringer.stop(this)
    releaseLocks()
    running = false
    super.onDestroy()
  }
}
