package expo.modules.localnetservice

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Restarts the background service after the phone reboots or the app is updated. */
class BootReceiver : BroadcastReceiver() {
  override fun onReceive(context: Context, intent: Intent?) {
    val a = intent?.action ?: return
    if (a != Intent.ACTION_BOOT_COMPLETED && a != Intent.ACTION_MY_PACKAGE_REPLACED && a != "android.intent.action.QUICKBOOT_POWERON") return
    if (!Store.session(context)) return
    try {
      ContextCompat.startForegroundService(context, Intent(context, LocalNetService::class.java))
    } catch (e: Exception) {
      // some phones block this until the app is opened once
    }
  }
}
