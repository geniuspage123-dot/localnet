package expo.modules.localnetservice

import android.app.Activity
import android.app.Application
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import org.json.JSONObject

class LocalNetServiceModule : Module() {
  private var hooked = false
  private var p2p: P2p? = null

  private fun appCtx(): Context =
    appContext.reactContext ?: throw IllegalStateException("React context is not available")

  private fun applyLock(a: Activity) {
    a.runOnUiThread {
      try {
        val on = Bridge.lockMode
        if (Build.VERSION.SDK_INT >= 27) {
          a.setShowWhenLocked(on)
          a.setTurnScreenOn(on)
        } else {
          @Suppress("DEPRECATION")
          val f = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
          if (on) a.window.addFlags(f) else a.window.clearFlags(f)
        }
      } catch (e: Exception) {
        // ignore
      }
    }
  }

  private fun tryStart(ctx: Context, i: Intent): Boolean {
    return try {
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      ctx.startActivity(i)
      true
    } catch (e: Exception) {
      false
    }
  }

  override fun definition() = ModuleDefinition {
    Name("LocalNetService")
    Events("onLine", "onP2p")

    OnCreate {
      Crypto.init(appCtx())
      Bridge.emitter = { line -> sendEvent("onLine", bundleOf("line" to line)) }
      if (!hooked) {
        hooked = true
        val app = appCtx().applicationContext as Application
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
          override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) { applyLock(activity) }
          override fun onActivityStarted(activity: Activity) {}
          override fun onActivityResumed(activity: Activity) { applyLock(activity) }
          override fun onActivityPaused(activity: Activity) {}
          override fun onActivityStopped(activity: Activity) {}
          override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
          override fun onActivityDestroyed(activity: Activity) {}
        })
      }
    }

    OnDestroy {
      Bridge.detach()
      Bridge.emitter = null
      try { p2p?.stop() } catch (e: Exception) { }
      p2p = null
    }

    /* ----- service ----- */
    Function("start") { title: String, text: String ->
      try {
        val ctx = appCtx()
        val i = Intent(ctx, LocalNetService::class.java)
        i.putExtra("title", title)
        i.putExtra("text", text)
        ContextCompat.startForegroundService(ctx, i)
        true
      } catch (e: Exception) {
        false
      }
    }

    Function("stop") {
      try {
        val ctx = appCtx()
        ctx.stopService(Intent(ctx, LocalNetService::class.java))
        Notif.cancel(ctx, Notif.ID_CALL)
        true
      } catch (e: Exception) {
        false
      }
    }

    Function("isRunning") { LocalNetService.running }

    // microphone foreground type only while a call is active (app is on screen then)
    Function("setCallMode") { on: Boolean ->
      try {
        val ctx = appCtx()
        val i = Intent(ctx, LocalNetService::class.java)
        i.action = LocalNetService.ACTION_CALLMODE
        i.putExtra("on", on)
        ContextCompat.startForegroundService(ctx, i)
        true
      } catch (e: Exception) {
        false
      }
    }

    /* ----- identity / security ----- */
    Function("setIdentity") { id: String, name: String, username: String, session: Boolean ->
      Store.setIdentity(appCtx(), id, name, username, session)
      true
    }

    Function("getRoom") { Store.room(appCtx()) }

    AsyncFunction("setRoom") { room: String ->
      Store.setRoom(appCtx(), room.trim())
      Crypto.setRoom(room)
      true
    }

    AsyncFunction("hashPassword") { username: String, password: String ->
      Crypto.hashPassword(username, password)
    }

    /* ----- network ----- */
    Function("attach") { Bridge.attach(appCtx()) }
    Function("detach") { Bridge.detach(); true }

    AsyncFunction("send") { ip: String, payload: String, ackId: String, timeoutMs: Int ->
      Transport.send(ip, payload, ackId, timeoutMs)
    }

    AsyncFunction("sendVoice") { ip: String, header: String, uri: String, timeoutMs: Int ->
      try {
        val path = Uri.parse(uri).path
        if (path == null) {
          false
        } else {
          val bytes = java.io.File(path).readBytes()
          val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
          val payload = JSONObject(header).put("data", b64).toString()
          Transport.send(ip, payload, JSONObject(header).optString("id"), timeoutMs)
        }
      } catch (e: Exception) {
        false
      }
    }

    Function("setKnownPeers") { ips: List<String> ->
      Store.setKnown(appCtx(), ips)
      LocalNetService.engine?.setKnown(ips)
      true
    }

    Function("localIps") { Engine.localIps() }

    /* ----- Wi-Fi Direct (no router / no hotspot) ----- */
    Function("p2pStart") {
      val ctx = appCtx()
      if (p2p == null) {
        p2p = P2p(
          ctx,
          { json -> sendEvent("onP2p", bundleOf("data" to json)) },
          { ip -> LocalNetService.engine?.addKnown(ip) }
        )
      }
      p2p?.start() ?: false
    }

    Function("p2pConnect") { address: String -> p2p?.connect(address) ?: false }

    Function("p2pStop") {
      try { p2p?.stop() } catch (e: Exception) { }
      true
    }

    /* ----- notifications / ringing ----- */
    Function("showIncomingCall") { name: String, peerId: String ->
      // the app itself rings from now on: silence the native ringer
      Ringer.stop(appCtx())
      Notif.incomingCall(appCtx(), name, peerId)
      true
    }

    Function("cancelIncomingCall") {
      Ringer.stop(appCtx())
      Notif.cancel(appCtx(), Notif.ID_CALL)
      true
    }

    Function("setLockScreenMode") { on: Boolean ->
      Bridge.lockMode = on
      appContext.currentActivity?.let { applyLock(it) }
      true
    }

    Function("showMessage") { name: String, text: String, peerId: String ->
      Notif.message(appCtx(), name, text, peerId)
      true
    }

    Function("cancelMessage") { peerId: String ->
      Notif.cancel(appCtx(), Notif.msgId(peerId))
      true
    }

    /* ----- reliability settings ----- */
    Function("isIgnoringBatteryOptimizations") {
      val pm = appCtx().getSystemService(Context.POWER_SERVICE) as PowerManager
      if (Build.VERSION.SDK_INT >= 23) pm.isIgnoringBatteryOptimizations(appCtx().packageName) else true
    }

    Function("requestIgnoreBatteryOptimizations") {
      val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
      i.data = Uri.parse("package:" + appCtx().packageName)
      tryStart(appCtx(), i)
    }

    Function("canUseFullScreenIntent") {
      if (Build.VERSION.SDK_INT >= 34) {
        val nm = appCtx().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.canUseFullScreenIntent()
      } else {
        true
      }
    }

    Function("openFullScreenIntentSettings") {
      if (Build.VERSION.SDK_INT >= 34) {
        val i = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
        i.data = Uri.parse("package:" + appCtx().packageName)
        tryStart(appCtx(), i)
      } else {
        true
      }
    }

    Function("manufacturer") { Build.MANUFACTURER ?: "" }

    // Many phones (Tecno, Infinix, itel, Xiaomi, Oppo, Vivo, Huawei...) kill background apps unless "autostart" is allowed.
    Function("openAutostartSettings") {
      val ctx = appCtx()
      val targets = listOf(
        ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
        ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
        ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
        ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"),
        ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
        ComponentName("com.transsion.phonemaster", "com.cyin.himgr.autostart.AutoStartActivity"),
        ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")
      )
      var opened = false
      for (cn in targets) {
        val i = Intent()
        i.component = cn
        if (tryStart(ctx, i)) {
          opened = true
          break
        }
      }
      if (!opened) {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
        i.data = Uri.parse("package:" + ctx.packageName)
        opened = tryStart(ctx, i)
      }
      opened
    }
  }
}
