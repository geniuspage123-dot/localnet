package expo.modules.localnetservice

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Looper
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Wi-Fi Direct: lets two or more phones connect to each other with NO router and NO hotspot.
 * Once the group is formed, the normal discovery (UDP broadcast on the p2p interface) finds the peers.
 */
@SuppressLint("MissingPermission")
class P2p(
  private val ctx: Context,
  private val emit: (String) -> Unit,
  private val onGroupIp: (String) -> Unit
) {
  private val mgr: WifiP2pManager? = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
  private var channel: WifiP2pManager.Channel? = null
  private var receiver: BroadcastReceiver? = null
  private var state = "idle"
  private var peers = JSONArray()

  private fun push() {
    try {
      emit(JSONObject().put("state", state).put("peers", peers).toString())
    } catch (e: Exception) {
    }
  }

  fun start(): Boolean {
    val m = mgr ?: run { state = "unsupported"; push(); return false }
    try {
      if (channel == null) channel = m.initialize(ctx, Looper.getMainLooper(), null)
      val ch = channel ?: return false
      if (receiver == null) {
        val r = object : BroadcastReceiver() {
          override fun onReceive(c: Context?, i: Intent?) {
            val intent = i ?: return
            when (intent.action) {
              WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> refreshPeers()
              WifiP2pManager.WIFI_P2P_CONNECTION_STATE_CHANGE_ACTION -> refreshConnection()
              WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                val on = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                if (!on) {
                  state = "off"
                  push()
                }
              }
            }
          }
        }
        val f = IntentFilter()
        f.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        f.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_STATE_CHANGE_ACTION)
        f.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiver = r
      }
      state = "searching"
      m.discoverPeers(ch, object : WifiP2pManager.ActionListener {
        override fun onSuccess() { push() }
        override fun onFailure(reason: Int) {
          state = "failed:$reason"
          push()
        }
      })
      push()
      return true
    } catch (e: SecurityException) {
      state = "nopermission"
      push()
      return false
    } catch (e: Exception) {
      state = "failed"
      push()
      return false
    }
  }

  private fun refreshPeers() {
    val m = mgr ?: return
    val ch = channel ?: return
    try {
      m.requestPeers(ch) { list ->
        val arr = JSONArray()
        for (d in list.deviceList) {
          arr.put(JSONObject().put("name", d.deviceName ?: "").put("address", d.deviceAddress ?: "").put("status", d.status))
        }
        peers = arr
        push()
      }
    } catch (e: Exception) {
    }
  }

  private fun refreshConnection() {
    val m = mgr ?: return
    val ch = channel ?: return
    try {
      m.requestConnectionInfo(ch) { info ->
        if (info != null && info.groupFormed) {
          state = if (info.isGroupOwner) "group-owner" else "connected"
          info.groupOwnerAddress?.hostAddress?.let { onGroupIp(it) }
        } else if (state == "group-owner" || state == "connected" || state == "connecting") {
          state = "searching"
        }
        push()
      }
    } catch (e: Exception) {
    }
  }

  fun connect(address: String): Boolean {
    val m = mgr ?: return false
    val ch = channel ?: return false
    return try {
      val cfg = WifiP2pConfig()
      cfg.deviceAddress = address
      cfg.wps.setup = WpsInfo.PBC
      state = "connecting"
      push()
      m.connect(ch, cfg, object : WifiP2pManager.ActionListener {
        override fun onSuccess() { }
        override fun onFailure(reason: Int) {
          state = "failed:$reason"
          push()
        }
      })
      true
    } catch (e: Exception) {
      false
    }
  }

  fun stop() {
    val m = mgr
    val ch = channel
    try {
      if (m != null && ch != null) {
        m.stopPeerDiscovery(ch, null)
        m.removeGroup(ch, null)
      }
    } catch (e: Exception) {
    }
    try { receiver?.let { ctx.unregisterReceiver(it) } } catch (e: Exception) { }
    receiver = null
    state = "idle"
    peers = JSONArray()
  }
}
