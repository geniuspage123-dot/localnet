package expo.modules.localnetdirect

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class LocalNetDirectModule : Module() {
  private var manager: WifiP2pManager? = null
  private var channel: WifiP2pManager.Channel? = null
  private var receiver: BroadcastReceiver? = null

  private fun appCtx(): Context =
    appContext.reactContext ?: throw IllegalStateException("React context is not available")

  private fun sendResult(action: String, ok: Boolean, reason: Int) {
    sendEvent("onResult", mapOf("action" to action, "ok" to ok, "reason" to reason))
  }

  private fun listener(action: String): WifiP2pManager.ActionListener {
    return object : WifiP2pManager.ActionListener {
      override fun onSuccess() { sendResult(action, true, 0) }
      override fun onFailure(reason: Int) { sendResult(action, false, reason) }
    }
  }

  private fun queryGroup() {
    val wm = manager ?: return
    val ch = channel ?: return
    try {
      wm.requestConnectionInfo(ch) { info ->
        var formed = false
        var isOwner = false
        var owner = ""
        if (info != null) {
          formed = info.groupFormed
          isOwner = info.isGroupOwner
          owner = info.groupOwnerAddress?.hostAddress ?: ""
        }
        sendEvent("onGroup", mapOf("formed" to formed, "isOwner" to isOwner, "owner" to owner))
      }
    } catch (e: Exception) {
      // ignore
    }
  }

  private fun startP2p(): Boolean {
    if (manager != null) {
      queryGroup()
      return true
    }
    val c = appCtx()
    val wm = c.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager ?: return false
    val ch = wm.initialize(c, c.mainLooper, null)
    manager = wm
    channel = ch
    val filter = IntentFilter()
    filter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
    filter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
    val r = object : BroadcastReceiver() {
      override fun onReceive(context: Context?, intent: Intent?) {
        val act = intent?.action
        if (act == WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION) {
          val st = intent?.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) ?: -1
          sendEvent("onState", mapOf("enabled" to (st == WifiP2pManager.WIFI_P2P_STATE_ENABLED)))
        } else if (act == WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION) {
          queryGroup()
        }
      }
    }
    ContextCompat.registerReceiver(c, r, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    receiver = r
    queryGroup()
    return true
  }

  private fun stopP2p() {
    val wm = manager
    val ch = channel
    try {
      if (wm != null && ch != null) wm.removeGroup(ch, null)
    } catch (e: Exception) { }
    try {
      val r = receiver
      if (r != null) appCtx().unregisterReceiver(r)
    } catch (e: Exception) { }
    try {
      if (Build.VERSION.SDK_INT >= 27) ch?.close()
    } catch (e: Exception) { }
    receiver = null
    channel = null
    manager = null
  }

  private fun doJoin(name: String, pass: String): Boolean {
    val wm = manager ?: return false
    val ch = channel ?: return false
    if (Build.VERSION.SDK_INT < 29) return false
    return try {
      val cfg = WifiP2pConfig.Builder().setNetworkName(name).setPassphrase(pass).build()
      wm.connect(ch, cfg, listener("join"))
      true
    } catch (e: Exception) {
      false
    }
  }

  private fun doHost(name: String, pass: String): Boolean {
    val wm = manager ?: return false
    val ch = channel ?: return false
    if (Build.VERSION.SDK_INT < 29) return false
    return try {
      val cfg = WifiP2pConfig.Builder()
        .setNetworkName(name)
        .setPassphrase(pass)
        .enablePersistentMode(false)
        .build()
      wm.createGroup(ch, cfg, listener("host"))
      true
    } catch (e: Exception) {
      false
    }
  }

  private fun doLeave(): Boolean {
    val wm = manager ?: return false
    val ch = channel ?: return false
    return try {
      wm.removeGroup(ch, listener("leave"))
      true
    } catch (e: Exception) {
      false
    }
  }

  override fun definition() = ModuleDefinition {
    Name("LocalNetDirect")

    Events("onGroup", "onState", "onResult")

    Function("isSupported") {
      Build.VERSION.SDK_INT >= 29 && appCtx().packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)
    }

    Function("isWifiEnabled") {
      val w = appCtx().applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
      w.isWifiEnabled
    }

    Function("start") {
      try {
        startP2p()
      } catch (e: Exception) {
        false
      }
    }

    Function("stop") {
      stopP2p()
      true
    }

    Function("join") { name: String, pass: String ->
      doJoin(name, pass)
    }

    Function("host") { name: String, pass: String ->
      doHost(name, pass)
    }

    Function("leave") {
      doLeave()
    }

    Function("refresh") {
      queryGroup()
      true
    }

    Function("openWifiPanel") {
      try {
        val i = Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        appCtx().startActivity(i)
        true
      } catch (e: Exception) {
        false
      }
    }

    Function("lanStart") { ip: String, port: Int ->
      LanAudio.start(appCtx(), ip, port)
    }

    Function("lanStop") {
      LanAudio.stop()
      true
    }

    Function("lanMute") { m: Boolean ->
      LanAudio.setMuted(m)
      true
    }

    Function("lanRxAge") {
      LanAudio.rxAgeMs()
    }

    Function("lanStats") {
      LanAudio.stats()
    }

    OnDestroy {
      LanAudio.stop()
      stopP2p()
    }
  }
}
