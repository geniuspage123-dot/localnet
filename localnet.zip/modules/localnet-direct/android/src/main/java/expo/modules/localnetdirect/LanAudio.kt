package expo.modules.localnetdirect

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.util.concurrent.LinkedBlockingQueue

// Plain voice over UDP between two phones on the same local network (used for Direct Wi-Fi calls,
// where the normal WebRTC engine cannot use the Wi-Fi Direct network). No internet needed.
// 16 kHz, 16-bit, mono, 20 ms per packet. The receiving side keeps a small adaptive jitter buffer:
// it starts with 60 ms, grows when packets arrive late and shrinks again when the line is calm.
object LanAudio {
  private const val RATE = 16000
  private const val FRAME_SAMPLES = 320
  private const val FRAME_BYTES = FRAME_SAMPLES * 2
  private const val MIN_DEPTH = 3
  private const val MAX_DEPTH = 10

  @Volatile private var running = false
  @Volatile private var muted = false
  @Volatile private var lastRx = 0L
  @Volatile private var tx = 0
  @Volatile private var rx = 0
  @Volatile private var underruns = 0

  private var socket: DatagramSocket? = null
  private var record: AudioRecord? = null
  private var track: AudioTrack? = null
  private var sendThread: Thread? = null
  private var recvThread: Thread? = null
  private var playThread: Thread? = null
  private var audioManager: AudioManager? = null
  private var previousMode = AudioManager.MODE_NORMAL
  private val queue = LinkedBlockingQueue<ShortArray>()

  fun setMuted(m: Boolean) {
    muted = m
  }

  fun rxAgeMs(): Int {
    if (!running) return -1
    val age = System.currentTimeMillis() - lastRx
    return if (age > 1000000L) 1000000 else age.toInt()
  }

  fun stats(): String = "" + tx + ":" + rx + ":" + underruns

  @Synchronized
  fun start(ctx: Context, peerIp: String, port: Int): Boolean {
    stop()
    try {
      val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
      audioManager = am
      previousMode = am.mode
      am.mode = AudioManager.MODE_IN_COMMUNICATION

      val s = DatagramSocket(null)
      s.reuseAddress = true
      s.bind(InetSocketAddress(port))
      s.soTimeout = 500
      try { s.trafficClass = 0xB8 } catch (e: Exception) { }
      val remote = InetSocketAddress(InetAddress.getByName(peerIp), port)

      val minIn = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val rec = AudioRecord(
        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
        RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT,
        maxOf(minIn, FRAME_BYTES * 4)
      )
      if (rec.state != AudioRecord.STATE_INITIALIZED) {
        rec.release()
        s.close()
        am.mode = previousMode
        return false
      }
      try {
        if (AcousticEchoCanceler.isAvailable()) {
          AcousticEchoCanceler.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }
      try {
        if (NoiseSuppressor.isAvailable()) {
          NoiseSuppressor.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }
      try {
        if (AutomaticGainControl.isAvailable()) {
          AutomaticGainControl.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }

      val minOut = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val trk = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setSampleRate(RATE)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(maxOf(minOut, FRAME_BYTES * 6))
        .setTransferMode(AudioTrack.MODE_STREAM)
        .build()

      socket = s
      record = rec
      track = trk
      queue.clear()
      muted = false
      tx = 0
      rx = 0
      underruns = 0
      lastRx = System.currentTimeMillis()
      running = true
      rec.startRecording()
      trk.play()

      val sender = Thread {
        val shorts = ShortArray(FRAME_SAMPLES)
        val bytes = ByteArray(FRAME_BYTES)
        while (running) {
          val n = rec.read(shorts, 0, FRAME_SAMPLES)
          if (n <= 0) {
            try { Thread.sleep(5) } catch (e: InterruptedException) { }
            continue
          }
          var i = 0
          while (i < n) {
            val v = if (muted) 0 else shorts[i].toInt()
            bytes[i * 2] = (v and 0xFF).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            i++
          }
          try {
            s.send(DatagramPacket(bytes, n * 2, remote))
            tx++
          } catch (e: Exception) { }
        }
      }

      val receiver = Thread {
        val buf = ByteArray(2048)
        val pkt = DatagramPacket(buf, buf.size)
        while (running) {
          try {
            pkt.length = buf.size
            s.receive(pkt)
            if (pkt.address != null && pkt.address.hostAddress != peerIp) continue
            val ns = pkt.length / 2
            if (ns > 0) {
              val frame = ShortArray(ns)
              var i = 0
              while (i < ns) {
                frame[i] = ((buf[i * 2].toInt() and 0xFF) or (buf[i * 2 + 1].toInt() shl 8)).toShort()
                i++
              }
              queue.offer(frame)
              while (queue.size > MAX_DEPTH + 8) queue.poll()
              rx++
              lastRx = System.currentTimeMillis()
            }
          } catch (e: SocketTimeoutException) {
            // no packet in the last 500 ms
          } catch (e: Exception) {
            if (!running) break
          }
        }
      }

      val player = Thread {
        val silence = ShortArray(FRAME_SAMPLES)
        var target = MIN_DEPTH
        var started = false
        var calmSince = System.currentTimeMillis()
        while (running) {
          try {
            if (!started) {
              if (queue.size >= target) {
                started = true
              } else {
                trk.write(silence, 0, silence.size)
                continue
              }
            }
            val f = queue.poll()
            if (f != null) {
              trk.write(f, 0, f.size)
              while (queue.size > target + 6) queue.poll()
              if (target > MIN_DEPTH && System.currentTimeMillis() - calmSince > 8000L) {
                target--
                calmSince = System.currentTimeMillis()
              }
            } else {
              underruns++
              started = false
              if (target < MAX_DEPTH) target++
              calmSince = System.currentTimeMillis()
              trk.write(silence, 0, silence.size)
            }
          } catch (e: Exception) {
            if (!running) break
          }
        }
      }

      sender.start()
      receiver.start()
      player.start()
      sendThread = sender
      recvThread = receiver
      playThread = player
      return true
    } catch (e: Exception) {
      stop()
      return false
    }
  }

  @Synchronized
  fun stop() {
    running = false
    try { socket?.close() } catch (e: Exception) { }
    try { record?.stop() } catch (e: Exception) { }
    try { sendThread?.join(300) } catch (e: Exception) { }
    try { recvThread?.join(300) } catch (e: Exception) { }
    try { playThread?.join(300) } catch (e: Exception) { }
    try { record?.release() } catch (e: Exception) { }
    try { track?.stop() } catch (e: Exception) { }
    try { track?.release() } catch (e: Exception) { }
    try { audioManager?.mode = previousMode } catch (e: Exception) { }
    queue.clear()
    socket = null
    record = null
    track = null
    sendThread = null
    recvThread = null
    playThread = null
    audioManager = null
  }
}
