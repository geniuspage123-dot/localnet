package expo.modules.localnetdirect

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import java.net.DatagramPacket
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec
import android.util.Base64
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException
import java.util.concurrent.LinkedBlockingQueue

// Plain voice over UDP between two phones on the same local network (used for Direct Wi-Fi calls,
// where the normal WebRTC engine cannot use the Wi-Fi Direct network). No internet needed.
// 16 kHz, 16-bit, mono, 20 ms per packet. The receiving side keeps a small adaptive jitter buffer:
// it starts with 60 ms, grows when packets arrive late and shrinks again when the line is calm.
object LanAudio {
  private const val RATE = 16000
  private const val FRAME_SAMPLES = 320
  private const val FRAME_BYTES = FRAME_SAMPLES * 2
  private const val MIN_DEPTH = 3
  private const val MAX_DEPTH = 10

  @Volatile private var running = false
  @Volatile private var muted = false
  @Volatile private var lastRx = 0L
  @Volatile private var tx = 0
  @Volatile private var rx = 0
  @Volatile private var underruns = 0

  private var socket: DatagramSocket? = null
  private var record: AudioRecord? = null
  private var track: AudioTrack? = null
  private var sendThread: Thread? = null
  private var recvThread: Thread? = null
  private var playThread: Thread? = null
  private var audioManager: AudioManager? = null
  // The call keeps its own locks, so audio does not depend on the background service being alive:
  // CPU stays awake with the screen off, and Wi-Fi power saving is switched off for the whole call.
  private var wifiLock: WifiManager.WifiLock? = null
  private var cpuLock: PowerManager.WakeLock? = null
  private const val LOCK_MAX_MS = 4L * 60L * 60L * 1000L
  private var previousMode = AudioManager.MODE_NORMAL
  private val queue = LinkedBlockingQueue<ShortArray>()

  // End-to-end encryption of the call audio: AES-256-GCM, key derived in JS from the two phones' keys.
  // Packet = 12-byte IV (random 4 bytes of this call + 8-byte counter) + ciphertext + 16-byte tag.
  private var aesKey: SecretKeySpec? = null
  private val ivPrefix = ByteArray(4)
  @Volatile private var txCounter = 0L

  private fun seal(plain: ByteArray, len: Int): ByteArray? {
    val k = aesKey ?: return null
    return try {
      val iv = ByteArray(12)
      System.arraycopy(ivPrefix, 0, iv, 0, 4)
      var c = txCounter++
      var i = 11
      while (i >= 4) { iv[i] = (c and 0xFF).toByte(); c = c shr 8; i-- }
      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, iv))
      val ct = cipher.doFinal(plain, 0, len)
      val out = ByteArray(12 + ct.size)
      System.arraycopy(iv, 0, out, 0, 12)
      System.arraycopy(ct, 0, out, 12, ct.size)
      out
    } catch (e: Exception) { null }
  }

  // returns the audio bytes, or null if the packet is not from our friend (wrong key / changed on the way)
  private fun unseal(packet: ByteArray, len: Int): ByteArray? {
    val k = aesKey ?: return null
    if (len < 12 + 16 + 2) return null
    return try {
      val cipher = Cipher.getInstance("AES/GCM/NoPadding")
      cipher.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, packet, 0, 12))
      cipher.doFinal(packet, 12, len - 12)
    } catch (e: Exception) { null }
  }

  fun setMuted(m: Boolean) {
    muted = m
  }

  fun rxAgeMs(): Int {
    if (!running) return -1
    val age = System.currentTimeMillis() - lastRx
    return if (age > 1000000L) 1000000 else age.toInt()
  }

  fun stats(): String = "" + tx + ":" + rx + ":" + underruns

  @Synchronized
  fun start(ctx: Context, peerIp: String, port: Int, keyB64: String): Boolean {
    stop()
    try {
      // no key = no call: audio is never sent in the clear
      val raw = Base64.decode(keyB64, Base64.DEFAULT)
      if (raw.size != 32) return false
      aesKey = SecretKeySpec(raw, "AES")
      SecureRandom().nextBytes(ivPrefix)
      txCounter = 0L
      val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
      audioManager = am
      previousMode = am.mode
      am.mode = AudioManager.MODE_IN_COMMUNICATION
      acquireLocks(ctx.applicationContext)

      val s = DatagramSocket(null)
      s.reuseAddress = true
      s.bind(InetSocketAddress(port))
      s.soTimeout = 500
      try { s.trafficClass = 0xB8 } catch (e: Exception) { }
      val remote = InetSocketAddress(InetAddress.getByName(peerIp), port)

      val minIn = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val rec = AudioRecord(
        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
        RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT,
        maxOf(minIn, FRAME_BYTES * 4)
      )
      if (rec.state != AudioRecord.STATE_INITIALIZED) {
        rec.release()
        s.close()
        am.mode = previousMode
        releaseLocks()
        return false
      }
      try {
        if (AcousticEchoCanceler.isAvailable()) {
          AcousticEchoCanceler.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }
      try {
        if (NoiseSuppressor.isAvailable()) {
          NoiseSuppressor.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }
      try {
        if (AutomaticGainControl.isAvailable()) {
          AutomaticGainControl.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }

      val minOut = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val trk = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setSampleRate(RATE)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(maxOf(minOut, FRAME_BYTES * 6))
        .setTransferMode(AudioTrack.MODE_STREAM)
        .build()

      socket = s
      record = rec
      track = trk
      queue.clear()
      muted = false
      tx = 0
      rx = 0
      underruns = 0
      lastRx = System.currentTimeMillis()
      running = true
      rec.startRecording()
      trk.play()

      val sender = Thread {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) { }
        val shorts = ShortArray(FRAME_SAMPLES)
        val bytes = ByteArray(FRAME_BYTES)
        while (running) {
          val n = rec.read(shorts, 0, FRAME_SAMPLES)
          if (n <= 0) {
            try { Thread.sleep(5) } catch (e: InterruptedException) { }
            continue
          }
          var i = 0
          while (i < n) {
            val v = if (muted) 0 else shorts[i].toInt()
            bytes[i * 2] = (v and 0xFF).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            i++
          }
          try {
            val sealed = seal(bytes, n * 2)
            if (sealed != null) {
              s.send(DatagramPacket(sealed, sealed.size, remote))
              tx++
            }
          } catch (e: Exception) { }
        }
      }

      val receiver = Thread {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO) } catch (e: Exception) { }
        val buf = ByteArray(2048)
        val pkt = DatagramPacket(buf, buf.size)
        while (running) {
          try {
            pkt.length = buf.size
            s.receive(pkt)
            if (pkt.address != null && pkt.address.hostAddress != peerIp) continue
            val plain = unseal(buf, pkt.length) ?: continue
            val ns = plain.size / 2
            if (ns > 0) {
              val frame = ShortArray(ns)
              var i = 0
              while (i < ns) {
                frame[i] = ((plain[i * 2].toInt() and 0xFF) or (plain[i * 2 + 1].toInt() shl 8)).toShort()
                i++
              }
              queue.offer(frame)
              while (queue.size > MAX_DEPTH + 8) queue.poll()
              rx++
              lastRx = System.currentTimeMillis()
            }
          } catch (e: SocketTimeoutException) {
            // no packet in the last 500 ms
          } catch (e: Exception) {
            if (!running) break
          }
        }
      }

      val player = Thread {
        try { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO) } catch (e: Exception) { }
        val silence = ShortArray(FRAME_SAMPLES)
        var target = MIN_DEPTH
        var started = false
        var calmSince = System.currentTimeMillis()
        while (running) {
          try {
            if (!started) {
              if (queue.size >= target) {
                started = true
              } else {
                trk.write(silence, 0, silence.size)
                continue
              }
            }
            val f = queue.poll()
            if (f != null) {
              trk.write(f, 0, f.size)
              while (queue.size > target + 6) queue.poll()
              if (target > MIN_DEPTH && System.currentTimeMillis() - calmSince > 8000L) {
                target--
                calmSince = System.currentTimeMillis()
              }
            } else {
              underruns++
              started = false
              if (target < MAX_DEPTH) target++
              calmSince = System.currentTimeMillis()
              trk.write(silence, 0, silence.size)
            }
          } catch (e: Exception) {
            if (!running) break
          }
        }
      }

      sender.start()
      receiver.start()
      player.start()
      sendThread = sender
      recvThread = receiver
      playThread = player
      return true
    } catch (e: Exception) {
      stop()
      return false
    }
  }

  @Suppress("DEPRECATION")
  private fun acquireLocks(app: Context) {
    try {
      val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
      if (wifiLock == null) {
        val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
        wifiLock = wm.createWifiLock(mode, "localnet:lanaudio")
        wifiLock?.setReferenceCounted(false)
      }
      wifiLock?.acquire()
    } catch (e: Exception) { }
    try {
      val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
      if (cpuLock == null) {
        cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "localnet:lanaudio-cpu")
        cpuLock?.setReferenceCounted(false)
      }
      // has a time limit, so it can never stay held by mistake (stop() releases it earlier)
      cpuLock?.acquire(LOCK_MAX_MS)
    } catch (e: Exception) { }
  }

  private fun releaseLocks() {
    try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { cpuLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
  }

  @Synchronized
  fun stop() {
    running = false
    try { socket?.close() } catch (e: Exception) { }
    try { record?.stop() } catch (e: Exception) { }
    try { sendThread?.join(300) } catch (e: Exception) { }
    try { recvThread?.join(300) } catch (e: Exception) { }
    try { playThread?.join(300) } catch (e: Exception) { }
    try { record?.release() } catch (e: Exception) { }
    try { track?.stop() } catch (e: Exception) { }
    try { track?.release() } catch (e: Exception) { }
    try { audioManager?.mode = previousMode } catch (e: Exception) { }
    releaseLocks()
    aesKey = null
    queue.clear()
    socket = null
    record = null
    track = null
    sendThread = null
    recvThread = null
    playThread = null
    audioManager = null
  }
}
