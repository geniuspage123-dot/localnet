package expo.modules.localnetservice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

object Notif {
  const val CH_SERVICE = "localnet_service"
  const val CH_MSG = "localnet_messages"
  const val CH_CALL = "localnet_calls"
  const val ID_SERVICE = 4101
  const val ID_CALL = 4102

  fun msgId(peerId: String): Int = 5000 + (peerId.hashCode() and 0x0FFF)

  private fun manager(ctx: Context): NotificationManager =
    ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

  fun ensureChannels(ctx: Context) {
    if (Build.VERSION.SDK_INT < 26) return
    val nm = manager(ctx)
    nm.createNotificationChannel(
      NotificationChannel(CH_SERVICE, "Running in background", NotificationManager.IMPORTANCE_LOW)
    )
    nm.createNotificationChannel(
      NotificationChannel(CH_MSG, "Messages", NotificationManager.IMPORTANCE_HIGH)
    )
    val call = NotificationChannel(CH_CALL, "Calls", NotificationManager.IMPORTANCE_HIGH)
    // the ringtone and vibration are played by the app itself while the call is ringing
    call.setSound(null, null)
    call.enableVibration(false)
    nm.createNotificationChannel(call)
  }

  private fun launchIntent(ctx: Context): PendingIntent {
    val i = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName) ?: Intent()
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  }

  fun serviceNotification(ctx: Context, title: String, text: String): Notification {
    return NotificationCompat.Builder(ctx, CH_SERVICE)
      .setSmallIcon(android.R.drawable.stat_notify_chat)
      .setContentTitle(title)
      .setContentText(text)
      .setContentIntent(launchIntent(ctx))
      .setOngoing(true)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .setCategory(NotificationCompat.CATEGORY_SERVICE)
      .build()
  }

  fun incomingCall(ctx: Context, name: String, peerId: String) {
    ensureChannels(ctx)
    val pi = launchIntent(ctx)
    val n = NotificationCompat.Builder(ctx, CH_CALL)
      .setSmallIcon(android.R.drawable.stat_sys_phone_call)
      .setContentTitle(name)
      .setContentText("Incoming voice call")
      .setPriority(NotificationCompat.PRIORITY_MAX)
      .setCategory(NotificationCompat.CATEGORY_CALL)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .setOngoing(true)
      .setAutoCancel(false)
      .setContentIntent(pi)
      .setFullScreenIntent(pi, true)
      .build()
    manager(ctx).notify(ID_CALL, n)
  }

  fun message(ctx: Context, name: String, text: String, peerId: String) {
    ensureChannels(ctx)
    val n = NotificationCompat.Builder(ctx, CH_MSG)
      .setSmallIcon(android.R.drawable.stat_notify_chat)
      .setContentTitle(name)
      .setContentText(text)
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_MESSAGE)
      .setAutoCancel(true)
      .setContentIntent(launchIntent(ctx))
      .build()
    manager(ctx).notify(msgId(peerId), n)
  }

  fun cancel(ctx: Context, id: Int) {
    manager(ctx).cancel(id)
  }
}
