package expo.modules.localnetservice

import android.app.Activity
import android.app.Application
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.core.content.ContextCompat
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class LocalNetServiceModule : Module() {
  companion object {
    @Volatile
    var lockMode: Boolean = false
  }

  private var hooked = false

  private fun appCtx(): Context =
    appContext.reactContext ?: throw IllegalStateException("React context is not available")

  private fun applyLock(a: Activity) {
    a.runOnUiThread {
      try {
        if (Build.VERSION.SDK_INT >= 27) {
          a.setShowWhenLocked(lockMode)
          a.setTurnScreenOn(lockMode)
        } else {
          @Suppress("DEPRECATION")
          val f = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
          if (lockMode) {
            a.window.addFlags(f)
          } else {
            a.window.clearFlags(f)
          }
        }
      } catch (e: Exception) {
        // ignore
      }
    }
  }

  override fun definition() = ModuleDefinition {
    Name("LocalNetService")

    OnCreate {
      if (!hooked) {
        hooked = true
        val app = appCtx().applicationContext as Application
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
          override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) { applyLock(activity) }
          override fun onActivityStarted(activity: Activity) {}
          override fun onActivityResumed(activity: Activity) { applyLock(activity) }
          override fun onActivityPaused(activity: Activity) {}
          override fun onActivityStopped(activity: Activity) {}
          override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
          override fun onActivityDestroyed(activity: Activity) {}
        })
      }
    }

    Function("start") { title: String, text: String ->
      try {
        val ctx = appCtx()
        val i = Intent(ctx, LocalNetService::class.java)
        i.putExtra("title", title)
        i.putExtra("text", text)
        ContextCompat.startForegroundService(ctx, i)
        true
      } catch (e: Exception) {
        false
      }
    }

    Function("stop") {
      try {
        val ctx = appCtx()
        ctx.stopService(Intent(ctx, LocalNetService::class.java))
        Notif.cancel(ctx, Notif.ID_CALL)
        true
      } catch (e: Exception) {
        false
      }
    }

    Function("isRunning") {
      LocalNetService.running
    }

    Function("showIncomingCall") { name: String, peerId: String ->
      Notif.incomingCall(appCtx(), name, peerId)
      true
    }

    Function("cancelIncomingCall") {
      Notif.cancel(appCtx(), Notif.ID_CALL)
      true
    }

    Function("setLockScreenMode") { on: Boolean ->
      lockMode = on
      appContext.currentActivity?.let { applyLock(it) }
      true
    }

    Function("showMessage") { name: String, text: String, peerId: String ->
      Notif.message(appCtx(), name, text, peerId)
      true
    }

    Function("cancelMessage") { peerId: String ->
      Notif.cancel(appCtx(), Notif.msgId(peerId))
      true
    }

    Function("isIgnoringBatteryOptimizations") {
      val pm = appCtx().getSystemService(Context.POWER_SERVICE) as PowerManager
      if (Build.VERSION.SDK_INT >= 23) pm.isIgnoringBatteryOptimizations(appCtx().packageName) else true
    }

    Function("requestIgnoreBatteryOptimizations") {
      try {
        val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
        i.data = Uri.parse("package:" + appCtx().packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        appCtx().startActivity(i)
        true
      } catch (e: Exception) {
        false
      }
    }

    Function("canUseFullScreenIntent") {
      if (Build.VERSION.SDK_INT >= 34) {
        val nm = appCtx().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.canUseFullScreenIntent()
      } else {
        true
      }
    }

    Function("openFullScreenIntentSettings") {
      try {
        if (Build.VERSION.SDK_INT >= 34) {
          val i = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
          i.data = Uri.parse("package:" + appCtx().packageName)
          i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          appCtx().startActivity(i)
        }
        true
      } catch (e: Exception) {
        false
      }
    }
  }
}
