package expo.modules.localnetservice

import android.content.Intent
import com.facebook.react.HeadlessJsTaskService
import com.facebook.react.bridge.Arguments
import com.facebook.react.jstasks.HeadlessJsTaskConfig

// Starts the JS task "LocalNetKeepAlive" (see index.js) without any screen.
// timeout 0 = no time limit, true = also allowed while the app is in the foreground.
class LocalNetHeadlessService : HeadlessJsTaskService() {
  override fun getTaskConfig(intent: Intent?): HeadlessJsTaskConfig? =
    HeadlessJsTaskConfig("LocalNetKeepAlive", Arguments.createMap(), 0L, true)
}
