package expo.modules.localnetservice

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import androidx.core.app.NotificationCompat
import android.provider.Settings
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.NotificationChannel
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat

class LocalNetService : Service() {
  companion object {
    @Volatile
    var running: Boolean = false

    @Volatile
    var instance: LocalNetService? = null

    private const val WAKE_MS = 10L * 60L * 1000L
    private const val RENEW_MS = 9L * 60L * 1000L
    private const val PREFS = "localnet_service"
    private const val WIFI_CHECK_MS = 30L * 1000L
    const val ACTION_ECO = "expo.modules.localnetservice.ECO_TICK"
    private const val ECO_EVERY_MS = 120L * 1000L
    private const val ECO_WINDOW_MS = 6L * 1000L

    @Volatile
    var ecoListener: (() -> Unit)? = null
    private const val WIFI_OFF_ID = 7102
    private const val WIFI_OFF_CHANNEL = "wifi_off"
  }

  private var wifiLock: WifiManager.WifiLock? = null
  private var callLock: WifiManager.WifiLock? = null
  private var multicastLock: WifiManager.MulticastLock? = null
  private var wakeLock: PowerManager.WakeLock? = null
  private val handler = Handler(Looper.getMainLooper())
  private var note: Notification? = null
  private var eco = false
  private var inCall = false

  // Every 30 s: if Wi-Fi was switched off, bring the user back to it. Android 10+ does not let an app switch
  // Wi-Fi on by itself, so the phone shows a notification that opens the Wi-Fi panel with one tap
  // (on Android 9 and older the app can switch it on directly).
  private val wifiCheck = object : Runnable {
    override fun run() {
      try {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) {
          @Suppress("DEPRECATION")
          if (Build.VERSION.SDK_INT < 29) { try { wm.isWifiEnabled = true } catch (e: Exception) { } }
          if (!wm.isWifiEnabled) showWifiOff() else cancelWifiOff()
        } else {
          cancelWifiOff()
        }
      } catch (e: Exception) { }
      if (running) handler.postDelayed(this, WIFI_CHECK_MS)
    }
  }

  private fun showWifiOff() {
    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(NotificationChannel(WIFI_OFF_CHANNEL, "Wi-Fi reminder", NotificationManager.IMPORTANCE_DEFAULT))
    }
    val i = if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val pi = PendingIntent.getActivity(this, 7102, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val n = NotificationCompat.Builder(this, WIFI_OFF_CHANNEL)
      .setSmallIcon(android.R.drawable.stat_sys_warning)
      .setContentTitle("Wi-Fi is off")
      .setContentText("UnitedApp cannot reach nearby phones. Tap to turn Wi-Fi on.")
      .setContentIntent(pi)
      .setOnlyAlertOnce(true)
      .setOngoing(true)
      .build()
    nm.notify(WIFI_OFF_ID, n)
  }

  private fun cancelWifiOff() {
    try { (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(WIFI_OFF_ID) } catch (e: Exception) { }
  }
  private var netCb: ConnectivityManager.NetworkCallback? = null

  // The CPU lock is renewed every 9 minutes, so it can never get stuck for ever.
  private val renew = object : Runnable {
    override fun run() {
      renewWakeLock()
      handler.postDelayed(this, RENEW_MS)
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    instance = this
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    Notif.ensureChannels(this)
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    // intent == null means Android restarted us (START_STICKY) after it had killed the process
    if (intent?.action == ACTION_ECO && running) {
      ecoTick()
      return START_STICKY
    }
    val restarted = intent == null || intent.action == ACTION_ECO
    if (restarted && !prefs.getBoolean("wanted", false)) {
      stopSelf()
      return START_NOT_STICKY
    }
    val title = intent?.getStringExtra("title") ?: prefs.getString("title", null) ?: "UnitedApp"
    val text = intent?.getStringExtra("text") ?: "Ready for messages and calls"
    if (!restarted) prefs.edit().putBoolean("wanted", true).putString("title", title).apply()
    val n = Notif.serviceNotification(this, title, text)
    note = n
    try {
      // Start with connectedDevice only. The microphone type may not be started from the background on
      // Android 14+ (it throws and the old code then killed the whole service), so it is added in callMode().
      if (Build.VERSION.SDK_INT >= 29) {
        startForeground(Notif.ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
      } else {
        startForeground(Notif.ID_SERVICE, n)
      }
      running = true
      if (prefs.getBoolean("eco", false)) applyEco(true) else acquireLocks()
      // bindWifi() is off on purpose: binding the whole process to Wi-Fi can break Wi-Fi Direct and hotspot traffic
      handler.removeCallbacks(wifiCheck)
      handler.post(wifiCheck)
      // Android restarted us after killing the app: there is no JS running, so start it headless
      if (restarted) {
        try { startService(Intent(this, LocalNetHeadlessService::class.java)) } catch (e: Exception) { }
      }
    } catch (e: Exception) {
      running = false
      stopSelf()
    }
    return START_STICKY
  }

  // Keep the process attached to the Wi-Fi network even when that network has no internet
  // (industrial gateways/routers usually have none). Without this Android 10+ may drop the Wi-Fi
  // or send sockets through mobile data instead.
  private fun bindWifi() {
    if (netCb != null) return
    try {
      val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
      val req = NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        .build()
      val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
          try { cm.bindProcessToNetwork(network) } catch (e: Exception) { }
        }
        override fun onLost(network: Network) {
          try { cm.bindProcessToNetwork(null) } catch (e: Exception) { }
        }
      }
      cm.requestNetwork(req, cb)
      netCb = cb
    } catch (e: Exception) {
      netCb = null
    }
  }

  private fun unbindWifi() {
    try {
      val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
      netCb?.let { cm.unregisterNetworkCallback(it) }
      cm.bindProcessToNetwork(null)
    } catch (e: Exception) { }
    netCb = null
  }

  @Suppress("DEPRECATION")
  private fun acquireLocks() {
    try {
      val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
      if (wifiLock == null) {
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "localnet:wifi")
        wifiLock?.setReferenceCounted(false)
      }
      wifiLock?.acquire()
      if (multicastLock == null) {
        multicastLock = wm.createMulticastLock("localnet:multicast")
        multicastLock?.setReferenceCounted(false)
      }
      multicastLock?.acquire()
      val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
      if (wakeLock == null) {
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "localnet:cpu")
        wakeLock?.setReferenceCounted(false)
      }
      wakeLock?.acquire(WAKE_MS)
      handler.removeCallbacks(renew)
      handler.postDelayed(renew, RENEW_MS)
    } catch (e: Exception) {
      // locks are an optimisation only
    }
  }

  private fun renewWakeLock() {
    try {
      // acquire() on a non reference-counted lock only restarts its timeout: no gap without the lock
      wakeLock?.acquire(WAKE_MS)
    } catch (e: Exception) { }
  }

  // While a call is active the Wi-Fi radio is kept in its fastest mode.
  fun callMode(on: Boolean) {
    inCall = on
    promoteMic(on)
    try {
      if (on) {
        if (Build.VERSION.SDK_INT >= 29) {
          val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
          if (callLock == null) {
            callLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "localnet:call")
            callLock?.setReferenceCounted(false)
          }
          callLock?.acquire()
        }
      } else {
        callLock?.let { if (it.isHeld) it.release() }
      }
    } catch (e: Exception) { }
  }

  private fun promoteMic(on: Boolean) {
    try {
      val n = note ?: return
      if (Build.VERSION.SDK_INT < 30) return
      var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
      val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
      if (on && micOk) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
      startForeground(Notif.ID_SERVICE, n, type)
    } catch (e: Exception) {
      // if Android refuses, the service keeps running as connectedDevice
    }
  }

  // ---- battery saver ("eco"): no permanent locks. Every 2 minutes an alarm wakes the phone for ~6 s, the app
  // checks the gateway during that window, then the locks are released and the phone can sleep again.
  fun setEco(on: Boolean) {
    getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("eco", on).apply()
    applyEco(on)
  }

  private fun applyEco(on: Boolean) {
    eco = on
    if (on) {
      handler.removeCallbacks(renew)
      if (!inCall) releaseBackgroundLocks()
      scheduleEco()
    } else {
      cancelEco()
      acquireLocks()
    }
  }

  private fun ecoIntent(): PendingIntent {
    val i = Intent(this, LocalNetService::class.java)
    i.action = ACTION_ECO
    return PendingIntent.getService(this, 7103, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  }

  private fun scheduleEco() {
    try {
      val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
      val at = System.currentTimeMillis() + ECO_EVERY_MS
      // Android 12+ needs the user's "alarms & reminders" permission for exact times; without it the
      // alarm is still delivered, only less precisely (it can be late while the phone is in deep sleep).
      val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
      if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, ecoIntent())
      else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, ecoIntent())
    } catch (e: Exception) { }
  }

  private fun cancelEco() {
    try { (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(ecoIntent()) } catch (e: Exception) { }
  }

  private fun ecoTick() {
    try {
      acquireLocks()
      handler.postDelayed({
        if (eco && !inCall) {
          handler.removeCallbacks(renew)
          releaseBackgroundLocks()
        }
      }, ECO_WINDOW_MS)
    } catch (e: Exception) { }
    try { ecoListener?.invoke() } catch (e: Exception) { }
    if (eco) scheduleEco()
  }

  private fun releaseBackgroundLocks() {
    try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { multicastLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
  }

  private fun releaseLocks() {
    try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { callLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { multicastLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
  }

  override fun onDestroy() {
    handler.removeCallbacks(renew)
    cancelEco()
    try { stopService(Intent(this, LocalNetHeadlessService::class.java)) } catch (e: Exception) { }
    handler.removeCallbacks(wifiCheck)
    cancelWifiOff()
    unbindWifi()
    releaseLocks()
    running = false
    instance = null
    super.onDestroy()
  }
}
