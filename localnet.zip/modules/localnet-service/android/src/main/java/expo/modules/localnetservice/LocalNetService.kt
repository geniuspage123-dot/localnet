package expo.modules.localnetservice

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat

class LocalNetService : Service() {
  companion object {
    @Volatile
    var running: Boolean = false
  }

  private var wifiLock: WifiManager.WifiLock? = null
  private var multicastLock: WifiManager.MulticastLock? = null
  private var wakeLock: PowerManager.WakeLock? = null

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    Notif.ensureChannels(this)
    val title = intent?.getStringExtra("title") ?: "LocalNet Connect"
    val text = intent?.getStringExtra("text") ?: "Ready for messages and calls"
    val n = Notif.serviceNotification(this, title, text)
    try {
      val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
      if (Build.VERSION.SDK_INT >= 30) {
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
        if (micOk) {
          type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        startForeground(Notif.ID_SERVICE, n, type)
      } else if (Build.VERSION.SDK_INT >= 29) {
        startForeground(Notif.ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
      } else {
        startForeground(Notif.ID_SERVICE, n)
      }
      running = true
      acquireLocks()
    } catch (e: Exception) {
      running = false
      stopSelf()
    }
    return START_STICKY
  }

  @Suppress("DEPRECATION")
  private fun acquireLocks() {
    try {
      val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
      if (wifiLock == null) {
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "localnet:wifi")
        wifiLock?.setReferenceCounted(false)
      }
      wifiLock?.acquire()
      if (multicastLock == null) {
        multicastLock = wm.createMulticastLock("localnet:multicast")
        multicastLock?.setReferenceCounted(false)
      }
      multicastLock?.acquire()
      val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
      if (wakeLock == null) {
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "localnet:cpu")
        wakeLock?.setReferenceCounted(false)
      }
      wakeLock?.acquire()
    } catch (e: Exception) {
      // locks are an optimisation only
    }
  }

  private fun releaseLocks() {
    try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { multicastLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
  }

  override fun onDestroy() {
    releaseLocks()
    running = false
    super.onDestroy()
  }
}
