package expo.modules.localnetservice

import android.Manifest
import android.app.Notification
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat

class LocalNetService : Service() {
  companion object {
    @Volatile
    var running: Boolean = false

    @Volatile
    var instance: LocalNetService? = null

    private const val WAKE_MS = 10L * 60L * 1000L
    private const val RENEW_MS = 9L * 60L * 1000L
    private const val PREFS = "localnet_service"
  }

  private var wifiLock: WifiManager.WifiLock? = null
  private var callLock: WifiManager.WifiLock? = null
  private var multicastLock: WifiManager.MulticastLock? = null
  private var wakeLock: PowerManager.WakeLock? = null
  private val handler = Handler(Looper.getMainLooper())
  private var note: Notification? = null
  private var netCb: ConnectivityManager.NetworkCallback? = null

  // The CPU lock is renewed every 9 minutes, so it can never get stuck for ever.
  private val renew = object : Runnable {
    override fun run() {
      renewWakeLock()
      handler.postDelayed(this, RENEW_MS)
    }
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    instance = this
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    Notif.ensureChannels(this)
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    // intent == null means Android restarted us (START_STICKY) after it had killed the process
    val restarted = intent == null
    if (restarted && !prefs.getBoolean("wanted", false)) {
      stopSelf()
      return START_NOT_STICKY
    }
    val title = intent?.getStringExtra("title") ?: prefs.getString("title", null) ?: "LocalNet Connect"
    val text = intent?.getStringExtra("text") ?: "Ready for messages and calls"
    if (!restarted) prefs.edit().putBoolean("wanted", true).putString("title", title).apply()
    val n = Notif.serviceNotification(this, title, text)
    note = n
    try {
      // Start with connectedDevice only. The microphone type may not be started from the background on
      // Android 14+ (it throws and the old code then killed the whole service), so it is added in callMode().
      if (Build.VERSION.SDK_INT >= 29) {
        startForeground(Notif.ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
      } else {
        startForeground(Notif.ID_SERVICE, n)
      }
      running = true
      acquireLocks()
      bindWifi()
      // Android restarted us after killing the app: there is no JS running, so start it headless
      if (restarted) {
        try { startService(Intent(this, LocalNetHeadlessService::class.java)) } catch (e: Exception) { }
      }
    } catch (e: Exception) {
      running = false
      stopSelf()
    }
    return START_STICKY
  }

  // Keep the process attached to the Wi-Fi network even when that network has no internet
  // (industrial gateways/routers usually have none). Without this Android 10+ may drop the Wi-Fi
  // or send sockets through mobile data instead.
  private fun bindWifi() {
    if (netCb != null) return
    try {
      val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
      val req = NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        .build()
      val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
          try { cm.bindProcessToNetwork(network) } catch (e: Exception) { }
        }
        override fun onLost(network: Network) {
          try { cm.bindProcessToNetwork(null) } catch (e: Exception) { }
        }
      }
      cm.requestNetwork(req, cb)
      netCb = cb
    } catch (e: Exception) {
      netCb = null
    }
  }

  private fun unbindWifi() {
    try {
      val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
      netCb?.let { cm.unregisterNetworkCallback(it) }
      cm.bindProcessToNetwork(null)
    } catch (e: Exception) { }
    netCb = null
  }

  @Suppress("DEPRECATION")
  private fun acquireLocks() {
    try {
      val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
      if (wifiLock == null) {
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "localnet:wifi")
        wifiLock?.setReferenceCounted(false)
      }
      wifiLock?.acquire()
      if (multicastLock == null) {
        multicastLock = wm.createMulticastLock("localnet:multicast")
        multicastLock?.setReferenceCounted(false)
      }
      multicastLock?.acquire()
      val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
      if (wakeLock == null) {
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "localnet:cpu")
        wakeLock?.setReferenceCounted(false)
      }
      wakeLock?.acquire(WAKE_MS)
      handler.removeCallbacks(renew)
      handler.postDelayed(renew, RENEW_MS)
    } catch (e: Exception) {
      // locks are an optimisation only
    }
  }

  private fun renewWakeLock() {
    try {
      // acquire() on a non reference-counted lock only restarts its timeout: no gap without the lock
      wakeLock?.acquire(WAKE_MS)
    } catch (e: Exception) { }
  }

  // While a call is active the Wi-Fi radio is kept in its fastest mode.
  fun callMode(on: Boolean) {
    promoteMic(on)
    try {
      if (on) {
        if (Build.VERSION.SDK_INT >= 29) {
          val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
          if (callLock == null) {
            callLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "localnet:call")
            callLock?.setReferenceCounted(false)
          }
          callLock?.acquire()
        }
      } else {
        callLock?.let { if (it.isHeld) it.release() }
      }
    } catch (e: Exception) { }
  }

  private fun promoteMic(on: Boolean) {
    try {
      val n = note ?: return
      if (Build.VERSION.SDK_INT < 30) return
      var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
      val micOk = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
      if (on && micOk) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
      startForeground(Notif.ID_SERVICE, n, type)
    } catch (e: Exception) {
      // if Android refuses, the service keeps running as connectedDevice
    }
  }

  private fun releaseLocks() {
    try { wifiLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { callLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { multicastLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
    try { wakeLock?.let { if (it.isHeld) it.release() } } catch (e: Exception) { }
  }

  override fun onDestroy() {
    handler.removeCallbacks(renew)
    try { stopService(Intent(this, LocalNetHeadlessService::class.java)) } catch (e: Exception) { }
    unbindWifi()
    releaseLocks()
    running = false
    instance = null
    super.onDestroy()
  }
}
