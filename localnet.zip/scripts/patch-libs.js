// Runs automatically after "npm install" (see "postinstall" in package.json).
// Fixes two bugs inside react-native-background-actions so that it compiles:
//  1) a stray '#' character in front of ServiceCompat.startForeground(...)
//  2) the installed androidx.core is too old and has no ServiceCompat.startForeground
//     -> a small replacement class with the same name is added to the same package.
const fs = require('fs');
const path = require('path');

const base = path.join(__dirname, '..', 'node_modules', 'react-native-background-actions', 'android', 'src', 'main', 'java');
if (!fs.existsSync(base)) {
  console.log('[patch] react-native-background-actions not installed, skipping');
  process.exit(0);
}

function walk(dir, out) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (p.endsWith('.java')) out.push(p);
  }
  return out;
}

for (const f of walk(base, [])) {
  const t = fs.readFileSync(f, 'utf8');
  const n = t
    .replace(/^([ \t]*)#[ \t]*(?=ServiceCompat)/gm, '$1')
    .replace(/^import\s+androidx\.core\.app\.ServiceCompat\s*;[ \t]*\r?\n/gm, '');
  if (n !== t) {
    fs.writeFileSync(f, n);
    console.log('[patch] patched ' + f);
  }
}

const pkgDir = path.join(base, 'com', 'asterinet', 'react', 'bgactions');
fs.mkdirSync(pkgDir, { recursive: true });
const helper = [
  'package com.asterinet.react.bgactions;',
  '',
  'import android.app.Notification;',
  'import android.app.Service;',
  'import android.content.pm.ServiceInfo;',
  'import android.os.Build;',
  '',
  'final class ServiceCompat {',
  '    static void startForeground(Service service, int id, Notification notification, int type) {',
  '        if (Build.VERSION.SDK_INT >= 29) {',
  '            service.startForeground(id, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST);',
  '        } else {',
  '            service.startForeground(id, notification);',
  '        }',
  '    }',
  '',
  '    static void stopForeground(Service service, int flags) {',
  '        service.stopForeground(flags);',
  '    }',
  '}',
  '',
].join('\n');
fs.writeFileSync(path.join(pkgDir, 'ServiceCompat.java'), helper);
console.log('[patch] created ServiceCompat.java in ' + pkgDir);
