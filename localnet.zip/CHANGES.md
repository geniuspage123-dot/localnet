# LocalNet Connect v1.10.0 - canje-canje

## Sabo: src/gateway.js
- Haɗin TCP na dindindin zuwa Gateways (port 45460, newline-JSON). Duba bayanin protocol a saman fayil ɗin.
- Neman Gateway: sweep na subnet (Wi-Fi, hotspot 192.168.43.x, Wi-Fi Direct 192.168.49.x), .1/.254 na farko; ana tuna Gateways (ln_gateways) kuma ana haɗuwa kai tsaye.
- Auto-reconnect: backoff 1s→30s, ping/pong kowane 10s, watchdog yana gano barci (sleep gap), AppState 'active', canjin hanyar sadarwa.
- Tsaro: gw-hello/gw-hi kawai plain (public key); komai bayan haka encrypted (X25519+XSalsa20). Ana pin ɗin public key na Gateway (TOFU); idan ya canza -> "KEY CHANGED", ba a haɗuwa. Babu plain-text fallback.

## src/net.js
- Gateways suna bayyana a matsayin contacts (gw:true); aika/karɓar saƙo ta gateway.js.
- Lafiyar sockets: UDP/TCP server suna sake tashi da kansu idan sun mutu; gano barci (tick gap) -> restartSockets + gateway.wake().
- AppState 'active' -> wakeUp().

## src/direct.js
- resetWaits()/wake(): bayan barci ko dawowar app, ana manta cooldown/jitter ɗin da suka tsufa a nemi/join group nan take.

## Android (modules/localnet-service)
- LocalNetService: farawa da connectedDevice kawai (microphone type daga background yana jefa SecurityException a Android 14+, wanda tsohon code ke kashe service ɗin da shi); ana ƙara microphone a callMode() kawai.
- Sticky restart: yana karanta prefs; idan mai amfani ya fita (logout) ba a sake tada shi.
- bindWifi(): requestNetwork(TRANSPORT_WIFI, ba tare da INTERNET ba) + bindProcessToNetwork -> Android ba zai bar Wi-Fi na Gateway mara internet ba.
- WakeLock renew ba tare da gibi ba.
- Sabon: openAutoStartSettings (Xiaomi/Tecno/Infinix/Oppo/Vivo/Huawei/Samsung).

## modules/localnet-direct/LanAudio.kt
- WifiLock (LOW_LATENCY) + PARTIAL_WAKE_LOCK nasa na kira (an sakin su a stop(), lock na CPU yana da iyaka ta awa 4).
- Audio threads suna da URGENT_AUDIO priority.

## crypto.js / bridge.js
- Ba a taɓa su ba: tsarin encryption ɗin yana nan yadda yake.

## Iyakoki (a sani)
- Ba a gina/gwada HeadlessJS a waya ba tukuna (duba ƙasa).
- Ba a gina/gwada Kotlin a nan ba (babu Gradle); an gwada gateway.js da mock server (discovery, handshake, ack, reconnect).

## HeadlessJS keep-alive (sabo)
- index.js: `LocalNetKeepAlive` headless task yana kiran `net.init()` (sockets, gateways, crypto) ba tare da allo ba.
- LocalNetHeadlessService.kt + manifest: Android idan ya kashe process ya sake tada LocalNetService (START_STICKY), service ɗin yana tada headless task ɗin.
- net.init() yanzu yana farawa sau ɗaya kawai (headless da allo suna raba JS runtime ɗaya).
- Idan mai amfani ya fita (logout), ba a sake tada komai.
- Lura: bayan reboot na waya ba a tada service ɗin da kansa (ba a ƙara BootReceiver ba); sai an buɗe app sau ɗaya.

## UnitedApp: icon da saitin Gateway
- Icon, adaptive icon da splash: an yi amfani da hoton da aka bayar.
- Settings > Gateways: kowa yana saita nasa (suna, IP, port, password), yana canzawa kowane lokaci; ana nuna su a allo (password yana da "Show/Hide").
- Ana adana gateway ko da bai samu ba tukuna; app yana ci gaba da ƙoƙari ya haɗu da kansa.
- Password: gateway yana aika `auth:true` + `nonce`; waya tana amsawa da sha512(nonce|password|publicKey), ba a aika password ɗin kansa ba. Kuskure: "Password needed" / "Wrong password".
- Wayoyi masu IP ɗaya suna haɗuwa da gateway ɗaya a lokaci guda ba tare da katse juna ba (kowace waya tana da haɗinta).
