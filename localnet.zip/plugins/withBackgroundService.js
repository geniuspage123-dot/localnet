const { withAndroidManifest } = require('@expo/config-plugins');

module.exports = function withBackgroundService(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;
    manifest.$['xmlns:tools'] = manifest.$['xmlns:tools'] || 'http://schemas.android.com/tools';
    manifest['uses-permission'] = manifest['uses-permission'] || [];
    [
      'android.permission.FOREGROUND_SERVICE',
      'android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE',
      'android.permission.FOREGROUND_SERVICE_MICROPHONE',
      'android.permission.WAKE_LOCK',
    ].forEach((p) => {
      if (!manifest['uses-permission'].some((x) => x.$['android:name'] === p)) {
        manifest['uses-permission'].push({ $: { 'android:name': p } });
      }
    });
    const app = manifest.application[0];
    app.service = app.service || [];
    const name = 'com.asterinet.react.bgactions.RNBackgroundActionsTask';
    let svc = app.service.find((x) => x.$['android:name'] === name);
    if (!svc) { svc = { $: { 'android:name': name } }; app.service.push(svc); }
    svc.$['android:foregroundServiceType'] = 'connectedDevice|microphone';
    svc.$['tools:replace'] = 'android:foregroundServiceType';
    return cfg;
  });
};
