import React, { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList, ScrollView, Animated, Alert,
  BackHandler, Platform, useColorScheme, StatusBar as RNStatusBar,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Audio } from 'expo-av';
import * as Network from 'expo-network';
import * as Clipboard from 'expo-clipboard';
import * as Notifications from 'expo-notifications';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as net from './src/net';
import * as call from './src/call';
import * as notify from './src/notify';
import * as bg from './src/bg';
import { themes, makeStyles } from './src/theme';

const TOP = Platform.OS === 'android' ? (RNStatusBar.currentHeight || 24) : 44;
const AUTH = ['welcome', 'register', 'login'];
const VERSION = '1.3.0';

// Current theme: re-assigned at the start of every App render, before children render.
let C = themes.light;
let st = makeStyles(C, TOP);
const styleCache = {};

const PALETTE = ['#246bfd', '#7c3aed', '#db2777', '#ea580c', '#059669', '#0891b2', '#ca8a04', '#475569'];
const colorFor = (name) => { let h = 0; const n = String(name || '?'); for (let i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) | 0; return PALETTE[Math.abs(h) % PALETTE.length]; };

const isOnline = (c) => Date.now() - c.lastSeen < net.ONLINE_MS;
const hhmm = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const mmss = (secs) => Math.floor(secs / 60) + ':' + String(Math.max(0, Math.floor(secs % 60))).padStart(2, '0');
const preview = (m) => (m.kind === 'voice' ? '🎤 Voice note' : m.text);
const ago = (ts) => {
  const m = Math.floor((Date.now() - ts) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return m + ' min ago';
  const h = Math.floor(m / 60);
  if (h < 24) return h + ' h ago';
  return Math.floor(h / 24) + ' d ago';
};
const lastSeen = (u) => (isOnline(u) ? 'Online' : 'Last seen ' + ago(u.lastSeen));
const dayLabel = (ts) => {
  const d = new Date(ts); const t = new Date();
  if (d.toDateString() === t.toDateString()) return 'Today';
  const y = new Date(t.getTime() - 86400000);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
};

const REC_OPTS = {
  isMeteringEnabled: false,
  android: { extension: '.m4a', outputFormat: Audio.AndroidOutputFormat.MPEG_4, audioEncoder: Audio.AndroidAudioEncoder.AAC, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  ios: { extension: '.m4a', outputFormat: Audio.IOSOutputFormat.MPEG4AAC, audioQuality: Audio.IOSAudioQuality.LOW, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  web: {},
};

/* ---------- shared pieces ---------- */
function Avatar({ name, size = 45, radius = 15, font = 18 }) {
  return (
    <View style={{ width: size, height: size, borderRadius: radius, backgroundColor: colorFor(name), alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: font }}>{String(name || '?').slice(0, 1).toUpperCase()}</Text>
    </View>
  );
}

function Btn({ title, onPress, kind = 'primary', style, disabled }) {
  const k = {
    primary: [C.primary, '#fff', null], soft: [C.soft, C.primary, null], danger: [C.dangerBg, C.danger, null],
    green: [C.greenBg, C.green, null], outline: [C.card, C.text, C.inputLine],
  }[kind];
  return (
    <TouchableOpacity
      disabled={disabled}
      activeOpacity={0.75}
      onPress={onPress}
      style={[{ backgroundColor: k[0], borderRadius: 13, paddingVertical: 12, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.6 : 1 }, k[2] && { borderWidth: 1, borderColor: k[2] }, style]}
    >
      <Text style={{ color: k[1], fontWeight: '700', fontSize: 15 }}>{title}</Text>
    </TouchableOpacity>
  );
}

const Card = ({ children, style }) => <View style={[st.card, style]}>{children}</View>;

function Field({ label, ...props }) {
  return (
    <View style={{ marginBottom: 13 }}>
      <Text style={st.label}>{label}</Text>
      <TextInput style={st.input} placeholderTextColor={C.hint} autoCapitalize="none" autoCorrect={false} {...props} />
    </View>
  );
}

function Dot({ on }) {
  return <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: on ? C.dotOn : C.dotOff }} />;
}

function TopBar({ s }) {
  const nearby = Object.values(s.contacts).filter(isOnline).length;
  return (
    <View>
      <View style={st.top}>
        <Text style={st.brand}>LocalNet Connect</Text>
        <Text style={st.sub}>Private • {s.myIp ? (nearby ? nearby + ' nearby' : 'Local Wi-Fi') : 'Not connected'}</Text>
      </View>
      {!s.myIp && (
        <View style={st.banner}><Text style={st.bannerTxt}>No Wi-Fi connection. Connect to Wi-Fi or turn on a hotspot to find people.</Text></View>
      )}
    </View>
  );
}

function Header({ title, subtitle, right }) {
  return (
    <View style={[st.row, { justifyContent: 'space-between', marginBottom: 14 }]}>
      <View style={st.flex}>
        <Text style={st.h2}>{title}</Text>
        {!!subtitle && <Text style={st.smallMuted}>{subtitle}</Text>}
      </View>
      {right}
    </View>
  );
}

/* ---------- root ---------- */
export default function App() {
  const system = useColorScheme();
  const [pref, setPref] = useState('system');
  const mode = pref === 'system' ? (system === 'dark' ? 'dark' : 'light') : pref;
  C = themes[mode];
  st = styleCache[mode] || (styleCache[mode] = makeStyles(C, TOP));

  const s = useSyncExternalStore(net.subscribe, net.getSnapshot);
  const cs = useSyncExternalStore(call.subscribe, call.getSnapshot);
  const [route, setRoute] = useState({ name: 'welcome' });
  const [toastTxt, setToastTxt] = useState('');
  const toastTimer = useRef(null);
  const prevCall = useRef(null);

  const toast = (t) => {
    setToastTxt(t);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastTxt(''), 2200);
  };

  let r = route;
  if (s.session && AUTH.includes(r.name)) r = { name: 'contacts' };
  if (!s.session && !AUTH.includes(r.name)) r = { name: 'welcome' };
  const rRef = useRef(r);
  rRef.current = r;
  const go = (name, id) => setRoute({ name, id });

  useEffect(() => {
    call.init();
    net.init();
    AsyncStorage.getItem('ln_theme').then((v) => { if (v) setPref(v); }).catch(() => {});
  }, []);
  const choosePref = (v) => { setPref(v); AsyncStorage.setItem('ln_theme', v).catch(() => {}); };

  // permissions + background service while signed in
  useEffect(() => {
    if (!s.session) { bg.stopService(); return; }
    (async () => {
      await notify.setup();
      if (await bg.ensureMic()) await bg.startService();
    })();
  }, [s.session]);

  // tap on a notification opens that chat
  useEffect(() => {
    const sub = Notifications.addNotificationResponseReceivedListener((resp) => {
      const id = resp && resp.notification.request.content.data && resp.notification.request.content.data.peerId;
      if (id) setRoute({ name: 'chat', id });
    });
    return () => sub.remove();
  }, []);

  const chatId = r.name === 'chat' ? r.id : null;
  useEffect(() => { net.setActive(chatId); }, [chatId]);
  useEffect(() => {
    if (prevCall.current && !cs.call) toast('Call ended');
    prevCall.current = cs.call;
  }, [cs.call]);
  useEffect(() => {
    const h = BackHandler.addEventListener('hardwareBackPress', () => {
      const cur = rRef.current.name;
      if (cur === 'chat') { setRoute({ name: 'messages' }); return true; }
      if (cur === 'register' || cur === 'login') { setRoute({ name: 'welcome' }); return true; }
      return false;
    });
    return () => h.remove();
  }, []);

  if (!s.ready) return <View style={{ flex: 1, backgroundColor: C.bg }} />;

  let body;
  if (r.name === 'welcome') body = <Welcome go={go} />;
  else if (r.name === 'register') body = <Register go={go} />;
  else if (r.name === 'login') body = <Login go={go} />;
  else if (r.name === 'chat' && s.contacts[r.id]) body = <Chat s={s} id={r.id} go={go} toast={toast} />;
  else if (r.name === 'messages') body = <Messages s={s} go={go} />;
  else if (r.name === 'calls') body = <Calls s={s} go={go} />;
  else if (r.name === 'settings') body = <Settings s={s} pref={pref} setPref={choosePref} toast={toast} />;
  else body = <Contacts s={s} go={go} />;

  const unreadTotal = Object.values(s.messages).reduce((n, list) => n + (list || []).filter((m) => !m.mine && !m.read && m.kind !== 'call').length, 0);
  const tab = r.name === 'chat' ? 'messages' : r.name;
  const inCall = !!(s.session && cs.call);
  return (
    <View style={{ flex: 1, backgroundColor: C.bg }}>
      <StatusBar style={mode === 'dark' ? 'light' : 'dark'} backgroundColor={AUTH.includes(r.name) ? C.bg : C.top} />
      <View style={st.flex}>{body}</View>
      {s.session && <Nav tab={tab} go={go} unread={unreadTotal} />}
      {inCall && <CallScreen cs={cs} />}
      {!!toastTxt && <View style={st.toast}><Text style={st.toastTxt}>{toastTxt}</Text></View>}
    </View>
  );
}

function Nav({ tab, go, unread }) {
  const items = [['contacts', '◉', 'Contacts'], ['messages', '◌', 'Messages'], ['calls', '⌕', 'Calls'], ['settings', '⚙', 'Settings']];
  return (
    <View style={st.nav}>
      {items.map(([k, ic, label]) => (
        <TouchableOpacity key={k} style={[st.navItem, tab === k && { backgroundColor: C.soft }]} onPress={() => go(k)}>
          <Text style={[st.navIcon, { color: tab === k ? C.primary : C.muted }]}>{ic}</Text>
          <Text style={[st.navLbl, { color: tab === k ? C.primary : C.muted }]}>{label}</Text>
          {k === 'messages' && unread > 0 && <View style={st.navBadge}><Text style={st.badgeTxt}>{unread > 99 ? '99+' : unread}</Text></View>}
        </TouchableOpacity>
      ))}
    </View>
  );
}

/* ---------- auth ---------- */
function Welcome({ go }) {
  return (
    <ScrollView style={{ backgroundColor: C.bg }} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24, paddingTop: TOP + 20 }}>
      <View style={{ alignItems: 'center' }}>
        <View style={st.heroIcon}><Text style={{ color: '#fff', fontSize: 38, fontWeight: '900' }}>⌁</Text></View>
        <Text style={st.h1Big}>LocalNet Connect</Text>
        <Text style={[st.mutedTxt, { textAlign: 'center', lineHeight: 24, marginTop: 8 }]}>Private chat and voice calls on the same local Wi-Fi network.</Text>
      </View>
      <Card style={{ padding: 18, marginTop: 22 }}>
        <View style={st.row}>
          <Text style={{ fontSize: 20 }}>📲</Text>
          <View style={st.flex}><Text style={st.bold}>Share the app</Text><Text style={st.smallMuted}>Send this APK to friends with Xender or Bluetooth.</Text></View>
        </View>
        <View style={{ height: 1, backgroundColor: C.divider, marginVertical: 16 }} />
        <View style={st.row}>
          <Text style={{ fontSize: 20 }}>🔒</Text>
          <View style={st.flex}><Text style={st.bold}>No server needed</Text><Text style={st.smallMuted}>Phones on the same Wi-Fi find each other automatically.</Text></View>
        </View>
      </Card>
      <Btn title="Create account" onPress={() => go('register')} style={{ marginTop: 22 }} />
      <Btn title="Log in" kind="outline" onPress={() => go('login')} style={{ marginTop: 14 }} />
      <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 18 }]}>
        Already registered? <Text style={{ fontWeight: '700', color: C.primary }} onPress={() => go('login')}>Sign in here</Text>
      </Text>
    </ScrollView>
  );
}

function ErrorBox({ text }) {
  if (!text) return null;
  return <View style={[st.card, { padding: 12, marginVertical: 15, backgroundColor: C.dangerBg }]}><Text style={{ color: C.danger }}>{text}</Text></View>;
}

function Register({ go }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  return (
    <ScrollView style={{ backgroundColor: C.bg }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 18, paddingTop: TOP + 14 }}>
      <Text style={st.mutedTxt} onPress={() => go('welcome')}>‹ Back</Text>
      <Text style={st.h1}>Create account</Text>
      <Text style={st.mutedTxt}>Your local identity appears to other users on this Wi-Fi.</Text>
      <ErrorBox text={error} />
      <Card style={{ padding: 18, marginTop: 18 }}>
        <Field label="Full name" value={name} onChangeText={setName} maxLength={60} autoCapitalize="words" />
        <Field label="Username" value={username} onChangeText={setUsername} maxLength={30} placeholder="e.g. ahmad" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        <Btn title="Create account" onPress={async () => setError((await net.register({ name, username, password })) || '')} style={{ marginTop: 5 }} />
        <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 15 }]}>
          Already have an account? <Text style={{ fontWeight: '700', color: C.primary }} onPress={() => go('login')}>Log in</Text>
        </Text>
      </Card>
    </ScrollView>
  );
}

function Login({ go }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  return (
    <ScrollView style={{ backgroundColor: C.bg }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 18, paddingTop: TOP + 30 }}>
      <Text style={st.mutedTxt} onPress={() => go('welcome')}>‹ Back</Text>
      <View style={{ alignItems: 'center', marginVertical: 26 }}>
        <View style={{ width: 70, height: 70, borderRadius: 22, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontSize: 25, fontWeight: '800' }}>⌁</Text>
        </View>
        <Text style={st.h1}>Welcome back</Text>
        <Text style={st.mutedTxt}>Sign in to your LocalNet account.</Text>
      </View>
      <ErrorBox text={error} />
      <Card style={{ padding: 18 }}>
        <Field label="Username" value={username} onChangeText={setUsername} />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        <Btn title="Sign in" onPress={async () => setError((await net.login({ username, password })) || '')} />
      </Card>
    </ScrollView>
  );
}

/* ---------- tabs ---------- */
const sortContacts = (s) => Object.values(s.contacts).sort((a, b) => (isOnline(b) - isOnline(a)) || (b.lastSeen - a.lastSeen));

function Contacts({ s, go }) {
  const [q, setQ] = useState('');
  const list = sortContacts(s).filter((u) => (u.name + ' ' + u.username).toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <FlatList
        data={list}
        keyExtractor={(u) => u.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={
          <View style={{ marginBottom: 4 }}>
            <Header title="Contacts" subtitle="Everyone nearby on this Wi-Fi." right={<Avatar name={s.me.name} />} />
            <TextInput style={st.input} placeholder="Search people…" placeholderTextColor={C.hint} value={q} onChangeText={setQ} />
          </View>
        }
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{ fontSize: 42, color: C.muted }}>◎</Text>
            <Text style={st.bold}>No one nearby yet</Text>
            <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 6, lineHeight: 18 }]}>
              Install the app on another phone, create an account, and connect both phones to the same Wi-Fi or hotspot.
            </Text>
          </View>
        }
        renderItem={({ item: u }) => (
          <Card style={{ padding: 13 }}>
            <View style={st.row}>
              <Avatar name={u.name} />
              <View style={st.flex}>
                <Text style={st.bold}>{u.name}</Text>
                <View style={[st.row, { gap: 6 }]}><Dot on={isOnline(u)} /><Text numberOfLines={1} style={[st.smallMuted, st.flex]}>{lastSeen(u)} · @{u.username}</Text></View>
              </View>
              <Btn title="Chat" kind="soft" onPress={() => go('chat', u.id)} />
              <Btn title="Call" kind="green" onPress={() => call.startCall(u.id)} />
            </View>
          </Card>
        )}
      />
    </View>
  );
}

function Messages({ s, go }) {
  const convs = Object.keys(s.messages)
    .filter((id) => s.contacts[id] && (s.messages[id] || []).some((m) => m.kind !== 'call'))
    .map((id) => {
      const list = s.messages[id].filter((m) => m.kind !== 'call');
      return { c: s.contacts[id], last: list[list.length - 1], unread: list.filter((m) => !m.mine && !m.read).length };
    })
    .sort((a, b) => b.last.ts - a.last.ts);
  const askClear = (c) => Alert.alert('Delete conversation?', 'This removes the chat with ' + c.name + ' from this phone only.', [
    { text: 'Cancel', style: 'cancel' },
    { text: 'Delete', style: 'destructive', onPress: () => net.clearChat(c.id) },
  ]);
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <FlatList
        data={convs}
        keyExtractor={(x) => x.c.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={<Header title="Messages" subtitle="Your private conversations. Long-press to delete." />}
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{ fontSize: 42, color: C.muted }}>◌</Text>
            <Text style={st.bold}>No conversations yet</Text>
            <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 6 }]}>Open Contacts and start a private chat.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <TouchableOpacity activeOpacity={0.8} onPress={() => go('chat', item.c.id)} onLongPress={() => askClear(item.c)}>
            <Card style={{ padding: 14 }}>
              <View style={st.row}>
                <View>
                  <Avatar name={item.c.name} />
                  <View style={{ position: 'absolute', right: -2, bottom: -2, borderWidth: 2, borderColor: C.card, borderRadius: 7 }}><Dot on={isOnline(item.c)} /></View>
                </View>
                <View style={st.flex}>
                  <View style={[st.row, { justifyContent: 'space-between' }]}>
                    <Text style={[st.bold, st.flex]} numberOfLines={1}>{item.c.name}</Text>
                    <Text style={[st.smallMuted, item.unread > 0 && { color: C.primary, fontWeight: '700' }]}>{hhmm(item.last.ts)}</Text>
                  </View>
                  <View style={[st.row, { justifyContent: 'space-between' }]}>
                    <Text numberOfLines={1} style={[st.smallMuted, st.flex, item.unread > 0 && { color: C.text, fontWeight: '600' }]}>
                      {item.last.mine ? 'You: ' : ''}{preview(item.last)}
                    </Text>
                    {item.unread > 0 && <View style={st.badge}><Text style={st.badgeTxt}>{item.unread}</Text></View>}
                  </View>
                </View>
              </View>
            </Card>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function Calls({ s, go }) {
  const list = sortContacts(s);
  const recents = [];
  Object.keys(s.messages).forEach((id) => {
    if (!s.contacts[id]) return;
    (s.messages[id] || []).forEach((m) => { if (m.kind === 'call') recents.push({ c: s.contacts[id], m }); });
  });
  recents.sort((a, b) => b.m.ts - a.m.ts);
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <FlatList
        data={list}
        keyExtractor={(u) => u.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={
          <View>
            <Header title="Voice Calls" subtitle="Select one person. Calls stay on the local network." />
            {recents.length > 0 && (
              <View>
                <Text style={st.h3}>RECENT</Text>
                <Card style={{ paddingVertical: 4 }}>
                  {recents.slice(0, 6).map(({ c, m }, i) => {
                    const missed = m.outcome === 'missed';
                    return (
                      <TouchableOpacity key={m.id} activeOpacity={0.7} onPress={() => call.startCall(c.id)} style={[st.row, { paddingVertical: 11, paddingHorizontal: 14, borderTopWidth: i ? 1 : 0, borderTopColor: C.divider }]}>
                        <Text style={{ fontSize: 18, fontWeight: '800', color: missed ? C.danger : m.dir === 'out' ? C.primary : C.green }}>{m.dir === 'out' ? '↗' : '↙'}</Text>
                        <View style={st.flex}>
                          <Text style={[st.bold, missed && { color: C.danger }]}>{c.name}</Text>
                          <Text style={st.smallMuted}>{m.text.replace('📞 ', '')} · {dayLabel(m.ts)}, {hhmm(m.ts)}</Text>
                        </View>
                        <Text style={{ color: C.green, fontSize: 18 }}>📞</Text>
                      </TouchableOpacity>
                    );
                  })}
                </Card>
              </View>
            )}
            <Text style={st.h3}>CONTACTS</Text>
          </View>
        }
        ListEmptyComponent={<View style={st.empty}><Text style={st.bold}>No contacts available</Text><Text style={[st.smallMuted, { marginTop: 6 }]}>People on your Wi-Fi will appear here.</Text></View>}
        renderItem={({ item: u }) => (
          <Card style={{ padding: 13 }}>
            <View style={st.row}>
              <Avatar name={u.name} />
              <View style={st.flex}>
                <Text style={st.bold}>{u.name}</Text>
                <Text style={st.smallMuted}>{isOnline(u) ? '● Online' : '○ ' + lastSeen(u)} · @{u.username}</Text>
              </View>
              <Btn title="Call" kind="green" onPress={() => call.startCall(u.id)} />
            </View>
          </Card>
        )}
      />
    </View>
  );
}

function Settings({ s, pref, setPref, toast }) {
  const [ip, setIp] = useState('');
  const [name, setName] = useState(s.me.name);
  const [running, setRunning] = useState(bg.isRunning());
  useEffect(() => { Network.getIpAddressAsync().then(setIp).catch(() => {}); }, []);
  const startBg = async () => {
    await notify.setup();
    if (!(await bg.ensureMic())) { toast('Allow the Microphone permission to run in the background.'); return; }
    setRunning(await bg.startService());
  };
  const opts = [['system', 'System'], ['light', 'Light'], ['dark', 'Dark']];
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 16, paddingBottom: 30 }}>
        <Text style={[st.h2, { marginBottom: 14 }]}>Settings</Text>
        <Card style={{ padding: 16 }}>
          <View style={st.row}>
            <Avatar name={s.me.name} size={52} radius={17} font={20} />
            <View><Text style={st.bold}>{s.me.name}</Text><Text style={st.smallMuted}>@{s.me.username}</Text></View>
          </View>
          <View style={[st.row, { marginTop: 14 }]}>
            <TextInput style={[st.input, st.flex]} value={name} onChangeText={setName} maxLength={60} placeholder="Display name" placeholderTextColor={C.hint} />
            <Btn title="Save" kind="soft" onPress={() => { net.updateName(name); toast('Name updated'); }} />
          </View>
        </Card>

        <Text style={st.h3}>APPEARANCE</Text>
        <View style={st.seg}>
          {opts.map(([k, label]) => (
            <TouchableOpacity key={k} style={[st.segItem, pref === k && { backgroundColor: C.card, elevation: 1 }]} onPress={() => setPref(k)}>
              <Text style={{ fontWeight: '700', color: pref === k ? C.primary : C.muted }}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={st.h3}>BACKGROUND</Text>
        <Card style={{ padding: 16 }}>
          <View style={[st.row, { justifyContent: 'space-between' }]}>
            <View style={st.flex}>
              <Text style={st.bold}>Stay connected</Text>
              <Text style={st.smallMuted}>{running ? 'Active: you can receive messages and calls when the screen is off.' : 'Off: messages and calls only arrive while the app is open.'}</Text>
            </View>
            <Dot on={running} />
          </View>
          {!running && <Btn title="Turn on" onPress={startBg} style={{ marginTop: 12 }} />}
          <Btn title="Battery settings" kind="soft" onPress={bg.openBatterySettings} style={{ marginTop: 10 }} />
          <Text style={[st.smallMuted, { marginTop: 8, lineHeight: 17 }]}>Tip: set LocalNet Connect to "Unrestricted" or "Don't optimize" so the phone does not stop it.</Text>
        </Card>

        <Text style={st.h3}>NETWORK</Text>
        <Card style={{ padding: 16 }}>
          <Text style={st.smallMuted}>Your phone's address on this Wi-Fi</Text>
          <View style={{ padding: 12, backgroundColor: C.box, borderRadius: 12, marginTop: 8 }}><Text style={{ fontWeight: '700', color: C.text }}>{ip && ip !== '0.0.0.0' ? ip : 'Not connected'}</Text></View>
          <Text style={[st.smallMuted, { marginTop: 8, lineHeight: 17 }]}>No host or server needed. Phones on the same Wi-Fi or hotspot find each other automatically.</Text>
        </Card>

        <Btn title="Sign out" kind="danger" onPress={() => net.logout()} style={{ marginTop: 20 }} />
        <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 14 }]}>LocalNet Connect v{VERSION}</Text>
      </ScrollView>
    </View>
  );
}

/* ---------- voice + chat ---------- */
function VoiceBubble({ uri, dur, mine }) {
  const [playing, setPlaying] = useState(false);
  const snd = useRef(null);
  useEffect(() => () => { snd.current && snd.current.unloadAsync().catch(() => {}); }, []);
  const toggle = async () => {
    try {
      if (snd.current) {
        const t = await snd.current.getStatusAsync();
        if (t.isLoaded && t.isPlaying) { await snd.current.pauseAsync(); setPlaying(false); return; }
        if (t.isLoaded) {
          if (t.positionMillis >= (t.durationMillis || 1) - 50) await snd.current.setPositionAsync(0);
          await snd.current.playAsync();
          setPlaying(true);
          return;
        }
      }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
      const { sound } = await Audio.Sound.createAsync({ uri }, { shouldPlay: true }, (u) => {
        if (u.isLoaded && u.didJustFinish) setPlaying(false);
      });
      snd.current = sound;
      setPlaying(true);
    } catch (e) { setPlaying(false); }
  };
  const fg = mine ? '#fff' : C.primary;
  return (
    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', minWidth: 190 }} onPress={toggle}>
      <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: mine ? '#fff' : C.soft, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: C.primary, fontSize: 13 }}>{playing ? '❚❚' : '▶'}</Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, marginHorizontal: 10, height: 20 }}>
        {[6, 12, 8, 16, 10, 14, 7, 12, 9, 15, 6, 11].map((h, i) => (
          <View key={i} style={{ width: 3, height: h, borderRadius: 2, marginRight: 3, backgroundColor: fg, opacity: 0.75 }} />
        ))}
      </View>
      <Text style={{ fontSize: 12, color: mine ? '#ffffffcc' : C.muted }}>{mmss((dur || 0) / 1000)}</Text>
    </TouchableOpacity>
  );
}

function Ticks({ m }) {
  if (!m.mine) return null;
  if (m.status === 'failed') return <Text style={{ color: '#ffd1d5', fontSize: 10, fontWeight: '700' }}> ! tap to retry</Text>;
  if (m.status === 'read') return <Text style={{ color: '#8df0ff', fontSize: 11, fontWeight: '800' }}> ✓✓</Text>;
  if (m.status === 'delivered') return <Text style={{ color: '#ffffffaa', fontSize: 11, fontWeight: '800' }}> ✓✓</Text>;
  return <Text style={{ color: '#ffffffaa', fontSize: 10 }}> …</Text>;
}

function Chat({ s, id, go, toast }) {
  const c = s.contacts[id];
  const list = s.messages[id] || [];
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [voice, setVoice] = useState(null);
  const recRef = useRef(null);
  const ref = useRef(null);
  const on = isOnline(c);
  const typing = Date.now() - (c.typingAt || 0) < 4000;

  useEffect(() => {
    if (!recording) return undefined;
    const t = setInterval(() => setRecSecs((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);
  useEffect(() => () => { if (recRef.current) recRef.current.stopAndUnloadAsync().catch(() => {}); }, []);

  const items = [];
  let lastDayStr = '';
  list.forEach((m) => {
    const d = new Date(m.ts).toDateString();
    if (d !== lastDayStr) { items.push({ id: 'sep-' + d, kind: 'sep', ts: m.ts }); lastDayStr = d; }
    items.push(m);
  });

  const send = () => {
    if (!text.trim()) return;
    net.sendMessage(id, text);
    setText('');
  };

  const stopRec = async (keep) => {
    const r = recRef.current;
    recRef.current = null;
    setRecording(false);
    if (!r) return;
    try {
      const t = await r.getStatusAsync();
      await r.stopAndUnloadAsync();
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
      if (!keep) return;
      const uri = r.getURI();
      if (!uri || !(t.durationMillis > 700)) { toast('No audio was recorded. Please try again.'); return; }
      setVoice({ uri, dur: t.durationMillis });
    } catch (e) { toast('Could not finish recording.'); }
  };

  const startRec = async () => {
    try {
      const p = await Audio.requestPermissionsAsync();
      if (!p.granted) { toast('Microphone permission is blocked. Allow Microphone in phone settings for this app.'); return; }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const r = new Audio.Recording();
      await r.prepareToRecordAsync(REC_OPTS);
      await r.startAsync();
      recRef.current = r;
      setRecSecs(0);
      setRecording(true);
    } catch (e) { setRecording(false); toast('Could not start microphone.'); }
  };

  const onLong = (m) => {
    const buttons = [];
    if (m.kind !== 'voice') buttons.push({ text: 'Copy', onPress: () => { Clipboard.setStringAsync(m.text); toast('Copied'); } });
    buttons.push({ text: 'Delete for me', style: 'destructive', onPress: () => net.deleteMessage(id, m.id) });
    buttons.push({ text: 'Cancel', style: 'cancel' });
    Alert.alert('Message', undefined, buttons);
  };

  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <View style={[st.top, st.row]}>
        <TouchableOpacity onPress={() => go('messages')} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={{ fontSize: 28, color: C.text, lineHeight: 30 }}>‹</Text>
        </TouchableOpacity>
        <Avatar name={c.name} size={38} radius={12} font={16} />
        <View style={st.flex}>
          <Text style={st.bold} numberOfLines={1}>{c.name}</Text>
          <Text style={[st.smallMuted, typing && { color: C.green, fontWeight: '700' }]}>{typing ? 'typing…' : lastSeen(c)}</Text>
        </View>
        <TouchableOpacity onPress={() => call.startCall(id)} style={{ width: 40, height: 40, borderRadius: 13, backgroundColor: C.greenBg, alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ fontSize: 18 }}>📞</Text>
        </TouchableOpacity>
      </View>
      <FlatList
        ref={ref}
        data={items}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: 16, gap: 6 }}
        onContentSizeChange={() => ref.current && ref.current.scrollToEnd({ animated: false })}
        ListEmptyComponent={<View style={st.empty}><Text style={{ fontSize: 40 }}>👋</Text><Text style={[st.smallMuted, { marginTop: 8 }]}>Say hello to {c.name}</Text></View>}
        renderItem={({ item }) => {
          if (item.kind === 'sep') return <View style={st.sepWrap}><Text style={st.sepTxt}>{dayLabel(item.ts)}</Text></View>;
          if (item.kind === 'call') return <Text style={st.callNote}>{item.text} · {hhmm(item.ts)}</Text>;
          const failed = item.mine && item.status === 'failed';
          return (
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() => failed && net.retry(id, item.id)}
              onLongPress={() => onLong(item)}
              style={[st.bubble, item.mine ? st.mine : st.theirs]}
            >
              {item.kind === 'voice'
                ? <VoiceBubble uri={item.uri} dur={item.dur} mine={item.mine} />
                : <Text style={{ fontSize: 15, lineHeight: 21, color: item.mine ? '#fff' : C.text }}>{item.text}</Text>}
              <View style={{ flexDirection: 'row', alignSelf: 'flex-end', alignItems: 'center', marginTop: 3 }}>
                <Text style={{ fontSize: 10, opacity: 0.7, color: item.mine ? '#fff' : C.muted }}>{hhmm(item.ts)}</Text>
                <Ticks m={item} />
              </View>
            </TouchableOpacity>
          );
        }}
      />
      {voice ? (
        <View style={st.voicePanel}>
          <Text style={st.bold}>Voice note preview</Text>
          <View style={{ marginVertical: 10 }}><VoiceBubble uri={voice.uri} dur={voice.dur} mine={false} /></View>
          <View style={[st.row, { gap: 8 }]}>
            <Btn title="Cancel" kind="soft" style={st.flex} onPress={() => setVoice(null)} />
            <Btn title="Send voice note" style={st.flex} onPress={() => { net.sendVoice(id, voice.uri, voice.dur); setVoice(null); }} />
          </View>
        </View>
      ) : recording ? (
        <View style={st.composer}>
          <TouchableOpacity onPress={() => stopRec(false)} style={[st.record, { backgroundColor: C.box }]}><Text style={{ fontSize: 16, color: C.muted }}>✕</Text></TouchableOpacity>
          <View style={[st.input, st.flex, { flexDirection: 'row', alignItems: 'center', gap: 8, height: 46 }]}>
            <View style={{ width: 10, height: 10, borderRadius: 5, backgroundColor: C.danger }} />
            <Text style={{ color: C.danger, fontSize: 15, fontWeight: '700' }}>Recording {mmss(recSecs)}</Text>
          </View>
          <TouchableOpacity onPress={() => stopRec(true)} style={[st.record, { backgroundColor: C.dangerBg }]}><Text style={{ fontSize: 17, color: C.danger }}>■</Text></TouchableOpacity>
        </View>
      ) : (
        <View style={st.composer}>
          <TouchableOpacity onPress={startRec} style={st.record}><Text style={{ fontSize: 18 }}>🎙</Text></TouchableOpacity>
          <TextInput
            style={[st.input, st.flex]}
            placeholder="Message…"
            placeholderTextColor={C.hint}
            value={text}
            onChangeText={(v) => { setText(v); if (v) net.sendTyping(id); }}
            onSubmitEditing={send}
          />
          <Btn title="Send" onPress={send} />
        </View>
      )}
    </View>
  );
}

/* ---------- calls ---------- */
function Pulse({ active, delay = 0 }) {
  const a = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!active) return undefined;
    const loop = Animated.loop(Animated.sequence([
      Animated.delay(delay),
      Animated.timing(a, { toValue: 1, duration: 1800, useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [active]);
  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute', width: 130, height: 130, borderRadius: 44, backgroundColor: '#4c8dff',
        opacity: a.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0] }),
        transform: [{ scale: a.interpolate({ inputRange: [0, 1], outputRange: [1, 2] }) }],
      }}
    />
  );
}

function CtlBtn({ icon, label, bgc, onPress, active }) {
  return (
    <View style={{ alignItems: 'center' }}>
      <TouchableOpacity onPress={onPress} activeOpacity={0.8} style={[st.callBtn, { backgroundColor: active ? '#ffffff' : bgc }]}>
        <Text style={{ fontSize: 26, color: active ? '#0b1220' : '#fff' }}>{icon}</Text>
      </TouchableOpacity>
      <Text style={{ color: '#9fb0c8', fontSize: 12, marginTop: 8 }}>{label}</Text>
    </View>
  );
}

function CallScreen({ cs }) {
  const c = cs.call;
  const incoming = c.dir === 'in' && c.status === 'ringing';
  const ringing = c.status === 'calling' || c.status === 'ringing';
  const label = {
    preparing: 'Preparing call…',
    calling: 'Ringing…',
    ringing: 'Incoming voice call',
    connecting: 'Connecting…',
    connected: mmss((cs.now - c.since) / 1000),
    lost: 'Connection lost — check both phones are on the same Wi-Fi',
  }[c.status] || '';
  return (
    <View style={st.callFull}>
      <StatusBar style="light" />
      <View style={{ alignItems: 'center' }}>
        <Text style={{ color: '#9fb0c8', fontSize: 13, letterSpacing: 1 }}>LOCALNET VOICE CALL</Text>
        <View style={{ marginTop: 56, width: 130, height: 130, alignItems: 'center', justifyContent: 'center' }}>
          <Pulse active={ringing} />
          <Pulse active={ringing} delay={900} />
          <Avatar name={c.name} size={130} radius={44} font={52} />
        </View>
        <Text style={{ color: '#fff', fontSize: 30, fontWeight: '800', marginTop: 30 }}>{c.name}</Text>
        <Text style={{ color: '#9fb0c8', fontSize: 17, marginTop: 8, textAlign: 'center', paddingHorizontal: 30 }}>{label}</Text>
      </View>
      {incoming ? (
        <View style={st.callCtl}>
          <CtlBtn icon="✕" label="Decline" bgc="#e5484d" onPress={call.decline} />
          <CtlBtn icon="📞" label="Answer" bgc="#22b573" onPress={call.answer} />
        </View>
      ) : (
        <View style={st.callCtl}>
          <CtlBtn icon={c.muted ? '🔇' : '🎙'} label={c.muted ? 'Unmute' : 'Mute'} bgc="#ffffff22" active={c.muted} onPress={call.toggleMute} />
          <CtlBtn icon="✕" label="End" bgc="#e5484d" onPress={call.hangup} />
          <CtlBtn icon="🔊" label="Speaker" bgc="#ffffff22" active={c.speaker} onPress={call.toggleSpeaker} />
        </View>
      )}
    </View>
  );
}
