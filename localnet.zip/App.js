import React, { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import {
  Alert, AppState,
  View, Text, TextInput, TouchableOpacity, FlatList, ScrollView, StyleSheet,
  BackHandler, Platform, StatusBar as RNStatusBar,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Audio } from 'expo-av';
import * as Network from 'expo-network';
import * as net from './src/net';
import * as call from './src/call';
import * as native from './src/native';
import * as direct from './src/direct';
import AsyncStorage from '@react-native-async-storage/async-storage';

const C = {
  bg: '#f8f9fb', card: '#ffffff', line: '#e8ebef', primary: '#246bfd', soft: '#edf3ff',
  dangerBg: '#ffe9ea', danger: '#d92d3b', greenBg: '#eaf8f1', green: '#15945d',
  muted: '#7b8593', text: '#17202a', dotOn: '#22b573', dotOff: '#b7c0ca', inputLine: '#dfe4ea',
};
const TOP = Platform.OS === 'android' ? (RNStatusBar.currentHeight || 24) : 44;
const AUTH = ['welcome', 'register', 'login'];

const isOnline = (c) => Date.now() - c.lastSeen < net.ONLINE_MS;
const ago = (ts) => {
  const m = Math.floor((Date.now() - ts) / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return m + ' min ago';
  const h = Math.floor(m / 60);
  if (h < 24) return h + ' h ago';
  return Math.floor(h / 24) + ' d ago';
};
const lastSeen = (u) => (isOnline(u) ? 'Online' : !u.lastSeen ? 'Not nearby right now' : 'Last seen ' + ago(u.lastSeen));
const dayLabel = (ts) => {
  const d = new Date(ts);
  const t = new Date();
  if (d.toDateString() === t.toDateString()) return 'Today';
  const y = new Date(t.getTime() - 86400000);
  if (d.toDateString() === y.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
};
const hhmm = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const mmss = (secs) => Math.floor(secs / 60) + ':' + String(Math.max(0, Math.floor(secs % 60))).padStart(2, '0');
const preview = (m) => (m.kind === 'voice' ? '🎤 Voice note' : m.text);

const REC_OPTS = {
  isMeteringEnabled: false,
  android: { extension: '.m4a', outputFormat: Audio.AndroidOutputFormat.MPEG_4, audioEncoder: Audio.AndroidAudioEncoder.AAC, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  ios: { extension: '.m4a', outputFormat: Audio.IOSOutputFormat.MPEG4AAC, audioQuality: Audio.IOSAudioQuality.LOW, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  web: {},
};

/* ---------- small shared pieces ---------- */
function Avatar({ name, size = 45, radius = 15, font = 18 }) {
  return (
    <View style={{ width: size, height: size, borderRadius: radius, backgroundColor: '#3f7bfd', alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ color: '#fff', fontWeight: '800', fontSize: font }}>{String(name || '?').slice(0, 1).toUpperCase()}</Text>
    </View>
  );
}

function Btn({ title, onPress, kind = 'primary', style, disabled }) {
  const k = {
    primary: [C.primary, '#fff', null], soft: [C.soft, C.primary, null], danger: [C.dangerBg, C.danger, null],
    green: [C.greenBg, C.green, null], outline: ['#fff', '#172033', '#dfe4ec'],
  }[kind];
  return (
    <TouchableOpacity
      disabled={disabled}
      onPress={onPress}
      style={[{ backgroundColor: k[0], borderRadius: 13, paddingVertical: 12, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.6 : 1 }, k[2] && { borderWidth: 1, borderColor: k[2] }, style]}
    >
      <Text style={{ color: k[1], fontWeight: '700', fontSize: 15 }}>{title}</Text>
    </TouchableOpacity>
  );
}

const Card = ({ children, style }) => <View style={[st.card, style]}>{children}</View>;

function Field({ label, ...props }) {
  return (
    <View style={{ marginBottom: 13 }}>
      <Text style={st.label}>{label}</Text>
      <TextInput style={st.input} placeholderTextColor="#a3acb9" autoCapitalize="none" autoCorrect={false} {...props} />
    </View>
  );
}

function TopBar({ s }) {
  const nearby = s ? Object.values(s.contacts).filter(isOnline).length : 0;
  const label = !s ? 'Local Wi-Fi' : s.direct ? 'Direct Wi-Fi' + (nearby ? ' • ' + nearby + ' nearby' : '') : s.myIp ? (nearby ? nearby + ' nearby' : 'Local Wi-Fi') : 'Not connected to Wi-Fi';
  return (
    <View style={st.top}>
      <Text style={st.brand}>LocalNet Connect</Text>
      <Text style={st.sub}>Private • {label}</Text>
    </View>
  );
}

function Dot({ on }) {
  return <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: on ? C.dotOn : C.dotOff }} />;
}

/* ---------- root ---------- */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  render() {
    if (this.state.error) {
      const msg = String((this.state.error && this.state.error.message) || this.state.error).slice(0, 200);
      return (
        <View style={{ flex: 1, backgroundColor: '#f8f9fb', alignItems: 'center', justifyContent: 'center', padding: 28 }}>
          <Text style={{ fontSize: 40 }}>⚠️</Text>
          <Text style={{ fontSize: 20, fontWeight: '800', color: '#17202a', marginTop: 12 }}>Something went wrong</Text>
          <Text style={{ color: '#7b8593', textAlign: 'center', marginTop: 8 }}>{msg}</Text>
          <TouchableOpacity onPress={() => this.setState({ error: null })} style={{ marginTop: 22, backgroundColor: '#246bfd', borderRadius: 13, paddingVertical: 12, paddingHorizontal: 28 }}>
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 15 }}>Try again</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <AppInner />
    </ErrorBoundary>
  );
}

function AppInner() {
  const s = useSyncExternalStore(net.subscribe, net.getSnapshot);
  const cs = useSyncExternalStore(call.subscribe, call.getSnapshot);
  const [route, setRoute] = useState({ name: 'welcome' });
  const [toastTxt, setToastTxt] = useState('');
  const toastTimer = useRef(null);
  const prevCall = useRef(null);

  const toast = (t) => {
    setToastTxt(t);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastTxt(''), 2200);
  };

  let r = route;
  if (s.session && AUTH.includes(r.name)) r = { name: 'contacts' };
  if (!s.session && !AUTH.includes(r.name)) r = { name: 'welcome' };
  const rRef = useRef(r);
  rRef.current = r;
  const go = (name, id) => setRoute({ name, id });

  useEffect(() => {
    call.init();
    net.init();
    AsyncStorage.getItem('ln_direct_off').then((v) => direct.setEnabled(v !== '1')).catch(() => {});
  }, []);
  // Direct Wi-Fi (no router) is used only when the phone is not on a normal Wi-Fi network
  useEffect(() => { direct.update(s.session, !!s.myIp); }, [s.session, s.myIp]);
  // make sure the background service is still running whenever the app comes to the front
  useEffect(() => {
    const sub = AppState.addEventListener('change', (st2) => {
      if (st2 === 'active' && s.session && native.available && !native.isRunning()) native.startService();
    });
    return () => sub.remove();
  }, [s.session]);
  // background service + permissions while signed in
  useEffect(() => {
    if (!s.session) { native.stopService(); return; }
    (async () => {
      await native.ensurePermissions();
      native.startService();
      try {
        const asked = await AsyncStorage.getItem('ln_battery_asked');
        if (!asked && !native.batteryExempt()) {
          await AsyncStorage.setItem('ln_battery_asked', '1');
          native.askBatteryExemption();
        }
      } catch (e) {}
    })();
  }, [s.session]);
  const chatId = r.name === 'chat' ? r.id : null;
  useEffect(() => { net.setActive(chatId); }, [chatId]);
  useEffect(() => {
    if (prevCall.current && !cs.call) toast('Call ended');
    prevCall.current = cs.call;
  }, [cs.call]);
  useEffect(() => {
    const h = BackHandler.addEventListener('hardwareBackPress', () => {
      const cur = rRef.current.name;
      if (cur === 'chat') { setRoute({ name: 'messages' }); return true; }
      if (cur === 'register' || cur === 'login') { setRoute({ name: 'welcome' }); return true; }
      return false;
    });
    return () => h.remove();
  }, []);

  if (!s.ready) return <View style={st.flex} />;

  let body;
  if (r.name === 'welcome') body = <Welcome go={go} />;
  else if (r.name === 'register') body = <Register go={go} />;
  else if (r.name === 'login') body = <Login go={go} />;
  else if (r.name === 'chat' && s.contacts[r.id]) body = <Chat s={s} id={r.id} go={go} toast={toast} />;
  else if (r.name === 'messages') body = <Messages s={s} go={go} />;
  else if (r.name === 'calls') body = <Calls s={s} />;
  else if (r.name === 'settings') body = <Settings s={s} toast={toast} />;
  else body = <Contacts s={s} go={go} />;

  const unreadTotal = Object.values(s.messages).reduce((n, list) => n + (list || []).filter((m) => !m.mine && !m.read && m.kind !== 'call').length, 0);
  const missedTotal = Object.values(s.messages).reduce((n, list) => n + (list || []).filter((m) => m.kind === 'call' && !m.mine && !m.read).length, 0);
  const tab = r.name === 'chat' ? 'messages' : r.name;
  return (
    <View style={st.flex}>
      <StatusBar style="dark" backgroundColor={AUTH.includes(r.name) ? C.bg : '#ffffff'} />
      <View style={st.flex}>{body}</View>
      {s.session && <Nav tab={tab} go={go} unread={unreadTotal} missed={missedTotal} />}
      {s.session && cs.call && <CallPanel cs={cs} />}
      {!!toastTxt && <View style={st.toast}><Text style={st.toastTxt}>{toastTxt}</Text></View>}
    </View>
  );
}

function Nav({ tab, go, unread, missed }) {
  const items = [['contacts', '◉', 'Contacts'], ['messages', '◌', 'Messages'], ['calls', '⌕', 'Calls'], ['settings', '⚙', 'Settings']];
  return (
    <View style={st.nav}>
      {items.map(([k, ic, label]) => (
        <TouchableOpacity key={k} style={[st.navItem, tab === k && { backgroundColor: C.soft }]} onPress={() => go(k)}>
          <Text style={[st.navIcon, { color: tab === k ? C.primary : '#8a94a2' }]}>{ic}</Text>
          <Text style={[st.navLbl, { color: tab === k ? C.primary : '#8a94a2' }]}>{label}</Text>
          {k === 'messages' && unread > 0 && <View style={st.navBadge}><Text style={st.badgeTxt}>{unread > 99 ? '99+' : unread}</Text></View>}
          {k === 'calls' && missed > 0 && <View style={st.navBadge}><Text style={st.badgeTxt}>{missed > 99 ? '99+' : missed}</Text></View>}
        </TouchableOpacity>
      ))}
    </View>
  );
}

/* ---------- auth screens ---------- */
function Welcome({ go }) {
  return (
    <ScrollView style={{ backgroundColor: C.bg }} contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: 24, paddingTop: TOP + 20 }}>
      <View style={{ alignItems: 'center' }}>
        <View style={st.heroIcon}><Text style={{ color: '#fff', fontSize: 38, fontWeight: '900' }}>⌁</Text></View>
        <Text style={st.h1Big}>LocalNet Connect</Text>
        <Text style={[st.mutedTxt, { textAlign: 'center', lineHeight: 24, marginTop: 8 }]}>Private chat and voice calls on the same local Wi-Fi network.</Text>
      </View>
      <Card style={{ padding: 18, marginTop: 22 }}>
        <View style={st.row}>
          <Text style={{ fontSize: 20 }}>📲</Text>
          <View style={st.flex}><Text style={st.bold}>Share the app</Text><Text style={st.smallMuted}>Send this APK to friends with Xender or Bluetooth.</Text></View>
        </View>
        <View style={{ height: 1, backgroundColor: '#eee', marginVertical: 16 }} />
        <View style={st.row}>
          <Text style={{ fontSize: 20 }}>🔒</Text>
          <View style={st.flex}><Text style={st.bold}>No server needed</Text><Text style={st.smallMuted}>Phones on the same Wi-Fi find each other automatically.</Text></View>
        </View>
      </Card>
      <Btn title="Create account" onPress={() => go('register')} style={{ marginTop: 22 }} />
      <Btn title="Log in" kind="outline" onPress={() => go('login')} style={{ marginTop: 14 }} />
      <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 18 }]}>
        Already registered? <Text style={{ fontWeight: '700', color: C.primary }} onPress={() => go('login')}>Sign in here</Text>
      </Text>
    </ScrollView>
  );
}

function ErrorBox({ text }) {
  if (!text) return null;
  return <View style={[st.card, { padding: 12, marginVertical: 15, backgroundColor: '#fff1f2' }]}><Text style={{ color: '#c62838' }}>{text}</Text></View>;
}

function Register({ go }) {
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  return (
    <ScrollView style={{ backgroundColor: C.bg }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 18, paddingTop: TOP + 14 }}>
      <Text style={st.mutedTxt} onPress={() => go('welcome')}>‹ Back</Text>
      <Text style={st.h1}>Create account</Text>
      <Text style={st.mutedTxt}>Your local identity appears to other users on this Wi-Fi.</Text>
      <ErrorBox text={error} />
      <Card style={{ padding: 18, marginTop: 18 }}>
        <Field label="Full name" value={name} onChangeText={setName} maxLength={60} autoCapitalize="words" />
        <Field label="Username" value={username} onChangeText={setUsername} maxLength={30} placeholder="e.g. ahmad" />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        <Btn title="Create account" onPress={async () => setError((await net.register({ name, username, password })) || '')} style={{ marginTop: 5 }} />
        <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 15 }]}>
          Already have an account? <Text style={{ fontWeight: '700', color: C.primary }} onPress={() => go('login')}>Log in</Text>
        </Text>
      </Card>
    </ScrollView>
  );
}

function Login({ go }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  return (
    <ScrollView style={{ backgroundColor: C.bg }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 18, paddingTop: TOP + 30 }}>
      <Text style={st.mutedTxt} onPress={() => go('welcome')}>‹ Back</Text>
      <View style={{ alignItems: 'center', marginVertical: 26 }}>
        <View style={{ width: 70, height: 70, borderRadius: 22, backgroundColor: '#3f7bfd', alignItems: 'center', justifyContent: 'center' }}>
          <Text style={{ color: '#fff', fontSize: 25, fontWeight: '800' }}>⌁</Text>
        </View>
        <Text style={st.h1}>Welcome back</Text>
        <Text style={st.mutedTxt}>Sign in to your LocalNet account.</Text>
      </View>
      <ErrorBox text={error} />
      <Card style={{ padding: 18 }}>
        <Field label="Username" value={username} onChangeText={setUsername} />
        <Field label="Password" value={password} onChangeText={setPassword} secureTextEntry />
        <Btn title="Sign in" onPress={async () => setError((await net.login({ username, password })) || '')} />
      </Card>
    </ScrollView>
  );
}

/* ---------- main tabs ---------- */
function Header({ title, subtitle, right }) {
  return (
    <View style={[st.row, { justifyContent: 'space-between', marginBottom: 14 }]}>
      <View style={st.flex}>
        <Text style={st.h2}>{title}</Text>
        {!!subtitle && <Text style={st.smallMuted}>{subtitle}</Text>}
      </View>
      {right}
    </View>
  );
}

const sortContacts = (s) => Object.values(s.contacts).sort((a, b) => (isOnline(b) - isOnline(a)) || (b.lastSeen - a.lastSeen));

function Contacts({ s, go }) {
  const [q, setQ] = useState('');
  const list = sortContacts(s).filter((u) => (u.name + ' ' + u.username).toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <FlatList
        data={list}
        keyExtractor={(u) => u.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={
          <View style={{ marginBottom: 4 }}>
            <Header title="Contacts" subtitle="Everyone nearby on this Wi-Fi." right={<Avatar name={s.me.name} />} />
            <TextInput style={st.input} placeholder="Search people…" placeholderTextColor="#a3acb9" value={q} onChangeText={setQ} />
          </View>
        }
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{ fontSize: 42, color: C.muted }}>◎</Text>
            <Text style={st.bold}>No other users yet</Text>
            <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 6 }]}>Ask another phone to open the app on this same Wi-Fi and create an account.</Text>
          </View>
        }
        renderItem={({ item: u }) => (
          <Card style={{ padding: 13 }}>
            <View style={st.row}>
              <Avatar name={u.name} />
              <View style={st.flex}>
                <Text style={st.bold}>{u.name}</Text>
                <View style={[st.row, { gap: 6 }]}><Dot on={isOnline(u)} /><Text numberOfLines={1} style={[st.smallMuted, st.flex]}>{lastSeen(u)} · @{u.username}</Text></View>
              </View>
              <Btn title="Chat" kind="soft" onPress={() => go('chat', u.id)} />
              <Btn title="Call" kind="green" onPress={() => call.startCall(u.id)} />
            </View>
          </Card>
        )}
      />
    </View>
  );
}

function Messages({ s, go }) {
  const convs = Object.keys(s.messages)
    .filter((id) => s.contacts[id] && (s.messages[id] || []).some((m) => m.kind !== 'call'))
    .map((id) => { const list = s.messages[id].filter((m) => m.kind !== 'call'); return { c: s.contacts[id], last: list[list.length - 1], unread: list.filter((m) => !m.mine && !m.read).length }; })
    .sort((a, b) => b.last.ts - a.last.ts);
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <FlatList
        data={convs}
        keyExtractor={(x) => x.c.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={<Header title="Messages" subtitle="Your private conversations." />}
        ListEmptyComponent={
          <View style={st.empty}>
            <Text style={{ fontSize: 42, color: C.muted }}>◌</Text>
            <Text style={st.bold}>No conversations yet</Text>
            <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 6 }]}>Open Contacts and start a private chat.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => go('chat', item.c.id)}
            onLongPress={() => Alert.alert('Delete conversation?', 'This removes the chat with ' + item.c.name + ' from this phone only.', [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Delete', style: 'destructive', onPress: () => net.clearChat(item.c.id) },
            ])}
          >
            <Card style={{ padding: 14 }}>
              <View style={st.row}>
                <Avatar name={item.c.name} />
                <View style={st.flex}>
                  <View style={[st.row, { justifyContent: 'space-between' }]}>
                    <Text style={st.bold}>{item.c.name}</Text>
                    <Text style={st.smallMuted}>{hhmm(item.last.ts)}</Text>
                  </View>
                  <View style={[st.row, { justifyContent: 'space-between' }]}>
                    <Text numberOfLines={1} style={[st.smallMuted, st.flex]}>{preview(item.last)}</Text>
                    {item.unread > 0 && <View style={st.badge}><Text style={st.badgeTxt}>{item.unread}</Text></View>}
                  </View>
                </View>
              </View>
            </Card>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

function Calls({ s }) {
  const list = sortContacts(s);
  const recents = [];
  Object.keys(s.messages).forEach((id) => {
    if (!s.contacts[id]) return;
    (s.messages[id] || []).forEach((m) => { if (m.kind === 'call') recents.push({ c: s.contacts[id], m }); });
  });
  recents.sort((a2, b2) => b2.m.ts - a2.m.ts);
  const unseen = recents.filter((x2) => !x2.m.mine && !x2.m.read).length;
  useEffect(() => { if (unseen > 0) net.markCallsRead(); }, [unseen]);
  const label = { marginTop: 18, marginBottom: 8, fontSize: 13, fontWeight: '800', color: C.muted, letterSpacing: 0.6 };
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <FlatList
        data={list}
        keyExtractor={(u) => u.id}
        contentContainerStyle={{ padding: 16, paddingBottom: 24, gap: 10 }}
        ListHeaderComponent={
          <View>
            <Header title="Voice Calls" subtitle="Calls, missed calls and call history." />
            {recents.length > 0 && (
              <View>
                <Text style={label}>RECENT CALLS</Text>
                <Card style={{ paddingVertical: 4 }}>
                  {recents.slice(0, 15).map(({ c, m }, i) => {
                    const missed = m.outcome === 'missed';
                    return (
                      <TouchableOpacity
                        key={m.id}
                        activeOpacity={0.7}
                        onPress={() => call.startCall(c.id)}
                        onLongPress={() => Alert.alert('Delete this call entry?', undefined, [
                          { text: 'Cancel', style: 'cancel' },
                          { text: 'Delete', style: 'destructive', onPress: () => net.deleteMessage(c.id, m.id) },
                        ])}
                        style={[st.row, { paddingVertical: 11, paddingHorizontal: 14, borderTopWidth: i ? 1 : 0, borderTopColor: '#eef0f3' }]}
                      >
                        <Text style={{ fontSize: 18, fontWeight: '800', color: missed ? C.danger : m.dir === 'out' ? C.primary : '#15945d' }}>{m.dir === 'out' ? '↗' : '↙'}</Text>
                        <View style={st.flex}>
                          <Text style={[st.bold, missed && { color: C.danger }]}>{c.name}</Text>
                          <Text style={st.smallMuted}>{String(m.text || '').replace('📞 ', '')} · {dayLabel(m.ts)}, {hhmm(m.ts)}</Text>
                        </View>
                        <Text style={{ color: '#15945d', fontSize: 18 }}>📞</Text>
                      </TouchableOpacity>
                    );
                  })}
                </Card>
              </View>
            )}
            <Text style={label}>CONTACTS</Text>
          </View>
        }
        ListEmptyComponent={<View style={st.empty}><Text style={st.bold}>No contacts available</Text></View>}
        renderItem={({ item: u }) => (
          <Card style={{ padding: 13 }}>
            <View style={st.row}>
              <Avatar name={u.name} />
              <View style={st.flex}>
                <Text style={st.bold}>{u.name}</Text>
                <Text style={st.smallMuted}>{isOnline(u) ? '● Online' : '○ ' + lastSeen(u)} · @{u.username}</Text>
              </View>
              <Btn title="Call" kind="green" onPress={() => call.startCall(u.id)} />
            </View>
          </Card>
        )}
      />
    </View>
  );
}

function Settings({ s, toast }) {
  const ds = useSyncExternalStore(direct.subscribe, direct.getSnapshot);
  const [dOn, setDOn] = useState(direct.isEnabled());
  const [ip, setIp] = useState('');
  const gws = useSyncExternalStore(net.gatewaySubscribe, net.gatewaySnapshot);
  const [gwIp, setGwIp] = useState('');
  const [gwBusy, setGwBusy] = useState(false);
  const [nameInput, setNameInput] = useState(s.me.name);
  const [bg, setBg] = useState({ on: native.isRunning(), ok: native.batteryExempt(), fs: native.fullScreenAllowed() });
  const refreshBg = () => setBg({ on: native.isRunning(), ok: native.batteryExempt(), fs: native.fullScreenAllowed() });
  useEffect(() => { Network.getIpAddressAsync().then(setIp).catch(() => {}); }, []);
  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <TopBar s={s} />
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={[st.h2, { marginBottom: 14 }]}>Settings</Text>
        <Card style={{ padding: 16 }}>
          <View style={st.row}>
            <Avatar name={s.me.name} />
            <View><Text style={st.bold}>{s.me.name}</Text><Text style={st.smallMuted}>@{s.me.username}</Text></View>
          </View>
          <View style={[st.row, { marginTop: 14 }]}>
            <TextInput style={[st.input, st.flex]} value={nameInput} onChangeText={setNameInput} maxLength={60} placeholder="Display name" placeholderTextColor="#a3acb9" />
            <Btn title="Save" kind="soft" onPress={() => { net.updateName(nameInput); if (toast) toast('Name updated'); }} />
          </View>
        </Card>
        {direct.available && (
          <Card style={{ padding: 16, marginTop: 12 }}>
            <View style={[st.row, { justifyContent: 'space-between' }]}>
              <View style={st.flex}>
                <Text style={st.bold}>Direct Wi-Fi (no router)</Text>
                <Text style={st.smallMuted}>
                  {!dOn ? 'Off'
                    : s.myIp ? 'Not needed: you are on Wi-Fi'
                    : ({ searching: 'Searching for nearby phones…', hosting: 'Waiting for nearby phones…', connected: 'Connected directly',
                        'needs-wifi': 'Turn Wi-Fi on (no network needed)', 'needs-permission': 'Allow the Nearby devices / Location permission',
                        unsupported: 'This phone does not support Direct Wi-Fi (needs Android 10+)', off: 'Starting…' }[ds.status] || '')}
                </Text>
              </View>
              <Btn title={dOn ? 'Turn off' : 'Turn on'} kind="soft" onPress={() => {
                const v = !dOn;
                setDOn(v);
                direct.setEnabled(v);
                AsyncStorage.setItem('ln_direct_off', v ? '0' : '1').catch(() => {});
              }} />
            </View>
            {dOn && !s.myIp && ds.status === 'needs-wifi' && (
              <Btn title="Turn on Wi-Fi" kind="soft" style={{ marginTop: 10 }} onPress={() => direct.openWifiPanel()} />
            )}
            <Text style={[st.smallMuted, { marginTop: 8, lineHeight: 17 }]}>Used only when there is no Wi-Fi, hotspot or router. Both phones need this app open and Wi-Fi switched on.</Text>
          </Card>
        )}
        <Card style={{ padding: 16, marginTop: 12 }}>
          <Text style={st.bold}>Local network</Text>
          <Text style={[st.smallMuted, { marginVertical: 8 }]}>Your phone's address on this Wi-Fi:</Text>
          <View style={{ padding: 12, backgroundColor: '#f1f4f8', borderRadius: 12 }}><Text style={{ fontWeight: '700', color: C.text }}>{ip || 'Not connected'}</Text></View>
          <Text style={[st.smallMuted, { marginTop: 8 }]}>No host or server needed. Phones on the same Wi-Fi or hotspot find each other automatically{native.available && bg.on ? ', even when the app is in the background.' : ' while the app is open.'}</Text>
          {s.carrying > 0 && (
            <Text style={[st.smallMuted, { marginTop: 8 }]}>Helping nearby phones: carrying {s.carrying} encrypted message{s.carrying === 1 ? '' : 's'} (nobody can read them).</Text>
          )}
          {native.available && !bg.ok && (
            <Btn title="Allow in background" kind="soft" style={{ marginTop: 12 }} onPress={() => { native.askBatteryExemption(); setTimeout(refreshBg, 4000); }} />
          )}
          {native.available && (
            <Btn title="Auto-start / protected apps" kind="soft" style={{ marginTop: 10 }} onPress={() => native.openAutoStart()} />
          )}
          {native.available && !bg.fs && (
            <Btn title="Allow calls on lock screen" kind="soft" style={{ marginTop: 10 }} onPress={() => { native.openFullScreenSettings(); setTimeout(refreshBg, 4000); }} />
          )}
        </Card>
        <Card style={{ padding: 16, marginTop: 12 }}>
          <Text style={st.bold}>Gateways</Text>
          <Text style={[st.smallMuted, { marginVertical: 8 }]}>Industrial gateways/routers are found on Wi-Fi, hotspot and Direct Wi-Fi, and reconnect by themselves. Everything sent to them is encrypted.</Text>
          {gws.length === 0 && <Text style={st.smallMuted}>No gateway found yet.</Text>}
          {gws.map((g) => (
            <View key={g.id} style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 6 }}>
              <Text style={[st.flex, { color: C.text }]}>{g.name} · {g.ip}:{g.port}</Text>
              <Text style={st.smallMuted}>{g.state === 'up' ? 'connected' : g.state === 'key-changed' ? 'KEY CHANGED' : 'reconnecting…'}</Text>
              <TouchableOpacity onPress={() => net.gatewayRemove(g.id)} style={{ paddingLeft: 12 }}><Text style={{ color: '#d33' }}>Remove</Text></TouchableOpacity>
            </View>
          ))}
          <Btn title={gwBusy ? 'Searching…' : 'Search for gateways'} kind="soft" disabled={gwBusy} style={{ marginTop: 10 }} onPress={async () => { setGwBusy(true); const n = await net.gatewayScan(); setGwBusy(false); toast(n ? 'Gateway found' : 'No gateway found'); }} />
          <TextInput style={[st.input, { marginTop: 10 }]} placeholder="Gateway IP, e.g. 192.168.1.1" placeholderTextColor="#a3acb9" autoCapitalize="none" keyboardType="numeric" value={gwIp} onChangeText={setGwIp} />
          <Btn title="Add by IP" kind="soft" style={{ marginTop: 8 }} onPress={async () => { const ok = await net.gatewayAdd(gwIp.trim()); toast(ok ? 'Gateway added' : 'No gateway answered at that address'); if (ok) setGwIp(''); }} />
        </Card>
        <Btn title="Sign out" kind="danger" onPress={() => net.logout()} style={{ marginTop: 14 }} />
        <Text style={[st.smallMuted, { textAlign: 'center', marginTop: 14 }]}>LocalNet Connect v1.10.0</Text>
      </ScrollView>
    </View>
  );
}

/* ---------- voice + chat ---------- */
function VoiceBubble({ uri, dur, mine }) {
  const [playing, setPlaying] = useState(false);
  const snd = useRef(null);
  useEffect(() => () => { snd.current && snd.current.unloadAsync().catch(() => {}); }, []);
  const toggle = async () => {
    try {
      if (snd.current) {
        const t = await snd.current.getStatusAsync();
        if (t.isLoaded && t.isPlaying) { await snd.current.pauseAsync(); setPlaying(false); return; }
        if (t.isLoaded) {
          if (t.positionMillis >= (t.durationMillis || 1) - 50) await snd.current.setPositionAsync(0);
          await snd.current.playAsync();
          setPlaying(true);
          return;
        }
      }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
      const { sound } = await Audio.Sound.createAsync({ uri }, { shouldPlay: true }, (u) => {
        if (u.isLoaded && u.didJustFinish) setPlaying(false);
      });
      snd.current = sound;
      setPlaying(true);
    } catch (e) { setPlaying(false); }
  };
  const fg = mine ? '#fff' : C.primary;
  return (
    <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', minWidth: 190 }} onPress={toggle}>
      <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: mine ? '#fff' : C.soft, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ color: C.primary, fontSize: 13 }}>{playing ? '❚❚' : '▶'}</Text>
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, marginHorizontal: 10, height: 20 }}>
        {[6, 12, 8, 16, 10, 14, 7, 12, 9, 15, 6, 11].map((h, i) => (
          <View key={i} style={{ width: 3, height: h, borderRadius: 2, marginRight: 3, backgroundColor: fg, opacity: 0.75 }} />
        ))}
      </View>
      <Text style={{ fontSize: 12, color: mine ? '#ffffffcc' : C.muted }}>{mmss((dur || 0) / 1000)}</Text>
    </TouchableOpacity>
  );
}

function Chat({ s, id, go, toast }) {
  const c = s.contacts[id];
  const list = s.messages[id] || [];
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [voice, setVoice] = useState(null);
  const recRef = useRef(null);
  const ref = useRef(null);
  const on = isOnline(c);
  const typing = Date.now() - (c.typingAt || 0) < 4000;
  const items = [];
  let lastDayStr = '';
  list.forEach((m) => {
    if (m.kind === 'call') return;
    const dd = new Date(m.ts).toDateString();
    if (dd !== lastDayStr) { items.push({ id: 'sep-' + dd, kind: 'sep', ts: m.ts }); lastDayStr = dd; }
    items.push(m);
  });

  useEffect(() => {
    if (!recording) return undefined;
    const t = setInterval(() => setRecSecs((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);
  useEffect(() => () => { if (recRef.current) recRef.current.stopAndUnloadAsync().catch(() => {}); }, []);

  const send = () => {
    if (!text.trim()) return;
    net.sendMessage(id, text);
    setText('');
  };

  const toggleRec = async () => {
    if (recording) {
      const r = recRef.current;
      recRef.current = null;
      setRecording(false);
      if (!r) return;
      try {
        const t = await r.getStatusAsync();
        await r.stopAndUnloadAsync();
        await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
        const uri = r.getURI();
        if (!uri || !(t.durationMillis > 700)) { toast('No audio was recorded. Please try again.'); return; }
        setVoice({ uri, dur: t.durationMillis });
      } catch (e) { toast('Could not finish recording.'); }
      return;
    }
    try {
      const p = await Audio.requestPermissionsAsync();
      if (!p.granted) { toast('Microphone permission is blocked. Allow Microphone in phone settings for this app.'); return; }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const r = new Audio.Recording();
      await r.prepareToRecordAsync(REC_OPTS);
      await r.startAsync();
      recRef.current = r;
      setRecSecs(0);
      setRecording(true);
      toast('Recording… tap ■ to finish and preview');
    } catch (e) { setRecording(false); toast('Could not start microphone.'); }
  };

  return (
    <View style={[st.flex, { backgroundColor: C.bg }]}>
      <View style={[st.top, st.row]}>
        <Text style={{ fontSize: 25, color: C.text }} onPress={() => go('messages')}>‹</Text>
        <Avatar name={c.name} size={38} radius={12} font={16} />
        <View>
          <Text style={st.bold}>{c.name}</Text>
          <Text style={[st.smallMuted, typing && { color: C.green, fontWeight: '700' }]}>{typing ? 'typing…' : '@' + (c.username || 'user') + ' · ' + (on ? 'online' : lastSeen(c))}</Text>
        </View>
      </View>
      <FlatList
        ref={ref}
        data={items}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: 16, gap: 8 }}
        onContentSizeChange={() => ref.current && ref.current.scrollToEnd({ animated: false })}
        renderItem={({ item }) => {
          if (item.kind === 'sep') return <View style={st.sepWrap}><Text style={st.sepTxt}>{dayLabel(item.ts)}</Text></View>;
          if (item.kind === 'call') return <Text style={st.callNote}>{item.text} · {hhmm(item.ts)}</Text>;
          const failed = item.mine && item.status === 'failed' && !item.carried;
          const mark = !item.mine ? '' : (item.status === 'delivered' || item.status === 'read') ? ' ✓✓' : failed ? ' ! tap to retry' : ' …';
          return (
            <TouchableOpacity
              activeOpacity={failed ? 0.6 : 1}
              onPress={() => failed && net.retry(id, item.id)}
              onLongPress={() => Alert.alert('Message', undefined, [
                { text: 'Delete for me', style: 'destructive', onPress: () => net.deleteMessage(id, item.id) },
                { text: 'Cancel', style: 'cancel' },
              ])}
              style={[st.bubble, item.mine ? st.mine : st.theirs]}
            >
              {item.kind === 'voice'
                ? <VoiceBubble uri={item.uri} dur={item.dur} mine={item.mine} />
                : <Text style={{ fontSize: 14, lineHeight: 20, color: item.mine ? '#fff' : C.text }}>{item.text}</Text>}
              <Text style={{ fontSize: 9, opacity: 0.65, marginTop: 4, color: item.mine ? '#fff' : C.text }}>{hhmm(item.ts)}<Text style={item.status === 'read' ? { color: '#9fe8ff', fontWeight: '800' } : null}>{mark}</Text></Text>
            </TouchableOpacity>
          );
        }}
      />
      {voice ? (
        <View style={st.voicePanel}>
          <Text style={st.bold}>Voice note preview</Text>
          <View style={{ marginVertical: 10 }}><VoiceBubble uri={voice.uri} dur={voice.dur} mine={false} /></View>
          <View style={[st.row, { gap: 8 }]}>
            <Btn title="Cancel" kind="soft" style={st.flex} onPress={() => setVoice(null)} />
            <Btn title="Send voice note" style={st.flex} onPress={() => { net.sendVoice(id, voice.uri, voice.dur); setVoice(null); }} />
          </View>
        </View>
      ) : (
        <View style={st.composer}>
          <TouchableOpacity onPress={toggleRec} style={[st.record, recording && { backgroundColor: C.dangerBg }]}>
            <Text style={{ fontSize: 18, color: recording ? C.danger : C.primary }}>{recording ? '■' : '🎙'}</Text>
          </TouchableOpacity>
          <TextInput
            style={[st.input, { flex: 1 }]}
            placeholder={recording ? 'Recording… ' + mmss(recSecs) : 'Message…'}
            placeholderTextColor={recording ? C.danger : '#a3acb9'}
            value={text}
            onChangeText={(v) => { setText(v); if (v) net.sendTyping(id); }}
            onSubmitEditing={send}
            editable={!recording}
          />
          <Btn title="Send" onPress={send} />
        </View>
      )}
    </View>
  );
}

/* ---------- call panel ---------- */
function CallPanel({ cs }) {
  const c = cs.call;
  const incoming = c.dir === 'in' && c.status === 'ringing';
  const label = {
    preparing: 'Preparing call…',
    calling: 'Ringing… waiting for answer',
    ringing: 'Incoming call — tap Answer to enable microphone',
    connecting: 'Connecting…',
    connected: 'Connected · ' + mmss((cs.now - c.since) / 1000),
    lost: 'Connection lost — check both phones are on the same Wi-Fi',
  }[c.status] || '';
  return (
    <View style={st.callDim}>
      <Card style={st.callCard}>
        <Avatar name={c.name} size={80} radius={25} font={28} />
        <Text style={[st.h2, { marginTop: 14 }]}>{c.name}</Text>
        <Text style={[st.mutedTxt, { textAlign: 'center', marginVertical: 10 }]}>{label}</Text>
        {c.mode !== 'lan' && !!c.ice && c.status !== 'connected' && c.status !== 'ringing' && c.status !== 'preparing' && (
          <Text style={[st.smallMuted, { textAlign: 'center', marginBottom: 8 }]}>Network: {c.ice}</Text>
        )}
        {c.mode === 'lan' && c.status !== 'ringing' && c.status !== 'preparing' && (
          <Text style={[st.smallMuted, { textAlign: 'center', marginBottom: 8 }]}>Direct audio · sent {String(direct.lanStats()).split(':')[0]} · received {String(direct.lanStats()).split(':')[1]}</Text>
        )}
        {incoming && <Btn title="Answer" kind="green" onPress={call.answer} style={{ marginBottom: 10, alignSelf: 'stretch' }} />}
        {!incoming && (c.status === 'connected' || c.status === 'connecting' || c.status === 'lost') && (
          <View style={[st.row, { gap: 10, marginBottom: 10 }]}>
            <Btn title={c.muted ? 'Unmute' : 'Mute'} kind="soft" onPress={call.toggleMute} />
            <Btn title={c.speaker ? 'Earpiece' : 'Speaker'} kind="soft" onPress={call.toggleSpeaker} />
          </View>
        )}
        <Btn title="End call" kind="danger" onPress={call.hangup} style={{ alignSelf: 'stretch' }} />
      </Card>
    </View>
  );
}

/* ---------- styles ---------- */
const st = StyleSheet.create({
  flex: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  card: { backgroundColor: C.card, borderWidth: 1, borderColor: C.line, borderRadius: 20, elevation: 2, shadowColor: '#1c2733', shadowOpacity: 0.07, shadowRadius: 12, shadowOffset: { width: 0, height: 6 } },
  top: { paddingTop: TOP + 12, paddingBottom: 12, paddingHorizontal: 18, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: C.line },
  brand: { fontWeight: '800', fontSize: 16, color: C.text, letterSpacing: -0.4 },
  sub: { fontSize: 12, color: '#7a8491', marginTop: 3 },
  h1: { fontSize: 28, fontWeight: '800', color: C.text, marginTop: 12, marginBottom: 4, letterSpacing: -0.6 },
  h1Big: { fontSize: 30, fontWeight: '800', color: C.text, marginTop: 20, letterSpacing: -1 },
  h2: { fontSize: 22, fontWeight: '800', color: C.text },
  bold: { fontWeight: '700', fontSize: 15, color: C.text },
  mutedTxt: { color: C.muted, fontSize: 15 },
  smallMuted: { color: C.muted, fontSize: 12 },
  label: { fontSize: 12, fontWeight: '700', color: '#657080', marginBottom: 7, marginLeft: 3 },
  input: { borderWidth: 1, borderColor: C.inputLine, backgroundColor: '#fff', borderRadius: 13, paddingVertical: 12, paddingHorizontal: 14, fontSize: 15, color: C.text },
  heroIcon: { width: 88, height: 88, borderRadius: 27, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center', elevation: 8, shadowColor: C.primary, shadowOpacity: 0.3, shadowRadius: 18 },
  empty: { alignItems: 'center', paddingVertical: 55, paddingHorizontal: 20 },
  navBadge: { position: 'absolute', top: 2, right: '22%', backgroundColor: C.danger, minWidth: 16, height: 16, borderRadius: 8, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  sepWrap: { alignSelf: 'center', backgroundColor: '#e8ecf2', paddingVertical: 4, paddingHorizontal: 12, borderRadius: 10, marginVertical: 6 },
  sepTxt: { color: C.muted, fontSize: 12, fontWeight: '600' },
  badge: { backgroundColor: C.primary, minWidth: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6, marginLeft: 8 },
  badgeTxt: { color: '#fff', fontSize: 11, fontWeight: '700' },
  nav: { flexDirection: 'row', backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e7eaee', paddingHorizontal: 7, paddingTop: 8, paddingBottom: 12 },
  navItem: { flex: 1, alignItems: 'center', gap: 4, paddingVertical: 7, borderRadius: 12 },
  navIcon: { fontSize: 20, lineHeight: 22 },
  navLbl: { fontSize: 10, fontWeight: '700' },
  bubble: { maxWidth: '82%', paddingVertical: 10, paddingHorizontal: 12, borderRadius: 16 },
  mine: { alignSelf: 'flex-end', backgroundColor: C.primary, borderBottomRightRadius: 5 },
  theirs: { alignSelf: 'flex-start', backgroundColor: '#fff', borderWidth: 1, borderColor: '#e7eaee', borderBottomLeftRadius: 5 },
  callNote: { alignSelf: 'center', backgroundColor: '#e8ecf2', color: C.muted, fontSize: 12, paddingVertical: 4, paddingHorizontal: 12, borderRadius: 10, overflow: 'hidden' },
  composer: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: C.bg, borderTopWidth: 1, borderTopColor: C.line, paddingVertical: 9, paddingHorizontal: 12 },
  record: { width: 44, height: 44, borderRadius: 14, backgroundColor: C.soft, alignItems: 'center', justifyContent: 'center' },
  voicePanel: { backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: C.line, padding: 12 },
  callDim: { ...StyleSheet.absoluteFillObject, backgroundColor: '#17202a66', justifyContent: 'flex-end', paddingHorizontal: 12, paddingBottom: 90 },
  callCard: { padding: 25, alignItems: 'center' },
  toast: { position: 'absolute', left: 20, right: 20, bottom: 82, alignItems: 'center' },
  toastTxt: { backgroundColor: C.text, color: '#fff', paddingVertical: 11, paddingHorizontal: 15, borderRadius: 12, fontSize: 12, overflow: 'hidden', textAlign: 'center' },
});
