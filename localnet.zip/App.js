import React, { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet,
  BackHandler, Platform, KeyboardAvoidingView, StatusBar as RNStatusBar,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Audio } from 'expo-av';
import * as net from './src/net';
import * as call from './src/call';

const C = { dark: '#0F766E', mid: '#14B8A6', bg: '#ECF1F0', mine: '#D1F5EC', white: '#FFFFFF', text: '#0F172A', sub: '#64748B', red: '#DC2626' };
const TOP = Platform.OS === 'android' ? (RNStatusBar.currentHeight || 24) : 44;
const isOnline = (c) => Date.now() - c.lastSeen < net.ONLINE_MS;
const hhmm = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const mmss = (secs) => Math.floor(secs / 60) + ':' + String(Math.max(0, Math.floor(secs % 60))).padStart(2, '0');
const preview = (m) => (m.kind === 'voice' ? '🎤 Voice note' : m.kind === 'call' ? m.text : m.text);

const REC_OPTS = {
  isMeteringEnabled: false,
  android: { extension: '.m4a', outputFormat: Audio.AndroidOutputFormat.MPEG_4, audioEncoder: Audio.AndroidAudioEncoder.AAC, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  ios: { extension: '.m4a', outputFormat: Audio.IOSOutputFormat.MPEG4AAC, audioQuality: Audio.IOSAudioQuality.LOW, sampleRate: 16000, numberOfChannels: 1, bitRate: 24000 },
  web: {},
};

export default function App() {
  const s = useSyncExternalStore(net.subscribe, net.getSnapshot);
  const cs = useSyncExternalStore(call.subscribe, call.getSnapshot);
  const [peer, setPeer] = useState(null);

  useEffect(() => { call.init(); net.init(); }, []);
  useEffect(() => { net.setActive(peer); }, [peer]);
  useEffect(() => {
    const h = BackHandler.addEventListener('hardwareBackPress', () => {
      if (peer) { setPeer(null); return true; }
      return false;
    });
    return () => h.remove();
  }, [peer]);

  let body;
  if (!s.ready) body = <View style={[st.flex, { backgroundColor: C.dark }]} />;
  else if (!s.me) body = <Setup />;
  else if (peer && s.contacts[peer]) body = <Chat s={s} id={peer} onBack={() => setPeer(null)} />;
  else body = <Home s={s} open={setPeer} />;

  return (
    <View style={st.flex}>
      <StatusBar style="light" backgroundColor={C.dark} />
      {body}
      {cs.call && <CallScreen cs={cs} />}
    </View>
  );
}

function CallScreen({ cs }) {
  const c = cs.call;
  const incoming = c.dir === 'in' && c.status === 'ringing';
  const label = c.status === 'connected' ? mmss((cs.now - c.since) / 1000)
    : c.status === 'calling' ? 'Calling…' : c.status === 'ringing' ? 'Incoming voice call' : 'Connecting…';
  return (
    <View style={st.callWrap}>
      <View style={st.callAvatar}><Text style={st.callAvatarTxt}>{c.name.slice(0, 1).toUpperCase()}</Text></View>
      <Text style={st.callName}>{c.name}</Text>
      <Text style={st.callStatus}>{label}</Text>
      {incoming ? (
        <View style={st.callRow}>
          <TouchableOpacity style={[st.callBtn, { backgroundColor: C.red }]} onPress={call.decline}><Text style={st.callBtnTxt}>✕</Text></TouchableOpacity>
          <TouchableOpacity style={[st.callBtn, { backgroundColor: '#16A34A' }]} onPress={call.answer}><Text style={st.callBtnTxt}>📞</Text></TouchableOpacity>
        </View>
      ) : (
        <View style={st.callRow}>
          <TouchableOpacity style={[st.callBtn, { backgroundColor: c.muted ? '#fff' : '#ffffff33' }]} onPress={call.toggleMute}>
            <Text style={st.callBtnTxt}>{c.muted ? '🔇' : '🎙️'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[st.callBtn, { backgroundColor: C.red }]} onPress={call.hangup}><Text style={st.callBtnTxt}>✕</Text></TouchableOpacity>
          <TouchableOpacity style={[st.callBtn, { backgroundColor: c.speaker ? '#fff' : '#ffffff33' }]} onPress={call.toggleSpeaker}>
            <Text style={st.callBtnTxt}>🔊</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

function VoiceBubble({ m }) {
  const [playing, setPlaying] = useState(false);
  const snd = useRef(null);
  useEffect(() => () => { snd.current && snd.current.unloadAsync().catch(() => {}); }, []);
  const toggle = async () => {
    try {
      if (snd.current) {
        const stt = await snd.current.getStatusAsync();
        if (stt.isLoaded && stt.isPlaying) { await snd.current.pauseAsync(); setPlaying(false); return; }
        if (stt.isLoaded) { if (stt.didJustFinish || stt.positionMillis >= (stt.durationMillis || 1)) await snd.current.setPositionAsync(0); await snd.current.playAsync(); setPlaying(true); return; }
      }
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
      const { sound } = await Audio.Sound.createAsync({ uri: m.uri }, { shouldPlay: true }, (u) => {
        if (u.isLoaded && u.didJustFinish) setPlaying(false);
      });
      snd.current = sound;
      setPlaying(true);
    } catch (e) { setPlaying(false); }
  };
  return (
    <TouchableOpacity style={st.voiceRow} onPress={toggle}>
      <View style={st.playBtn}><Text style={st.playTxt}>{playing ? '❚❚' : '▶'}</Text></View>
      <View style={st.wave}>{[6, 12, 8, 16, 10, 14, 7, 12, 9, 15, 6, 11].map((h, i) => <View key={i} style={[st.bar, { height: h }]} />)}</View>
      <Text style={st.dur}>{mmss((m.dur || 0) / 1000)}</Text>
    </TouchableOpacity>
  );
}

function Setup() {
  const [name, setName] = useState('');
  return (
    <View style={[st.flex, st.center, { backgroundColor: C.dark, padding: 28 }]}>
      <Text style={st.bigTitle}>LocalNet Connect</Text>
      <Text style={st.setupSub}>Chat with people on the same WiFi. No internet, no server.</Text>
      <TextInput
        style={st.nameInput}
        placeholder="Your name"
        placeholderTextColor="#94A3B8"
        value={name}
        onChangeText={setName}
        maxLength={24}
      />
      <TouchableOpacity style={st.startBtn} onPress={() => net.setName(name)}>
        <Text style={st.startTxt}>Start</Text>
      </TouchableOpacity>
    </View>
  );
}

function Home({ s, open }) {
  const list = Object.values(s.contacts).sort(
    (a, b) => (isOnline(b) - isOnline(a)) || (b.lastSeen - a.lastSeen)
  );
  return (
    <View style={[st.flex, { backgroundColor: C.white }]}>
      <View style={st.header}>
        <Text style={st.title}>LocalNet Connect</Text>
        <Text style={st.headSub}>You: {s.me.name}</Text>
      </View>
      <FlatList
        data={list}
        keyExtractor={(c) => c.id}
        contentContainerStyle={list.length ? null : { flexGrow: 1, justifyContent: 'center' }}
        ListEmptyComponent={
          <Text style={st.empty}>
            No one nearby yet.{'\n\n'}Install the app on another phone, connect both to the same WiFi (or one phone's hotspot) and keep the app open.
          </Text>
        }
        renderItem={({ item }) => {
          const msgs = s.messages[item.id] || [];
          const last = msgs[msgs.length - 1];
          const unread = msgs.filter((m) => !m.mine && !m.read).length;
          const on = isOnline(item);
          return (
            <TouchableOpacity style={st.row} onPress={() => open(item.id)}>
              <View style={st.avatar}>
                <Text style={st.avatarTxt}>{item.name.slice(0, 1).toUpperCase()}</Text>
                <View style={[st.dot, { backgroundColor: on ? '#22C55E' : '#94A3B8' }]} />
              </View>
              <View style={st.flex}>
                <Text style={st.name}>{item.name}</Text>
                <Text numberOfLines={1} style={st.preview}>{last ? preview(last) : on ? 'Online' : 'Offline'}</Text>
              </View>
              {unread > 0 && (
                <View style={st.badge}><Text style={st.badgeTxt}>{unread}</Text></View>
              )}
            </TouchableOpacity>
          );
        }}
      />
    </View>
  );
}

function Chat({ s, id, onBack }) {
  const c = s.contacts[id];
  const list = s.messages[id] || [];
  const [text, setText] = useState('');
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const recRef = useRef(null);
  const ref = useRef(null);
  const on = isOnline(c);

  useEffect(() => {
    if (!recording) return undefined;
    const t = setInterval(() => setRecSecs((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);
  useEffect(() => () => { if (recRef.current) recRef.current.stopAndUnloadAsync().catch(() => {}); }, []);

  const startRec = async () => {
    try {
      const p = await Audio.requestPermissionsAsync();
      if (!p.granted) return;
      await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
      const r = new Audio.Recording();
      await r.prepareToRecordAsync(REC_OPTS);
      await r.startAsync();
      recRef.current = r;
      setRecSecs(0);
      setRecording(true);
    } catch (e) { setRecording(false); }
  };
  const stopRec = async (sendIt) => {
    const r = recRef.current;
    recRef.current = null;
    setRecording(false);
    if (!r) return;
    try {
      const stt = await r.getStatusAsync();
      await r.stopAndUnloadAsync();
      await Audio.setAudioModeAsync({ allowsRecordingIOS: false });
      const uri = r.getURI();
      if (sendIt && uri && stt.durationMillis > 700) await net.sendVoice(id, uri, stt.durationMillis);
    } catch (e) {}
  };

  const send = () => {
    if (!text.trim()) return;
    net.sendMessage(id, text);
    setText('');
  };

  return (
    <KeyboardAvoidingView style={[st.flex, { backgroundColor: C.bg }]} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={[st.header, { flexDirection: 'row', alignItems: 'center' }]}>
        <TouchableOpacity onPress={onBack} style={{ paddingRight: 14 }}>
          <Text style={st.back}>‹</Text>
        </TouchableOpacity>
        <View style={st.flex}>
          <Text style={st.title}>{c.name}</Text>
          <Text style={st.headSub}>{on ? 'online' : 'offline'}</Text>
        </View>
        <TouchableOpacity onPress={() => call.startCall(id)} style={{ padding: 8 }}>
          <Text style={{ fontSize: 22, opacity: on ? 1 : 0.4 }}>📞</Text>
        </TouchableOpacity>
      </View>
      {!on && <Text style={st.banner}>Offline. Messages will send when they come back on this WiFi.</Text>}
      <FlatList
        ref={ref}
        data={list}
        keyExtractor={(m) => m.id}
        contentContainerStyle={{ padding: 10 }}
        onContentSizeChange={() => ref.current && ref.current.scrollToEnd({ animated: false })}
        renderItem={({ item }) => {
          if (item.kind === 'call') {
            return <Text style={st.callNote}>{item.text} · {hhmm(item.ts)}</Text>;
          }
          const failed = item.mine && item.status === 'failed';
          const mark = !item.mine ? '' : item.status === 'delivered' ? ' ✓' : failed ? ' ! tap to retry' : ' …';
          return (
            <TouchableOpacity
              activeOpacity={failed ? 0.6 : 1}
              onPress={() => failed && net.retry(id, item.id)}
              style={[st.bubble, item.mine ? st.mine : st.theirs]}
            >
              {item.kind === 'voice' ? <VoiceBubble m={item} /> : <Text style={st.msgTxt}>{item.text}</Text>}
              <Text style={[st.time, failed && { color: C.red }]}>{hhmm(item.ts)}{mark}</Text>
            </TouchableOpacity>
          );
        }}
      />
      <View style={st.inputRow}>
        {recording ? (
          <>
            <TouchableOpacity style={[st.send, { backgroundColor: '#94A3B8', marginLeft: 0, marginRight: 8 }]} onPress={() => stopRec(false)}>
              <Text style={st.sendTxt}>✕</Text>
            </TouchableOpacity>
            <View style={[st.input, { justifyContent: 'center', height: 46 }]}>
              <Text style={{ color: C.red, fontSize: 16 }}>● Recording {mmss(recSecs)}</Text>
            </View>
            <TouchableOpacity style={st.send} onPress={() => stopRec(true)}>
              <Text style={st.sendTxt}>➤</Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <TextInput
              style={st.input}
              placeholder="Message"
              placeholderTextColor="#94A3B8"
              value={text}
              onChangeText={setText}
              multiline
            />
            {text.trim() ? (
              <TouchableOpacity style={st.send} onPress={send}><Text style={st.sendTxt}>➤</Text></TouchableOpacity>
            ) : (
              <TouchableOpacity style={st.send} onPress={startRec}><Text style={st.sendTxt}>🎤</Text></TouchableOpacity>
            )}
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const st = StyleSheet.create({
  flex: { flex: 1 },
  center: { alignItems: 'center', justifyContent: 'center' },
  header: { backgroundColor: C.dark, paddingTop: TOP + 10, paddingBottom: 14, paddingHorizontal: 16 },
  title: { color: '#fff', fontSize: 19, fontWeight: '700' },
  headSub: { color: '#B6EDE4', fontSize: 12, marginTop: 2 },
  back: { color: '#fff', fontSize: 34, lineHeight: 34 },
  bigTitle: { color: '#fff', fontSize: 30, fontWeight: '800' },
  setupSub: { color: '#B6EDE4', textAlign: 'center', marginTop: 10, marginBottom: 30, fontSize: 15 },
  nameInput: { backgroundColor: '#fff', borderRadius: 12, padding: 14, fontSize: 17, width: '100%', color: C.text },
  startBtn: { backgroundColor: C.mid, borderRadius: 12, paddingVertical: 14, width: '100%', alignItems: 'center', marginTop: 14 },
  startTxt: { color: '#fff', fontSize: 17, fontWeight: '700' },
  empty: { textAlign: 'center', color: C.sub, fontSize: 15, padding: 30, lineHeight: 22 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 16, borderBottomWidth: StyleSheet.hairlineWidth, borderColor: '#E2E8F0' },
  avatar: { width: 48, height: 48, borderRadius: 24, backgroundColor: C.mid, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  avatarTxt: { color: '#fff', fontSize: 20, fontWeight: '700' },
  dot: { position: 'absolute', right: 0, bottom: 0, width: 13, height: 13, borderRadius: 7, borderWidth: 2, borderColor: '#fff' },
  name: { fontSize: 16, fontWeight: '600', color: C.text },
  preview: { fontSize: 14, color: C.sub, marginTop: 2 },
  badge: { backgroundColor: C.mid, minWidth: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  badgeTxt: { color: '#fff', fontSize: 12, fontWeight: '700' },
  banner: { backgroundColor: '#FEF3C7', color: '#92400E', fontSize: 12, textAlign: 'center', padding: 6 },
  bubble: { maxWidth: '80%', borderRadius: 12, paddingVertical: 7, paddingHorizontal: 11, marginVertical: 3 },
  mine: { alignSelf: 'flex-end', backgroundColor: C.mine },
  theirs: { alignSelf: 'flex-start', backgroundColor: '#fff' },
  msgTxt: { fontSize: 16, color: C.text },
  time: { fontSize: 11, color: C.sub, alignSelf: 'flex-end', marginTop: 2 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', padding: 8 },
  input: { flex: 1, backgroundColor: '#fff', borderRadius: 22, paddingHorizontal: 16, paddingVertical: 9, fontSize: 16, maxHeight: 120, color: C.text },
  send: { backgroundColor: C.dark, width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', marginLeft: 8 },
  sendTxt: { color: '#fff', fontSize: 18 },
  callNote: { alignSelf: 'center', backgroundColor: '#E2E8F0', color: C.sub, fontSize: 12, paddingVertical: 4, paddingHorizontal: 12, borderRadius: 10, marginVertical: 6, overflow: 'hidden' },
  voiceRow: { flexDirection: 'row', alignItems: 'center', minWidth: 190 },
  playBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: C.dark, alignItems: 'center', justifyContent: 'center' },
  playTxt: { color: '#fff', fontSize: 13 },
  wave: { flexDirection: 'row', alignItems: 'center', flex: 1, marginHorizontal: 10, height: 20 },
  bar: { width: 3, borderRadius: 2, backgroundColor: C.mid, marginRight: 3 },
  dur: { fontSize: 12, color: C.sub },
  callWrap: { ...StyleSheet.absoluteFillObject, backgroundColor: C.dark, alignItems: 'center', justifyContent: 'center', padding: 30 },
  callAvatar: { width: 120, height: 120, borderRadius: 60, backgroundColor: C.mid, alignItems: 'center', justifyContent: 'center' },
  callAvatarTxt: { color: '#fff', fontSize: 52, fontWeight: '700' },
  callName: { color: '#fff', fontSize: 28, fontWeight: '700', marginTop: 22 },
  callStatus: { color: '#B6EDE4', fontSize: 17, marginTop: 8, marginBottom: 70 },
  callRow: { flexDirection: 'row', justifyContent: 'center' },
  callBtn: { width: 68, height: 68, borderRadius: 34, alignItems: 'center', justifyContent: 'center', marginHorizontal: 18 },
  callBtnTxt: { color: '#fff', fontSize: 26 },
});
