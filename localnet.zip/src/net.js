import dgram from 'react-native-udp';
import TcpSocket from 'react-native-tcp-socket';
import * as Network from 'expo-network';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';

const UDP_PORT = 45454;
const TCP_PORT = 45455;
const BEAT_MS = 3000;
export const ONLINE_MS = 10000;

let me = null;
let contacts = {};
let messages = {};
let ready = false;
let activePeer = null;
let started = false;
let session = false;
let server = null;
let tickTimer = null;
let signalHandler = null;
let udp = null;
let snapshot = { me: null, contacts: {}, messages: {}, ready: false, session: false };
const listeners = new Set();

export const genId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const cleanIp = (ip) => String(ip || '').replace('::ffff:', '');

function publish() {
  snapshot = { me, contacts: { ...contacts }, messages: { ...messages }, ready, session };
  listeners.forEach((f) => f());
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snapshot;
export const getContact = (id) => contacts[id];
export const setSignalHandler = (f) => { signalHandler = f; };
export const addLocalMessage = (peerId, msg) => addMessage(peerId, msg);

let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(async () => {
    saveTimer = null;
    try {
      await AsyncStorage.setItem('ln_contacts', JSON.stringify(contacts));
      await AsyncStorage.setItem('ln_messages', JSON.stringify(messages));
    } catch (e) {}
  }, 500);
}

const hash = (str) => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0; return String(h); };

export async function init() {
  try {
    const p = await AsyncStorage.getItem('ln_account');
    const c = await AsyncStorage.getItem('ln_contacts');
    const m = await AsyncStorage.getItem('ln_messages');
    const ss = await AsyncStorage.getItem('ln_session');
    me = p ? JSON.parse(p) : null;
    contacts = c ? JSON.parse(c) : {};
    messages = m ? JSON.parse(m) : {};
    session = !!(me && ss === '1');
  } catch (e) {}
  ready = true;
  publish();
  if (session) start();
}

export async function register({ name, username, password }) {
  const n = String(name || '').trim();
  const u = String(username || '').trim().toLowerCase().replace(/\s+/g, '');
  if (!n || !u || !password) return 'Please fill in all fields.';
  if (String(password).length < 4) return 'Password must be at least 4 characters.';
  if (me) return 'An account already exists on this phone. Please log in.';
  me = { id: genId(), name: n, username: u, ph: hash(u + ':' + password) };
  session = true;
  try {
    await AsyncStorage.setItem('ln_account', JSON.stringify(me));
    await AsyncStorage.setItem('ln_session', '1');
  } catch (e) {}
  publish();
  start();
  return null;
}

export async function login({ username, password }) {
  const u = String(username || '').trim().toLowerCase();
  if (!me || me.username !== u || me.ph !== hash(u + ':' + password)) return 'Invalid username or password.';
  session = true;
  try { await AsyncStorage.setItem('ln_session', '1'); } catch (e) {}
  publish();
  start();
  return null;
}

export async function logout() {
  session = false;
  stop();
  try { await AsyncStorage.setItem('ln_session', '0'); } catch (e) {}
  publish();
}

function start() {
  if (started || !me) return;
  started = true;
  startServer();
  startUdp();
  tickTimer = setInterval(tick, BEAT_MS);
  tick();
}

function stop() {
  clearInterval(tickTimer);
  tickTimer = null;
  try { udp && udp.close(); } catch (e) {}
  try { server && server.close(); } catch (e) {}
  udp = null;
  server = null;
  started = false;
}

const hello = (r) => JSON.stringify({ t: 'hi', id: me.id, name: me.name, username: me.username, r });

function sendUdp(text, addr) {
  try { udp.send(text, undefined, undefined, UDP_PORT, addr, () => {}); } catch (e) {}
}

function startUdp() {
  try {
    udp = dgram.createSocket({ type: 'udp4', reusePort: true });
    udp.on('error', () => {});
    udp.on('message', (buf, rinfo) => {
      try {
        const d = JSON.parse(buf.toString());
        if (d.t !== 'hi' || !d.id || d.id === me.id) return;
        touchContact(d.id, d.name, cleanIp(rinfo.address), d.username);
        if (d.r !== 1) sendUdp(hello(1), cleanIp(rinfo.address));
      } catch (e) {}
    });
    udp.bind(UDP_PORT, () => { try { udp.setBroadcast(true); } catch (e) {} });
  } catch (e) {}
}

async function tick() {
  if (udp) {
    const targets = new Set(['255.255.255.255', '192.168.43.255']);
    try {
      const ip = await Network.getIpAddressAsync();
      const p = String(ip).split('.');
      if (p.length === 4 && ip !== '0.0.0.0') { p[3] = '255'; targets.add(p.join('.')); }
    } catch (e) {}
    targets.forEach((a) => sendUdp(hello(0), a));
  }
  publish();
}

function touchContact(id, name, ip, username) {
  const old = contacts[id];
  const wasOffline = !old || Date.now() - old.lastSeen > ONLINE_MS;
  contacts[id] = { id, name: name || (old && old.name) || 'Unknown', username: username || (old && old.username) || '', ip: ip || (old && old.ip), lastSeen: Date.now() };
  if (!old || old.ip !== contacts[id].ip || old.name !== contacts[id].name) save();
  publish();
  if (wasOffline) retryFailed(id);
}

function startServer() {
  try {
    server = TcpSocket.createServer((socket) => {
      let buf = '';
      socket.on('data', (data) => {
        buf += data.toString('utf8');
        if (buf.length > 4000000) { try { socket.destroy(); } catch (e) {} return; }
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i);
          buf = buf.slice(i + 1);
          handleLine(line, socket);
        }
      });
      socket.on('error', () => {});
    });
    server.on('error', () => {});
    server.listen({ port: TCP_PORT, host: '0.0.0.0', reuseAddress: true });
  } catch (e) {}
}

function handleLine(line, socket) {
  let d;
  try { d = JSON.parse(line); } catch (e) { return; }
  // Private: only accept anything addressed to this device.
  if (!d || d.to !== me.id || !d.from) return;
  const ip = cleanIp(socket.remoteAddress);
  if (d.t === 'msg' && d.id) {
    touchContact(d.from, d.fromName, ip, d.fromUsername);
    addMessage(d.from, { id: d.id, kind: 'text', mine: false, text: String(d.text || ''), ts: d.ts || Date.now(), read: activePeer === d.from });
    ack(socket, d.id);
  } else if (d.t === 'voice' && d.id && d.data && d.data.length < 3000000) {
    touchContact(d.from, d.fromName, ip, d.fromUsername);
    receiveVoice(d, socket);
  } else if (typeof d.t === 'string' && d.t.indexOf('call-') === 0) {
    touchContact(d.from, d.fromName, ip, d.fromUsername);
    if (signalHandler) { try { signalHandler(d); } catch (e) {} }
  }
}

function ack(socket, id) {
  try { socket.write(JSON.stringify({ t: 'ack', id }) + '\n'); } catch (e) {}
}

async function receiveVoice(d, socket) {
  try {
    if (!(messages[d.from] || []).some((m) => m.id === d.id)) {
      const dest = FileSystem.documentDirectory + 'vn_' + d.id + '.m4a';
      await FileSystem.writeAsStringAsync(dest, d.data, { encoding: FileSystem.EncodingType.Base64 });
      addMessage(d.from, { id: d.id, kind: 'voice', mine: false, uri: dest, dur: d.dur || 0, ts: d.ts || Date.now(), read: activePeer === d.from });
    }
    ack(socket, d.id);
  } catch (e) {}
}

function addMessage(peerId, msg) {
  const list = messages[peerId] || [];
  if (list.some((m) => m.id === msg.id)) return;
  messages[peerId] = [...list, msg];
  save();
  publish();
}

function setStatus(peerId, msgId, status) {
  messages[peerId] = (messages[peerId] || []).map((m) => (m.id === msgId ? { ...m, status } : m));
  save();
  publish();
}

async function deliver(peerId, msg) {
  const c = contacts[peerId];
  if (!c || !c.ip) { setStatus(peerId, msg.id, 'failed'); return; }
  let payload;
  try {
    if (msg.kind === 'voice') {
      const data = await FileSystem.readAsStringAsync(msg.uri, { encoding: FileSystem.EncodingType.Base64 });
      payload = { t: 'voice', id: msg.id, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId, dur: msg.dur, data, ts: msg.ts };
    } else {
      payload = { t: 'msg', id: msg.id, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId, text: msg.text, ts: msg.ts };
    }
  } catch (e) { setStatus(peerId, msg.id, 'failed'); return; }
  let done = false;
  let client = null;
  const finish = (st) => {
    if (done) return;
    done = true;
    setStatus(peerId, msg.id, st);
    try { client && client.destroy(); } catch (e) {}
  };
  try {
    client = TcpSocket.createConnection({ host: c.ip, port: TCP_PORT }, () => {
      client.write(JSON.stringify(payload) + '\n');
    });
    let buf = '';
    client.on('data', (x) => { buf += x.toString('utf8'); if (buf.indexOf('"ack"') >= 0) finish('delivered'); });
    client.on('error', () => finish('failed'));
    client.on('close', () => finish('failed'));
    setTimeout(() => finish('failed'), msg.kind === 'voice' ? 25000 : 6000);
  } catch (e) { finish('failed'); }
}

export function sendSignal(peerId, obj) {
  const c = contacts[peerId];
  if (!c || !c.ip || !me) return;
  let client = null;
  try {
    client = TcpSocket.createConnection({ host: c.ip, port: TCP_PORT }, () => {
      client.write(JSON.stringify({ ...obj, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId }) + '\n');
      setTimeout(() => { try { client.destroy(); } catch (e) {} }, 1500);
    });
    client.on('error', () => {});
  } catch (e) {}
}

export function sendMessage(peerId, text) {
  const t = String(text || '').trim();
  if (!t || !contacts[peerId]) return;
  const msg = { id: genId(), kind: 'text', mine: true, text: t, ts: Date.now(), status: 'sending' };
  addMessage(peerId, msg);
  deliver(peerId, msg);
}

export async function sendVoice(peerId, uri, dur) {
  if (!contacts[peerId]) return;
  let dest = uri;
  try {
    dest = FileSystem.documentDirectory + 'vn_' + genId() + '.m4a';
    await FileSystem.copyAsync({ from: uri, to: dest });
  } catch (e) { dest = uri; }
  const msg = { id: genId(), kind: 'voice', mine: true, uri: dest, dur, ts: Date.now(), status: 'sending' };
  addMessage(peerId, msg);
  deliver(peerId, msg);
}

export function retry(peerId, msgId) {
  const m = (messages[peerId] || []).find((x) => x.id === msgId);
  if (!m || m.kind === 'call' || m.status === 'sending' || m.status === 'delivered') return;
  setStatus(peerId, msgId, 'sending');
  deliver(peerId, m);
}

function retryFailed(peerId) {
  (messages[peerId] || []).filter((m) => m.mine && m.status === 'failed').forEach((m) => retry(peerId, m.id));
}

export function setActive(id) {
  activePeer = id;
  if (id && messages[id]) {
    messages[id] = messages[id].map((m) => (m.mine ? m : { ...m, read: true }));
    save();
    publish();
  }
}
