import TcpSocket from 'react-native-tcp-socket';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState } from 'react-native';
import * as crypto from './crypto';

// Industrial gateway / router link.
//
// Wire format (newline-delimited JSON over TCP, default port 45460):
//   phone   -> gateway : {"t":"gw-hello","id","name","pk"}        (plain, public key only)
//   gateway -> phone   : {"t":"gw-hi","id","name","pk"}           (plain, public key only)
//   after that every payload is encrypted with X25519 + XSalsa20-Poly1305 (same box as crypto.js):
//                        {"t":"gw-e","n":<nonce b64>,"c":<cipher b64>}   (inner JSON: {t:'msg'|'ack'|...})
//   keep-alive         : phone sends {"t":"ping"}, gateway must answer {"t":"pong"} (or any frame)
//
// Security rules:
//   * The gateway public key is pinned the first time it is seen. If it changes later the link is
//     refused ('key-changed') until the user removes the gateway.
//   * Nothing except gw-hi / pong is ever accepted in plain text. There is NO plain-text fallback.

export const DEFAULT_PORTS = [45460];

const PROBE_MS = 450;        // TCP connect timeout while scanning
const HELLO_MS = 1500;       // wait for gw-hi after connecting
const CONNECT_MS = 5000;     // normal connect timeout
const PING_MS = 10000;
const DEAD_MS = 25000;       // no frame for this long => link is dead, reconnect
const MAX_BACKOFF = 30000;
const SCAN_CONCURRENCY = 24;
const WATCHDOG_MS = 5000;

let me = null;
let gws = {};                // id -> { id, name, ip, port, pk }
let links = {};              // id -> { sock, state, buf, lastRx, tries, retry, ping }
let pending = {};            // msgId -> { resolve, timer }
let subnets = [];
let ports = DEFAULT_PORTS;
let started = false;
let scanning = false;
let nextScan = 0;
let scanFails = 0;
let watchdog = null;
let lastWatch = 0;
let appSub = null;
let handler = { onAlive: () => {}, onMessage: () => {} };
let snap = [];
const listeners = new Set();

const now = () => Date.now();
const jitter = (ms) => ms * (0.8 + Math.random() * 0.4);
const clean = (ip) => String(ip || '').replace('::ffff:', '');

function publish() {
  snap = Object.values(gws).map((g) => ({
    id: g.id, name: g.name, ip: g.ip, port: g.port,
    state: (links[g.id] && links[g.id].state) || 'down',
  }));
  listeners.forEach((f) => f());
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snap;
export const isUp = (id) => !!(links[id] && links[id].state === 'up');
export const anyUp = () => Object.keys(links).some((id) => links[id].state === 'up');
export const setHandler = (h) => { handler = { ...handler, ...h }; };
export const setPorts = (p) => { if (Array.isArray(p) && p.length) ports = p.map(Number).filter(Boolean); };

async function saveGws() {
  try { await AsyncStorage.setItem('ln_gateways', JSON.stringify(gws)); } catch (e) {}
}

async function loadGws() {
  try {
    const raw = await AsyncStorage.getItem('ln_gateways');
    gws = raw ? JSON.parse(raw) : {};
  } catch (e) { gws = {}; }
}

const hello = () => JSON.stringify({ t: 'gw-hello', id: me.id, name: me.name, pk: crypto.myPublicKey() }) + '\n';

// ---------------------------------------------------------------- probing (discovery)

// Opens a short connection, sends gw-hello and returns {id,name,pk} if a gateway answers gw-hi.
function probe(ip, port, connectMs) {
  return new Promise((resolve) => {
    let done = false;
    let sock = null;
    let buf = '';
    const finish = (r) => {
      if (done) return;
      done = true;
      clearTimeout(t1);
      clearTimeout(t2);
      try { sock && sock.destroy(); } catch (e) {}
      resolve(r);
    };
    const t1 = setTimeout(() => finish(null), connectMs + HELLO_MS);
    let t2 = null;
    try {
      sock = TcpSocket.createConnection({ host: ip, port }, () => {
        t2 = setTimeout(() => finish(null), HELLO_MS);
        try { sock.write(hello()); } catch (e) { finish(null); }
      });
      sock.on('data', (d) => {
        buf += d.toString('utf8');
        const i = buf.indexOf('\n');
        if (i < 0) { if (buf.length > 4096) finish(null); return; }
        try {
          const o = JSON.parse(buf.slice(0, i));
          if (o && o.t === 'gw-hi' && o.id && o.pk) finish({ id: String(o.id), name: String(o.name || 'Gateway'), pk: String(o.pk) });
          else finish(null);
        } catch (e) { finish(null); }
      });
      sock.on('error', () => finish(null));
      sock.on('close', () => finish(null));
    } catch (e) { finish(null); }
  });
}

async function pool(items, n, fn) {
  let i = 0;
  const run = async () => {
    while (i < items.length) {
      const x = items[i++];
      try { await fn(x); } catch (e) {}
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, run));
}

function register(found, ip, port) {
  const old = gws[found.id];
  if (old && old.pk && old.pk !== found.pk) {
    // pinned key differs: do not trust this device
    if (links[found.id]) links[found.id].state = 'key-changed';
    publish();
    return false;
  }
  const changed = !old || old.ip !== ip || old.port !== port || old.pk !== found.pk || old.name !== found.name;
  gws[found.id] = { id: found.id, name: found.name, ip, port, pk: found.pk };
  if (changed) saveGws();
  publish();
  return true;
}

// Sweep the local subnets (own Wi-Fi, hotspot, Wi-Fi Direct) for gateways.
// Router-like addresses (.1, .254, ...) go first so the usual case is found in under a second.
export async function scan() {
  if (!started || scanning || !subnets.length) return 0;
  scanning = true;
  let found = 0;
  try {
    const first = [1, 254, 2, 100, 101, 200, 10, 50];
    const order = first.concat(Array.from({ length: 254 }, (_, i) => i + 1).filter((n) => first.indexOf(n) < 0));
    const targets = [];
    subnets.forEach((p) => order.forEach((h) => ports.forEach((port) => targets.push([`${p}.${h}`, port]))));
    // already-connected gateways do not need probing
    const skip = new Set(Object.keys(links).filter((id) => links[id].state === 'up').map((id) => gws[id] && gws[id].ip + ':' + gws[id].port));
    await pool(targets.filter((t) => !skip.has(t[0] + ':' + t[1])), SCAN_CONCURRENCY, async ([ip, port]) => {
      const r = await probe(ip, port, PROBE_MS);
      if (r && register(r, ip, port)) { found += 1; connect(r.id); }
    });
  } finally {
    scanning = false;
    scanFails = found ? 0 : Math.min(scanFails + 1, 5);
    nextScan = now() + Math.min(120000, 20000 * (1 + scanFails));
  }
  return found;
}

export async function addManual(ip, port) {
  const p = Number(port) || ports[0];
  const r = await probe(clean(ip), p, CONNECT_MS);
  if (!r) return false;
  if (!register(r, clean(ip), p)) return false;
  connect(r.id);
  return true;
}

export function remove(id) {
  drop(id, true);
  delete gws[id];
  delete links[id];
  saveGws();
  publish();
}

// ---------------------------------------------------------------- persistent link

function drop(id, final) {
  const l = links[id];
  if (!l) return;
  clearTimeout(l.retry);
  clearInterval(l.ping);
  clearTimeout(l.ct);
  const s = l.sock;
  l.sock = null;
  l.connecting = false;
  if (!final && l.state !== 'key-changed') l.state = 'down';
  try { s && s.destroy(); } catch (e) {}
}

function schedule(id) {
  const l = links[id];
  if (!l || !started || l.state === 'key-changed' || l.retry) return;
  l.tries = (l.tries || 0) + 1;
  const wait = jitter(Math.min(MAX_BACKOFF, 1000 * Math.pow(2, Math.min(l.tries - 1, 5))));
  l.retry = setTimeout(() => { l.retry = null; connect(id); }, wait);
  // gateway may have received a new DHCP address: rescan after a few failures
  if (l.tries === 3 && now() >= nextScan) { nextScan = 0; }
}

function closed(id, sock) {
  const l = links[id];
  if (!l || (l.sock && l.sock !== sock)) return;
  const was = l.state;
  drop(id, false);
  if (was !== l.state || was === 'up') publish();
  schedule(id);
}

export function connect(id) {
  const g = gws[id];
  if (!started || !g || !me) return;
  const l = links[id] || (links[id] = { state: 'down', tries: 0 });
  if (l.sock || l.connecting || l.state === 'key-changed') return;
  clearTimeout(l.retry);
  l.retry = null;
  l.connecting = true;
  l.state = 'connecting';
  l.buf = '';
  publish();
  let sock = null;
  try {
    sock = TcpSocket.createConnection({ host: g.ip, port: g.port }, () => {
      l.sock = sock;
      try { sock.setKeepAlive && sock.setKeepAlive(true, 10000); } catch (e) {}
      try { sock.setNoDelay && sock.setNoDelay(true); } catch (e) {}
      try { sock.write(hello()); } catch (e) { closed(id, sock); }
    });
    l.sock = sock;
    l.lastRx = now();
    l.ct = setTimeout(() => { if (l.state !== 'up') { try { sock.destroy(); } catch (e) {} closed(id, sock); } }, CONNECT_MS + HELLO_MS);
    sock.on('data', (d) => onData(id, sock, d));
    sock.on('error', () => closed(id, sock));
    sock.on('close', () => closed(id, sock));
  } catch (e) {
    l.connecting = false;
    l.state = 'down';
    schedule(id);
  }
}

function onData(id, sock, data) {
  const l = links[id];
  if (!l || l.sock !== sock) return;
  l.buf += data.toString('utf8');
  if (l.buf.length > 4000000) { try { sock.destroy(); } catch (e) {} return; }
  let i;
  while ((i = l.buf.indexOf('\n')) >= 0) {
    const line = l.buf.slice(0, i);
    l.buf = l.buf.slice(i + 1);
    onLine(id, sock, line);
  }
}

function onLine(id, sock, line) {
  const l = links[id];
  const g = gws[id];
  let o;
  try { o = JSON.parse(line); } catch (e) { return; }
  if (!o || !g) return;
  l.lastRx = now();

  if (o.t === 'gw-hi') {
    if (!o.pk || String(o.id) !== id) return;
    if (g.pk && g.pk !== String(o.pk)) {
      l.state = 'key-changed';
      drop(id, false);
      publish();
      return;
    }
    l.connecting = false;
    clearTimeout(l.ct);
    l.state = 'up';
    l.tries = 0;
    scanFails = 0;
    clearInterval(l.ping);
    l.ping = setInterval(() => { try { sock.write('{"t":"ping"}\n'); } catch (e) { closed(id, sock); } }, PING_MS);
    publish();
    handler.onAlive(g);
    return;
  }
  if (l.state !== 'up') return;           // nothing is accepted before the handshake
  if (o.t === 'pong') { handler.onAlive(g); return; }
  if (o.t !== 'gw-e' || !o.n || !o.c) return;   // plain text is never accepted
  const bytes = crypto.decryptFrom(g.pk, o.n, o.c);
  if (!bytes) return;
  let inner;
  try { inner = JSON.parse(crypto.text(bytes)); } catch (e) { return; }
  handler.onAlive(g);
  if (inner && inner.t === 'ack' && inner.id && pending[inner.id]) {
    clearTimeout(pending[inner.id].timer);
    pending[inner.id].resolve(true);
    delete pending[inner.id];
    return;
  }
  try { handler.onMessage(g, inner); } catch (e) {}
}

// Encrypt obj for the gateway and (when obj.id is set) wait for its ack. Resolves true/false.
export function sendEncrypted(id, obj, timeoutMs = 6000) {
  return new Promise((resolve) => {
    const l = links[id];
    const g = gws[id];
    if (!l || !g || l.state !== 'up' || !l.sock || !g.pk || !crypto.ready()) {
      connect(id);
      resolve(false);
      return;
    }
    try {
      const e = crypto.encryptTo(g.pk, crypto.utf8(JSON.stringify(obj)));
      l.sock.write(JSON.stringify({ t: 'gw-e', n: e.n, c: e.c }) + '\n');
    } catch (err) { resolve(false); return; }
    if (!obj.id) { resolve(true); return; }
    const timer = setTimeout(() => { delete pending[obj.id]; resolve(false); }, timeoutMs);
    pending[obj.id] = { resolve, timer };
  });
}

// ---------------------------------------------------------------- lifecycle

function tickWatch() {
  if (!started) return;
  const t = now();
  const slept = lastWatch && t - lastWatch > WATCHDOG_MS * 3;   // phone was asleep / frozen
  lastWatch = t;
  if (slept) { wake(); return; }
  Object.keys(links).forEach((id) => {
    const l = links[id];
    if (l.state === 'up' && t - l.lastRx > DEAD_MS) {
      const s = l.sock;
      drop(id, false);
      publish();
      try { s && s.destroy(); } catch (e) {}
      schedule(id);
    } else if (l.state === 'down' && !l.retry && !l.connecting) {
      schedule(id);
    }
  });
  if (!anyUp() && !scanning && subnets.length && t >= nextScan) scan();
}

// Force every link to reconnect right now (wake from sleep, app back in front, network changed).
export function wake() {
  if (!started) return;
  Object.keys(gws).forEach((id) => {
    const l = links[id] || (links[id] = { state: 'down', tries: 0 });
    if (l.state === 'key-changed') return;
    drop(id, false);
    l.tries = 0;
    connect(id);
  });
  nextScan = 0;
  publish();
}

export function networkChanged(list) {
  const key = (a) => a.slice().sort().join(',');
  const changed = key(list) !== key(subnets);
  subnets = list.slice();
  if (changed && started) wake();
}

export async function start(identity) {
  if (started) return;
  me = identity;
  started = true;
  await loadGws();
  Object.keys(gws).forEach((id) => { links[id] = { state: 'down', tries: 0 }; });
  publish();
  Object.keys(gws).forEach(connect);
  lastWatch = now();
  watchdog = setInterval(tickWatch, WATCHDOG_MS);
  appSub = AppState.addEventListener('change', (st) => { if (st === 'active') wake(); });
}

export function stop() {
  started = false;
  clearInterval(watchdog);
  watchdog = null;
  try { appSub && appSub.remove(); } catch (e) {}
  appSub = null;
  Object.keys(links).forEach((id) => drop(id, true));
  links = {};
  Object.keys(pending).forEach((k) => { clearTimeout(pending[k].timer); pending[k].resolve(false); });
  pending = {};
  publish();
}
