import TcpSocket from 'react-native-tcp-socket';
import { getSecure, setSecure } from './secure';
import { AppState } from 'react-native';
import nacl from 'tweetnacl';
import * as crypto from './crypto';

// Industrial gateway / router link.
//
// Wire format (newline-delimited JSON over TCP, default port 45460):
//   phone   -> gateway : {"t":"gw-hello","id","name","pk"}        (plain, public key only)
//   gateway -> phone   : {"t":"gw-hi","id","name","pk"}           (plain, public key only)
//   password (optional): gw-hi may carry {"auth":true,"nonce":"<random>"}. The phone then answers
//                        {"t":"gw-auth","proof":hex(sha512(nonce+"|"+password+"|"+phonePk))} and the gateway
//                        replies {"t":"gw-ok"} or {"t":"gw-deny"}. The password itself is never sent.
//   after that every payload is encrypted with X25519 + XSalsa20-Poly1305 (same box as crypto.js):
//                        {"t":"gw-e","n":<nonce b64>,"c":<cipher b64>}   (inner JSON: {t:'msg'|'ack'|...})
//   keep-alive         : phone sends {"t":"ping"}, gateway must answer {"t":"pong"} (or any frame)
//
// Security rules:
//   * The gateway public key is pinned the first time it is seen. If it changes later the link is
//     refused ('key-changed') until the user removes the gateway.
//   * Nothing except gw-hi / pong is ever accepted in plain text. There is NO plain-text fallback.

export const DEFAULT_PORTS = [45460];

const PROBE_MS = 450;        // TCP connect timeout while scanning
const HELLO_MS = 1500;       // wait for gw-hi after connecting
const CONNECT_MS = 5000;     // normal connect timeout
const PING_MS = 10000;
const DEAD_MS = 25000;       // no frame for this long => link is dead, reconnect
const MAX_BACKOFF = 30000;
const SCAN_CONCURRENCY = 8;
const WATCHDOG_MS = 5000;

let me = null;
let gws = {};                // id -> { id, name, ip, port, pk }
let links = {};              // id -> { sock, state, buf, lastRx, tries, retry, ping }
let pending = {};            // msgId -> { resolve, timer }
let subnets = [];
let ports = DEFAULT_PORTS;
let started = false;
let scanning = false;
let nextScan = 0;
let scanFails = 0;
let watchdog = null;
let lastWatch = 0;
let appSub = null;
let eco = false;              // battery saver: the links are only open in short check windows
let sleeping = false;
let windowTimer = null;
const ECO_WINDOW_MS = 5000;
let handler = { onAlive: () => {}, onMessage: () => {} };
let snap = [];
const listeners = new Set();
const BLOCKED = ['key-changed', 'need-password', 'wrong-password'];   // no automatic retry until the user edits it
const blocked = (l) => !!l && BLOCKED.indexOf(l.state) >= 0;

const now = () => Date.now();
const jitter = (ms) => ms * (0.8 + Math.random() * 0.4);
const clean = (ip) => String(ip || '').replace('::ffff:', '');

function publish() {
  snap = Object.values(gws).map((g) => ({
    id: g.id, name: g.name || g.devName || 'Gateway', ip: g.ip, port: g.port,
    auth: !!g.auth, hasPassword: !!g.password,
    state: (links[g.id] && links[g.id].state) || 'down',
  }));
  listeners.forEach((f) => f());
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snap;
export const isSleeping = () => sleeping;
export const isUp = (id) => !!(links[id] && links[id].state === 'up');
export const anyUp = () => Object.keys(links).some((id) => links[id].state === 'up');
export const setHandler = (h) => { handler = { ...handler, ...h }; };
export const setPorts = (p) => { if (Array.isArray(p) && p.length) ports = p.map(Number).filter(Boolean); };

async function saveGws() {
  try { await setSecure('ln_gateways', JSON.stringify(gws)); } catch (e) {}
}

async function loadGws() {
  try {
    const raw = await getSecure('ln_gateways');
    gws = raw ? JSON.parse(raw) : {};
  } catch (e) { gws = {}; }
}

const hello = () => JSON.stringify({ t: 'gw-hello', id: me.id, name: me.name, pk: crypto.myPublicKey() }) + '\n';

// ---------------------------------------------------------------- probing (discovery)

// Opens a short connection, sends gw-hello and returns {id,name,pk} if a gateway answers gw-hi.
function probe(ip, port, connectMs) {
  return new Promise((resolve) => {
    let done = false;
    let sock = null;
    let buf = '';
    const finish = (r) => {
      if (done) return;
      done = true;
      clearTimeout(t1);
      clearTimeout(t2);
      try { sock && sock.destroy(); } catch (e) {}
      resolve(r);
    };
    const t1 = setTimeout(() => finish(null), connectMs + HELLO_MS);
    let t2 = null;
    try {
      sock = TcpSocket.createConnection({ host: ip, port }, () => {
        t2 = setTimeout(() => finish(null), HELLO_MS);
        try { sock.write(hello()); } catch (e) { finish(null); }
      });
      sock.on('data', (d) => {
        buf += d.toString('utf8');
        const i = buf.indexOf('\n');
        if (i < 0) { if (buf.length > 4096) finish(null); return; }
        try {
          const o = JSON.parse(buf.slice(0, i));
          if (o && o.t === 'gw-hi' && o.id && o.pk) finish({ id: String(o.id), name: String(o.name || 'Gateway'), pk: String(o.pk), auth: !!o.auth });
          else finish(null);
        } catch (e) { finish(null); }
      });
      sock.on('error', () => finish(null));
      sock.on('close', () => finish(null));
    } catch (e) { finish(null); }
  });
}

async function pool(items, n, fn) {
  let i = 0;
  const run = async () => {
    while (i < items.length) {
      const x = items[i++];
      try { await fn(x); } catch (e) {}
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, run));
}

function register(found, ip, port) {
  const old = gws[found.id];
  if (old && old.pk && old.pk !== found.pk) {
    // pinned key differs: do not trust this device
    if (links[found.id]) links[found.id].state = 'key-changed';
    publish();
    return false;
  }
  // a gateway added by hand (key m:ip:port) at the same address is replaced by the real entry
  let password = old && old.password;
  let name = old && old.name;
  Object.keys(gws).forEach((k) => {
    const m = gws[k];
    if (k !== found.id && m.ip === ip && m.port === port && k.indexOf('m:') === 0) {
      password = password || m.password;
      name = name || m.name;
      drop(k, true);
      delete links[k];
      delete gws[k];
    }
  });
  const next = { id: found.id, name: name || '', devName: found.name, ip, port, pk: found.pk, auth: !!found.auth, password: password || '' };
  const changed = !old || old.ip !== ip || old.port !== port || old.pk !== found.pk || old.devName !== found.name || old.auth !== next.auth;
  gws[found.id] = next;
  if (changed) saveGws();
  publish();
  return true;
}

// Sweep the local subnets (own Wi-Fi, hotspot, Wi-Fi Direct) for gateways.
// Router-like addresses (.1, .254, ...) go first so the usual case is found in under a second.
export async function scan() {
  if (!started || sleeping || scanning || !subnets.length) return 0;
  scanning = true;
  let found = 0;
  try {
    const first = [1, 254, 2, 100, 101, 200, 10, 50];
    const order = first.concat(Array.from({ length: 254 }, (_, i) => i + 1).filter((n) => first.indexOf(n) < 0));
    const targets = [];
    subnets.forEach((p) => order.forEach((h) => ports.forEach((port) => targets.push([`${p}.${h}`, port]))));
    // already-connected gateways do not need probing
    const skip = new Set(Object.keys(links).filter((id) => links[id].state === 'up').map((id) => gws[id] && gws[id].ip + ':' + gws[id].port));
    await pool(targets.filter((t) => !skip.has(t[0] + ':' + t[1])), SCAN_CONCURRENCY, async ([ip, port]) => {
      const r = await probe(ip, port, PROBE_MS);
      if (r && register(r, ip, port)) { found += 1; connect(r.id); }
    });
  } finally {
    scanning = false;
    scanFails = found ? 0 : Math.min(scanFails + 1, 5);
    nextScan = now() + Math.min(600000, 60000 * (1 + scanFails));
  }
  return found;
}

export function getGateway(id) {
  const g = gws[id];
  return g ? { id: g.id, name: g.name || '', ip: g.ip, port: String(g.port), password: g.password || '' } : null;
}

// Create or edit a gateway from the settings screen. Works even if the gateway is not reachable yet:
// the phone keeps trying and connects by itself when it appears.
export function save({ id, name, ip, port, password }) {
  const addr = clean(ip).trim();
  const octets = addr.split('.').map(Number);
  if (octets.length !== 4 || octets.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) return { ok: false, error: 'Enter a valid IP address, e.g. 192.168.1.1' };
  const p = Number(port) || ports[0];
  if (!Number.isInteger(p) || p < 1 || p > 65535) return { ok: false, error: 'Enter a valid port (1-65535)' };
  const key = id && gws[id] ? id : 'm:' + addr + ':' + p;
  const dup = Object.values(gws).find((g) => g.id !== key && g.ip === addr && g.port === p);
  if (dup) return { ok: false, error: 'This gateway is already in the list' };
  const old = gws[key];
  const moved = !!old && (old.ip !== addr || old.port !== p);
  gws[key] = {
    id: key,
    name: String(name || '').trim(),
    devName: (old && old.devName) || '',
    ip: addr,
    port: p,
    pk: moved ? '' : (old && old.pk) || '',      // new address = new device: pin its key again
    auth: moved ? false : !!(old && old.auth),
    password: String(password || ''),
  };
  drop(key, true);
  links[key] = { state: 'down', tries: 0 };
  saveGws();
  publish();
  if (started) connect(key);
  return { ok: true };
}

export function remove(id) {
  drop(id, true);
  delete gws[id];
  delete links[id];
  saveGws();
  publish();
}

// ---------------------------------------------------------------- persistent link

function drop(id, final) {
  const l = links[id];
  if (!l) return;
  clearTimeout(l.retry);
  clearInterval(l.ping);
  clearTimeout(l.ct);
  const s = l.sock;
  l.sock = null;
  l.connecting = false;
  if (!final && !blocked(l)) l.state = 'down';
  try { s && s.destroy(); } catch (e) {}
}

function schedule(id) {
  const l = links[id];
  if (!l || !started || sleeping || blocked(l) || l.retry) return;
  l.tries = (l.tries || 0) + 1;
  const wait = jitter(Math.min(MAX_BACKOFF, 1000 * Math.pow(2, Math.min(l.tries - 1, 5))));
  l.retry = setTimeout(() => { l.retry = null; connect(id); }, wait);
  // gateway may have received a new DHCP address: rescan after a few failures
  if (l.tries === 3 && nextScan > now() + 20000) { nextScan = now() + 20000; }
}

function closed(id, sock) {
  const l = links[id];
  if (!l || (l.sock && l.sock !== sock)) return;
  const was = l.state;
  drop(id, false);
  if (was !== l.state || was === 'up') publish();
  schedule(id);
}

export function connect(id) {
  const g = gws[id];
  if (!started || sleeping || !g || !me) return;
  const l = links[id] || (links[id] = { state: 'down', tries: 0 });
  if (l.sock || l.connecting || blocked(l)) return;
  clearTimeout(l.retry);
  l.retry = null;
  l.connecting = true;
  l.state = 'connecting';
  l.buf = '';
  publish();
  let sock = null;
  try {
    sock = TcpSocket.createConnection({ host: g.ip, port: g.port }, () => {
      l.sock = sock;
      try { sock.setKeepAlive && sock.setKeepAlive(true, 10000); } catch (e) {}
      try { sock.setNoDelay && sock.setNoDelay(true); } catch (e) {}
      try { sock.write(hello()); } catch (e) { closed(id, sock); }
    });
    l.sock = sock;
    l.lastRx = now();
    l.ct = setTimeout(() => { if (l.state !== 'up') { try { sock.destroy(); } catch (e) {} closed(id, sock); } }, CONNECT_MS + HELLO_MS);
    sock.on('data', (d) => onData(id, sock, d));
    sock.on('error', () => closed(id, sock));
    sock.on('close', () => closed(id, sock));
  } catch (e) {
    l.connecting = false;
    l.state = 'down';
    schedule(id);
  }
}

function onData(id, sock, data) {
  const l = links[id];
  if (!l || l.sock !== sock) return;
  l.buf += data.toString('utf8');
  if (l.buf.length > 4000000) { try { sock.destroy(); } catch (e) {} return; }
  let i;
  while ((i = l.buf.indexOf('\n')) >= 0) {
    const line = l.buf.slice(0, i);
    l.buf = l.buf.slice(i + 1);
    onLine(id, sock, line);
  }
}

function setUp(id, sock) {
  const l = links[id];
  const g = gws[id];
  l.connecting = false;
  clearTimeout(l.ct);
  l.state = 'up';
  l.tries = 0;
  scanFails = 0;
  clearInterval(l.ping);
  l.ping = setInterval(() => { try { sock.write('{"t":"ping"}\n'); } catch (e) { closed(id, sock); } }, PING_MS);
  publish();
  handler.onAlive(g);
}

// Stop retrying until the user fixes the settings (wrong password, changed key...).
function block(id, state) {
  const l = links[id];
  if (!l) return;
  drop(id, false);
  l.state = state;
  publish();
}

// A gateway added by hand has no real id yet: once it introduces itself, store it under its real id.
function promote(oldId, realId, o) {
  const g = gws[oldId];
  if (!g) return;
  const known = gws[realId];
  gws[realId] = known
    ? { ...known, ip: g.ip, port: g.port, name: known.name || g.name, password: g.password || known.password }
    : { ...g, id: realId, devName: String(o.name || ''), pk: '', auth: !!o.auth };
  drop(oldId, true);
  delete links[oldId];
  delete gws[oldId];
  links[realId] = links[realId] || { state: 'down', tries: 0 };
  saveGws();
  publish();
  connect(realId);
}

function onLine(id, sock, line) {
  const l = links[id];
  const g = gws[id];
  let o;
  try { o = JSON.parse(line); } catch (e) { return; }
  if (!o || !g) return;
  l.lastRx = now();

  if (o.t === 'gw-hi') {
    if (!o.pk || !o.id || l.state === 'up') return;
    const realId = String(o.id);
    if (realId !== id) { promote(id, realId, o); return; }
    if (g.pk && g.pk !== String(o.pk)) { block(id, 'key-changed'); return; }
    if (!g.pk) { g.pk = String(o.pk); saveGws(); }
    g.devName = String(o.name || '');
    if (!!o.auth !== !!g.auth) { g.auth = !!o.auth; saveGws(); }
    if (o.auth) {
      if (!g.password) { block(id, 'need-password'); return; }
      if (!o.nonce) { block(id, 'wrong-password'); return; }
      l.state = 'authing';
      publish();
      const proof = Buffer.from(nacl.hash(crypto.utf8(String(o.nonce) + '|' + g.password + '|' + crypto.myPublicKey()))).toString('hex');
      try { sock.write(JSON.stringify({ t: 'gw-auth', proof }) + '\n'); } catch (e) { closed(id, sock); }
      return;
    }
    setUp(id, sock);
    return;
  }
  if (l.state === 'authing') {
    if (o.t === 'gw-ok') setUp(id, sock);
    else if (o.t === 'gw-deny') block(id, 'wrong-password');
    return;
  }
  if (l.state !== 'up') return;           // nothing is accepted before the handshake
  if (o.t === 'pong') { handler.onAlive(g); return; }
  if (o.t !== 'gw-e' || !o.n || !o.c) return;   // plain text is never accepted
  const bytes = crypto.decryptFrom(g.pk, o.n, o.c);
  if (!bytes) return;
  let inner;
  try { inner = JSON.parse(crypto.text(bytes)); } catch (e) { return; }
  handler.onAlive(g);
  if (inner && inner.t === 'ack' && inner.id && pending[inner.id]) {
    clearTimeout(pending[inner.id].timer);
    pending[inner.id].resolve(true);
    delete pending[inner.id];
    return;
  }
  try { handler.onMessage(g, inner); } catch (e) {}
}

// Encrypt obj for the gateway and (when obj.id is set) wait for its ack. Resolves true/false.
export function sendEncrypted(id, obj, timeoutMs = 6000) {
  return new Promise((resolve) => {
    const l = links[id];
    const g = gws[id];
    if (!l || !g || l.state !== 'up' || !l.sock || !g.pk || !crypto.ready()) {
      connect(id);
      resolve(false);
      return;
    }
    try {
      const e = crypto.encryptTo(g.pk, crypto.utf8(JSON.stringify(obj)));
      l.sock.write(JSON.stringify({ t: 'gw-e', n: e.n, c: e.c }) + '\n');
    } catch (err) { resolve(false); return; }
    if (!obj.id) { resolve(true); return; }
    const timer = setTimeout(() => { delete pending[obj.id]; resolve(false); }, timeoutMs);
    pending[obj.id] = { resolve, timer };
  });
}

// ---------------------------------------------------------------- lifecycle

function tickWatch() {
  if (!started || sleeping) return;
  const t = now();
  const slept = lastWatch && t - lastWatch > WATCHDOG_MS * 3;   // phone was asleep / frozen
  lastWatch = t;
  if (slept) { wake(); return; }
  Object.keys(links).forEach((id) => {
    const l = links[id];
    if (l.state === 'up' && t - l.lastRx > DEAD_MS) {
      const s = l.sock;
      drop(id, false);
      publish();
      try { s && s.destroy(); } catch (e) {}
      schedule(id);
    } else if (l.state === 'down' && !l.retry && !l.connecting) {
      schedule(id);
    }
  });
  // sweeping 250 addresses is heavy: only do it by itself when a saved gateway cannot be reached (it may have a new IP)
  if (Object.keys(gws).length > 0 && !anyUp() && !scanning && subnets.length && t >= nextScan) scan();
}

// Force every link to reconnect right now (wake from sleep, app back in front, network changed).
export function wake() {
  if (!started) return;
  Object.keys(gws).forEach((id) => {
    const l = links[id] || (links[id] = { state: 'down', tries: 0 });
    if (blocked(l)) return;
    drop(id, false);
    l.tries = 0;
    connect(id);
  });
  nextScan = now() + 20000;
  publish();
}

// ---- battery saver ----
// Between check windows every gateway link is closed and nothing runs. The native service wakes the phone
// every ~2 minutes (see LocalNetService.kt); the window keeps the links open for 3-5 seconds, collects whatever
// the gateway has for us, then everything sleeps again. Whenever the app is on screen it behaves normally.
function sleepNow() {
  if (!eco || !started || AppState.currentState === 'active') return;
  sleeping = true;
  Object.keys(links).forEach((id) => { drop(id, false); });
  publish();
}

export function ecoWindow(ms = ECO_WINDOW_MS) {
  if (!started || !eco) return;
  sleeping = false;
  wake();
  clearTimeout(windowTimer);
  windowTimer = setTimeout(sleepNow, Math.min(Math.max(ms, 3000), 5000));
}

export function setEco(on) {
  eco = !!on;
  clearTimeout(windowTimer);
  if (!eco) { sleeping = false; if (started) wake(); return; }
  if (started) windowTimer = setTimeout(sleepNow, ECO_WINDOW_MS);
}

export function networkChanged(list) {
  const key = (a) => a.slice().sort().join(',');
  const changed = key(list) !== key(subnets);
  subnets = list.slice();
  if (changed && started) wake();
}

export async function start(identity) {
  if (started) return;
  me = identity;
  started = true;
  await loadGws();
  Object.keys(gws).forEach((id) => { links[id] = { state: 'down', tries: 0 }; });
  publish();
  Object.keys(gws).forEach(connect);
  lastWatch = now();
  watchdog = setInterval(tickWatch, WATCHDOG_MS);
  appSub = AppState.addEventListener('change', (st) => {
    if (st === 'active') { sleeping = false; wake(); }
    else if (eco) { clearTimeout(windowTimer); windowTimer = setTimeout(sleepNow, ECO_WINDOW_MS); }
  });
}

export function stop() {
  started = false;
  sleeping = false;
  clearTimeout(windowTimer);
  clearInterval(watchdog);
  watchdog = null;
  try { appSub && appSub.remove(); } catch (e) {}
  appSub = null;
  Object.keys(links).forEach((id) => drop(id, true));
  links = {};
  Object.keys(pending).forEach((k) => { clearTimeout(pending[k].timer); pending[k].resolve(false); });
  pending = {};
  publish();
}
