import { Platform } from 'react-native';
import { requireOptionalNativeModule } from 'expo-modules-core';

// One place that talks to the Android native modules.
// A missing module (or any native error) never crashes the app: calls just return the fallback.
export function loadModule(name) {
  try {
    return Platform.OS === 'android' ? requireOptionalNativeModule(name) : null;
  } catch (e) {
    return null;
  }
}

export function guard(mod, fn, fallback) {
  try {
    return mod ? fn(mod) : fallback;
  } catch (e) {
    return fallback;
  }
}
