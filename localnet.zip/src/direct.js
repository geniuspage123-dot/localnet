import { AppState, PermissionsAndroid, Platform } from 'react-native';
import { loadModule } from './bridge';
import * as net from './net';

// Direct Wi-Fi (Wi-Fi Direct): connects phones without any router or hotspot.
// Used only when the phone is not on a normal Wi-Fi network.
// All phones use the same group name and password, so nobody has to accept an invitation:
// a phone first tries to join a nearby group, and if there is none it creates one.
const D = loadModule('LocalNetDirect');

const SSID = 'DIRECT-LN-LocalNetConnect';
const PASS = 'ln-direct-7f3a91c2';

const safe = (fn, fallback) => {
  try { return D ? fn() : fallback; } catch (e) { return fallback; }
};
const rand = (a, b) => a + Math.random() * (b - a);
const NO_GROUP = { formed: false, isOwner: false, owner: '' };

export const available = !!D;
export const supported = () => !!safe(() => D.isSupported(), false);
export const openWifiPanel = () => safe(() => D.openWifiPanel(), false);

// Voice over the local network (used for calls on Direct Wi-Fi)
export const lanAvailable = () => !!(D && D.lanStart);
export const lanStart = (ip, port) => !!safe(() => D.lanStart(String(ip), port), false);
export const lanStop = () => safe(() => D.lanStop(), false);
export const lanMute = (m) => safe(() => D.lanMute(!!m), false);
export const lanRxAge = () => safe(() => D.lanRxAge(), -1);
export const lanStats = () => safe(() => D.lanStats(), '0:0');

let enabled = true;
let wantNow = null;
let lastArgs = [false, true];
let running = false;
let starting = false;
let group = NO_GROUP;
let phase = 'idle';
let joinTries = 0;
let joinUntil = 0;
let hostUntil = 0;
let hostSince = 0;
let cooldownUntil = 0;
let jitterUntil = 0;
let timer = null;
let lastTick = 0;
let debounce = null;
let subs = [];
let snap = { status: 'off', formed: false };
const listeners = new Set();

function publish(status) {
  snap = { status, formed: group.formed };
  listeners.forEach((f) => f());
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snap;

async function ensurePerm() {
  try {
    if (Platform.Version >= 33) {
      const r = await PermissionsAndroid.request('android.permission.NEARBY_WIFI_DEVICES');
      return r === PermissionsAndroid.RESULTS.GRANTED;
    }
    const r = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);
    return r === PermissionsAndroid.RESULTS.GRANTED;
  } catch (e) {
    return false;
  }
}

function setGroup(g) {
  group = g;
  net.setDirectGroup(g);
}

// After the phone slept (or the app came back to the front) old timers and cool-downs are stale:
// forget them so the phone looks for / re-joins a group at once instead of waiting.
function resetWaits() {
  cooldownUntil = 0;
  joinUntil = 0;
  hostUntil = 0;
  jitterUntil = 0;
  if (!group.formed) { phase = 'idle'; joinTries = 0; }
}

export function wake() {
  if (!running) return;
  resetWaits();
  tick();
}

function tick() {
  if (!running || !D) return;
  const t0 = Date.now();
  if (lastTick && t0 - lastTick > 12000) resetWaits();   // timer was frozen: phone was asleep
  lastTick = t0;
  if (!safe(() => D.isWifiEnabled(), true)) { publish('needs-wifi'); return; }
  const now = Date.now();

  if (group.formed) {
    if (group.isOwner) {
      phase = 'hosting';
      const others = net.onlineCount();
      if (others > 0) hostSince = now;
      if (now - hostSince > 45000) {
        // nobody joined for a while: step down and look for another group
        safe(() => D.leave());
        setGroup(NO_GROUP);
        phase = 'idle';
        joinTries = 0;
        cooldownUntil = now + rand(3000, 12000);
        publish('searching');
        return;
      }
      publish(others > 0 ? 'connected' : 'hosting');
    } else {
      phase = 'connected';
      publish('connected');
    }
    return;
  }

  if (now < cooldownUntil) { publish('searching'); return; }
  if (phase === 'hosting' && now < hostUntil) { publish('hosting'); return; }
  if (phase === 'joining' && now < joinUntil) { publish('searching'); return; }

  if (phase === 'joining' && joinTries >= 2) {
    // nobody to join: become the host after a small random delay (avoids two hosts at once)
    if (!jitterUntil) { jitterUntil = now + rand(0, 7000); publish('searching'); return; }
    if (now < jitterUntil) { publish('searching'); return; }
    jitterUntil = 0;
    phase = 'hosting';
    hostUntil = now + 15000;
    hostSince = now;
    joinTries = 0;
    safe(() => D.host(SSID, PASS));
    publish('hosting');
    return;
  }

  phase = 'joining';
  joinTries += 1;
  joinUntil = now + 12000;
  safe(() => D.join(SSID, PASS));
  publish('searching');
}

async function begin() {
  if (running || starting || !D) return;
  starting = true;
  try {
    if (!supported()) { publish('unsupported'); return; }
    if (!(await ensurePerm())) { publish('needs-permission'); return; }
    if (!wantNow) return;
    subs = [
      D.addListener('onGroup', (e) => {
        setGroup({ formed: !!e.formed, isOwner: !!e.isOwner, owner: e.owner || '' });
        if (e.formed) joinTries = 0;
        tick();
      }),
      AppState.addEventListener('change', (st) => { if (st === 'active') wake(); }),
    ];
    safe(() => D.start());
    running = true;
    phase = 'idle';
    joinTries = 0;
    cooldownUntil = 0;
    jitterUntil = 0;
    lastTick = Date.now();
    timer = setInterval(tick, 4000);
    tick();
  } finally {
    starting = false;
  }
}

function end() {
  if (running) {
    running = false;
    clearInterval(timer);
    timer = null;
    subs.forEach((s) => { try { s.remove(); } catch (e) {} });
    subs = [];
    safe(() => D.stop());
    setGroup(NO_GROUP);
  }
  publish('off');
}

// Called whenever the sign-in state or the normal Wi-Fi state changes.
export function update(session, hasWifi) {
  lastArgs = [session, hasWifi];
  if (!D) return;
  const want = !!(session && enabled && !hasWifi);
  if (want === wantNow) return;
  wantNow = want;
  clearTimeout(debounce);
  debounce = setTimeout(() => { if (wantNow) begin(); else end(); }, wantNow ? 6000 : 1000);
}

export function setEnabled(v) {
  enabled = !!v;
  wantNow = null;
  update(lastArgs[0], lastArgs[1]);
}
export const isEnabled = () => enabled;
