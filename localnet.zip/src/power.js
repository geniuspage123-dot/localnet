import AsyncStorage from '@react-native-async-storage/async-storage';
import * as native from './native';
import * as gateway from './gateway';

// Power mode.
//   instant : always connected (best for calls and alerts, uses more battery)
//   eco     : battery saver. The gateway is checked for 3-5 seconds every ~2 minutes, then the phone sleeps.
//             Calls and alerts can arrive up to 2 minutes late. While the app is on screen it is always instant.
let mode = 'instant';
let started = false;
let sub = null;
const listeners = new Set();

function apply() {
  native.setEco(mode === 'eco');
  gateway.setEco(mode === 'eco');
}

export async function init() {
  if (started) return;
  started = true;
  try {
    const m = await AsyncStorage.getItem('ln_power');
    mode = m === 'eco' ? 'eco' : 'instant';
  } catch (e) { /* default */ }
  sub = native.onEcoWindow(() => gateway.ecoWindow(5000));
  apply();
  listeners.forEach((f) => f());
}

export const getMode = () => mode;
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };

export async function setMode(m) {
  mode = m === 'eco' ? 'eco' : 'instant';
  try { await AsyncStorage.setItem('ln_power', mode); } catch (e) { /* ignore */ }
  apply();
  listeners.forEach((f) => f());
}
