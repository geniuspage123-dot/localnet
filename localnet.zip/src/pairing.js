// Secure pairing and blind discovery.
//
// PAIRING: one phone shows a one-time code (10 characters, valid for 10 minutes), the other types it. Both phones
// prove that they know the code (a MAC over both public keys) without sending it, so nobody who does not know the code
// can pair, and a man in the middle cannot swap the public keys. Names are sent encrypted. After three wrong
// proofs the code is cancelled. (A QR code can carry the same secret later.)
//
// BLIND DISCOVERY: phones that are already paired do not broadcast a name. They broadcast short tokens that only the
// paired friend can recognise (derived from the secret both phones share), and the tokens change every minute.
// Anybody else on the network sees random bytes and learns nothing about who is nearby.
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
export const CODE_LEN = 10;
export const HOST_MS = 10 * 60 * 1000;
export const GUEST_MS = 3 * 60 * 1000;
export const WINDOW_MS = 60 * 1000;
const ROUNDS = 2000;
const MAX_FAILS = 3;

export const normCode = (c) => String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
export const prettyCode = (c) => (c.length > 5 ? c.slice(0, 5) + '-' + c.slice(5) : c);

export const windowOf = (t) => Math.floor(t / WINDOW_MS);

const cat = (...parts) => {
  const len = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(len);
  let o = 0;
  parts.forEach((p) => { out.set(p, o); o += p.length; });
  return out;
};

// token that "senderId" puts in its beacon for a friend it shares `shared` (32 bytes) with
export function beaconToken(env, shared, w, senderId) {
  return env.hex(env.hash(cat(shared, env.utf8('bb|' + w + '|' + senderId)))).slice(0, 24);
}

export function createPairing(env) {
  let host = null;
  let guest = null;
  let status = { mode: null, state: 'idle', code: '', peerName: '', error: '' };

  const set = (patch) => { status = { ...status, ...patch }; env.onStatus && env.onStatus(status); };

  function stretch(code) {
    let h = env.hash(env.utf8('pair-v1|' + code));
    for (let i = 0; i < ROUNDS; i++) h = env.hash(h);
    return h;
  }
  const tagOf = (K) => env.hex(env.hash(cat(K, env.utf8('tag')))).slice(0, 16);
  const macOf = (K, role, f) => env.hex(env.hash(cat(K, env.utf8(role + '|' + f.join('|'))))).slice(0, 32);
  const okStr = (s, max) => typeof s === 'string' && s.length > 0 && s.length <= max;

  function sealName(pk) {
    const e = env.encryptTo(pk, env.utf8(String(env.me().name || '').slice(0, 40)));
    return { n: e.n, c: e.c };
  }
  function openName(pk, nm) {
    if (!nm || !okStr(nm.n, 100) || !okStr(nm.c, 400)) return '';
    const b = env.decryptFrom(pk, nm.n, nm.c);
    return b ? env.text(b).slice(0, 40) : '';
  }

  function active() {
    const t = env.now();
    if (host && t > host.until) { host = null; if (status.mode === 'host' && status.state === 'waiting') set({ state: 'expired' }); }
    if (guest && t > guest.until) { guest = null; if (status.mode === 'guest' && status.state === 'waiting') set({ state: 'expired' }); }
  }

  return {
    status: () => status,
    cancel() { host = null; guest = null; set({ mode: null, state: 'idle', code: '', peerName: '', error: '' }); },

    // phone A: show this code
    startHost() {
      let code = '';
      const r = env.rand(CODE_LEN);
      for (let i = 0; i < CODE_LEN; i++) code += ALPHABET[r[i] % ALPHABET.length];
      const K = stretch(code);
      host = { K, tag: tagOf(K), until: env.now() + HOST_MS, sess: null, fails: 0 };
      guest = null;
      set({ mode: 'host', state: 'waiting', code, peerName: '', error: '', until: host.until });
      return code;
    },

    // phone B: the code typed by the user
    join(input) {
      const code = normCode(input);
      if (code.length !== CODE_LEN) { set({ mode: 'guest', state: 'failed', error: 'The code has ' + CODE_LEN + ' characters' }); return false; }
      const K = stretch(code);
      guest = { K, tag: tagOf(K), until: env.now() + GUEST_MS, nb: env.hex(env.rand(12)) };
      host = null;
      set({ mode: 'guest', state: 'waiting', code: '', peerName: '', error: '', until: guest.until });
      this.tick();
      return true;
    },

    // called every few seconds: the guest keeps asking until the host answers
    tick() {
      active();
      if (guest) {
        const me = env.me();
        env.send(null, { t: 'pr1', tag: guest.tag, id: me.id, pk: me.pk, nb: guest.nb });
      }
    },

    handle(d, ip) {
      active();
      const me = env.me();
      if (!d || typeof d !== 'object' || !okStr(d.tag, 40) || !okStr(d.id, 80) || d.id === me.id) return;

      if (d.t === 'pr1' && host && d.tag === host.tag && okStr(d.pk, 100) && okStr(d.nb, 64)) {
        // the guest repeats pr1 until it hears back: answer the same way every time
        if (!(host.sess && host.sess.id === d.id && host.sess.nb === d.nb && host.sess.pk === d.pk)) {
          host.sess = { id: d.id, pk: d.pk, nb: d.nb, na: env.hex(env.rand(12)), ip };
        }
        host.sess.ip = ip;
        const f = [me.id, me.pk, d.id, d.pk, host.sess.na, d.nb];
        env.send(ip, { t: 'pr2', tag: host.tag, id: me.id, pk: me.pk, na: host.sess.na, mac: macOf(host.K, 'A', f), nm: sealName(d.pk) });
        set({ state: 'working' });
        return;
      }

      if (d.t === 'pr2' && guest && d.tag === guest.tag && okStr(d.pk, 100) && okStr(d.na, 64) && okStr(d.mac, 64)) {
        const f = [d.id, d.pk, me.id, me.pk, d.na, guest.nb];
        if (macOf(guest.K, 'A', f) !== d.mac) return;                 // not made with our code: ignore
        const name = openName(d.pk, d.nm) || 'Friend';
        const K = guest.K;
        const tag = guest.tag;
        guest = null;
        env.send(ip, { t: 'pr3', tag, id: me.id, mac: macOf(K, 'B', f), nm: sealName(d.pk) });
        env.onPaired({ id: d.id, name, pk: d.pk, ip });
        set({ state: 'done', peerName: name, error: '' });
        return;
      }

      if (d.t === 'pr3' && host && host.sess && d.tag === host.tag && d.id === host.sess.id && okStr(d.mac, 64)) {
        const s = host.sess;
        const f = [me.id, me.pk, s.id, s.pk, s.na, s.nb];
        if (macOf(host.K, 'B', f) !== d.mac) {
          host.fails += 1;
          host.sess = null;
          if (host.fails >= MAX_FAILS) { host = null; set({ state: 'failed', error: 'Too many wrong attempts. Make a new code.' }); }
          return;
        }
        const name = openName(s.pk, d.nm) || 'Friend';
        host = null;
        env.onPaired({ id: s.id, name, pk: s.pk, ip: s.ip });
        set({ state: 'done', peerName: name, error: '' });
      }
    },
  };
}
