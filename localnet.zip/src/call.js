import { PermissionsAndroid, Platform, Vibration } from 'react-native';
import { RTCPeerConnection, RTCSessionDescription, RTCIceCandidate, mediaDevices } from 'react-native-webrtc';
import InCallManager from 'react-native-incall-manager';
import * as net from './net';
import * as notify from './notify';

let call = null;
let pc = null;
let stream = null;
let remoteOffer = null;
let pendingIce = {};
let ringTimer = null;
let tickTimer = null;
let snapshot = { call: null, now: Date.now() };
const listeners = new Set();

function publish() {
  snapshot = { call: call ? { ...call } : null, now: Date.now() };
  listeners.forEach((f) => f());
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snapshot;
export const init = () => net.setSignalHandler(onSignal);

const fmt = (s) => Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');

async function ensureMic() {
  if (Platform.OS !== 'android') return true;
  try {
    const r = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
    return r === PermissionsAndroid.RESULTS.GRANTED;
  } catch (e) { return false; }
}

async function makePc(id) {
  const s = await mediaDevices.getUserMedia({ audio: true, video: false });
  if (!call || call.id !== id) { s.getTracks().forEach((t) => t.stop()); return false; }
  stream = s;
  pc = new RTCPeerConnection({ iceServers: [] });
  stream.getTracks().forEach((t) => pc.addTrack(t, stream));
  pc.addEventListener('icecandidate', (e) => {
    if (e.candidate && call) net.sendSignal(call.peer, { t: 'call-ice', callId: call.id, cand: e.candidate.toJSON() });
  });
  pc.addEventListener('iceconnectionstatechange', () => {
    const st = pc && pc.iceConnectionState;
    if (!call) return;
    if (st === 'connected' || st === 'completed') {
      if (call.status !== 'connected') {
        call.status = 'connected';
        if (!call.since) call.since = Date.now();
        clearTimeout(ringTimer);
        try { InCallManager.stopRingtone(); } catch (e) {}
        Vibration.cancel();
        if (!tickTimer) tickTimer = setInterval(publish, 1000);
        publish();
      }
    } else if (st === 'disconnected') {
      if (call.status === 'connected') { call.status = 'lost'; publish(); }
    } else if (st === 'failed') {
      finish(call.since ? 'ended' : 'failed');
    }
  });
  return true;
}

async function flushIce(id) {
  const list = pendingIce[id] || [];
  pendingIce[id] = [];
  for (const c of list) { try { await pc.addIceCandidate(new RTCIceCandidate(c)); } catch (e) {} }
}

function cleanup() {
  clearTimeout(ringTimer);
  clearInterval(tickTimer);
  tickTimer = null;
  try { InCallManager.stopRingtone(); } catch (e) {}
  try { InCallManager.stop(); } catch (e) {}
  Vibration.cancel();
  try { stream && stream.getTracks().forEach((t) => t.stop()); } catch (e) {}
  try { pc && pc.close(); } catch (e) {}
  if (call) delete pendingIce[call.id];
  pc = null;
  stream = null;
  remoteOffer = null;
  call = null;
  publish();
}

function finish(reason) {
  if (!call) return;
  const c = call;
  const secs = c.since ? Math.round((Date.now() - c.since) / 1000) : 0;
  const texts = {
    ended: '📞 Voice call · ' + fmt(secs),
    missed: '📞 Missed call',
    noanswer: '📞 No answer',
    declined: '📞 Call declined',
    busy: '📞 User is busy',
    cancelled: '📞 Call cancelled',
    failed: '📞 Call failed',
  };
  net.addLocalMessage(c.peer, {
    id: net.genId(), kind: 'call', mine: c.dir === 'out', dir: c.dir, outcome: reason, secs,
    text: texts[reason] || texts.failed, ts: Date.now(), read: reason !== 'missed', status: 'delivered',
  });
  if (reason === 'missed') notify.missedCall(c.name, c.peer);
  else notify.dismissCall();
  cleanup();
}

export async function startCall(peerId) {
  if (call) return;
  const c = net.getContact(peerId);
  if (!c) return;
  if (!(await ensureMic())) return;
  const id = net.genId();
  call = { id, peer: peerId, name: c.name, dir: 'out', status: 'preparing', since: 0, muted: false, speaker: false };
  publish();
  try {
    if (!(await makePc(id))) return;
    try { InCallManager.start({ media: 'audio' }); } catch (e) {}
    const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: false });
    await pc.setLocalDescription(offer);
    net.sendSignal(peerId, { t: 'call-offer', callId: id, sdp: offer.sdp });
    if (call && call.id === id) { call.status = 'calling'; publish(); }
    ringTimer = setTimeout(() => {
      if (call && call.id === id && (call.status === 'calling' || call.status === 'preparing')) {
        net.sendSignal(peerId, { t: 'call-end', callId: id });
        finish('noanswer');
      }
    }, 45000);
  } catch (e) { finish('failed'); }
}

export async function answer() {
  if (!call || call.dir !== 'in' || call.status !== 'ringing') return;
  const id = call.id;
  clearTimeout(ringTimer);
  try { InCallManager.stopRingtone(); } catch (e) {}
  Vibration.cancel();
  notify.dismissCall();
  if (!(await ensureMic())) { decline(); return; }
  call.status = 'connecting';
  publish();
  try {
    if (!(await makePc(id))) return;
    try { InCallManager.start({ media: 'audio' }); } catch (e) {}
    await pc.setRemoteDescription(new RTCSessionDescription({ type: 'offer', sdp: remoteOffer }));
    await flushIce(id);
    const ans = await pc.createAnswer();
    await pc.setLocalDescription(ans);
    net.sendSignal(call.peer, { t: 'call-answer', callId: id, sdp: ans.sdp });
  } catch (e) {
    if (call) net.sendSignal(call.peer, { t: 'call-end', callId: id });
    finish('failed');
  }
}

export function decline() {
  if (!call) return;
  net.sendSignal(call.peer, { t: 'call-reject', callId: call.id });
  finish('declined');
}

export function hangup() {
  if (!call) return;
  if (call.dir === 'in' && call.status === 'ringing') { decline(); return; }
  net.sendSignal(call.peer, { t: 'call-end', callId: call.id });
  finish(call.status === 'connected' ? 'ended' : call.dir === 'out' ? 'cancelled' : 'declined');
}

export function toggleMute() {
  if (!call) return;
  call.muted = !call.muted;
  try { stream && stream.getAudioTracks().forEach((t) => { t.enabled = !call.muted; }); } catch (e) {}
  publish();
}

export function toggleSpeaker() {
  if (!call) return;
  call.speaker = !call.speaker;
  try { InCallManager.setForceSpeakerphoneOn(call.speaker); } catch (e) {}
  publish();
}

async function onSignal(d) {
  try {
    if (d.t === 'call-offer') {
      if (call || !d.sdp) { net.sendSignal(d.from, { t: 'call-reject', callId: d.callId, busy: true }); return; }
      const c = net.getContact(d.from);
      const id = d.callId;
      call = { id, peer: d.from, name: c ? c.name : d.fromName, dir: 'in', status: 'ringing', since: 0, muted: false, speaker: false };
      remoteOffer = d.sdp;
      try { InCallManager.startRingtone('_DEFAULT_'); } catch (e) {}
      Vibration.vibrate([0, 800, 800], true);
      ringTimer = setTimeout(() => {
        if (call && call.id === id && call.status === 'ringing') {
          net.sendSignal(call.peer, { t: 'call-reject', callId: id });
          finish('missed');
        }
      }, 45000);
      notify.incomingCall(call.name, d.from);
      publish();
      return;
    }
    if (d.t === 'call-ice') {
      if (pc && pc.remoteDescription && call && call.id === d.callId) {
        try { await pc.addIceCandidate(new RTCIceCandidate(d.cand)); } catch (e) {}
      } else {
        (pendingIce[d.callId] = pendingIce[d.callId] || []).push(d.cand);
      }
      return;
    }
    if (!call || d.callId !== call.id) return;
    if (d.t === 'call-answer' && call.dir === 'out' && pc) {
      await pc.setRemoteDescription(new RTCSessionDescription({ type: 'answer', sdp: d.sdp }));
      await flushIce(call.id);
    } else if (d.t === 'call-end') {
      finish(call.status === 'connected' ? 'ended' : call.dir === 'in' ? 'missed' : 'cancelled');
    } else if (d.t === 'call-reject') {
      finish(d.busy ? 'busy' : 'declined');
    }
  } catch (e) {}
}
