import * as Notifications from 'expo-notifications';
import { AppState, Platform } from 'react-native';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: false }),
});

export async function setup() {
  try {
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('messages', {
        name: 'Messages', importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 200, 100, 200], lightColor: '#246bfd',
      });
      await Notifications.setNotificationChannelAsync('calls', {
        name: 'Calls', importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 700, 500, 700], lightColor: '#22b573',
      });
    }
    const cur = await Notifications.getPermissionsAsync();
    if (!cur.granted) await Notifications.requestPermissionsAsync();
  } catch (e) {}
}

async function show(id, title, body, channelId, data) {
  try {
    await Notifications.scheduleNotificationAsync({
      identifier: id,
      content: { title, body, data: data || {}, sound: true, priority: Notifications.AndroidNotificationPriority.MAX },
      trigger: { channelId },
    });
  } catch (e) {}
}

export function message(name, text, peerId) {
  if (AppState.currentState === 'active') return;
  show('msg-' + peerId, name, text, 'messages', { peerId });
}
export function dismissMessage(peerId) {
  try { Notifications.dismissNotificationAsync('msg-' + peerId); } catch (e) {}
}
export function incomingCall(name, peerId) {
  if (AppState.currentState === 'active') return;
  show('call', name, 'Incoming voice call', 'calls', { peerId });
}
export function dismissCall() {
  try { Notifications.dismissNotificationAsync('call'); } catch (e) {}
}
export function missedCall(name, peerId) {
  dismissCall();
  show('missed-' + peerId, 'Missed call', name, 'messages', { peerId });
}
