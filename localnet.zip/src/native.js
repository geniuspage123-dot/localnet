import { AppState, PermissionsAndroid, Platform } from 'react-native';
import { loadModule } from './bridge';

// Native helper (Android): background service, notifications, ringing on the lock screen.
// If it is missing, everything below does nothing and the app works as before.
const M = loadModule('LocalNetService');

const safe = (fn, fallback) => {
  try { return M ? fn() : fallback; } catch (e) { return fallback; }
};

export const available = !!M;
export const startService = () => safe(() => M.start('LocalNet Connect', 'Ready for messages and calls on your Wi-Fi'), false);
export const stopService = () => safe(() => M.stop(), false);
export const callMode = (on) => safe(() => M.setCallMode(!!on), false);
export const isRunning = () => !!safe(() => M.isRunning(), false);
export const ring = (name, peerId) => safe(() => M.showIncomingCall(String(name), String(peerId)), false);
export const cancelRing = () => safe(() => M.cancelIncomingCall(), false);
export const lockScreen = (on) => safe(() => M.setLockScreenMode(!!on), false);
export const dismissMessages = (peerId) => safe(() => M.cancelMessage(String(peerId)), false);
export const batteryExempt = () => !!safe(() => M.isIgnoringBatteryOptimizations(), true);
export const askBatteryExemption = () => safe(() => M.requestIgnoreBatteryOptimizations(), false);
export const fullScreenAllowed = () => !!safe(() => M.canUseFullScreenIntent(), true);
export const openFullScreenSettings = () => safe(() => M.openFullScreenIntentSettings(), false);

// Message / missed-call notification, only when the app is not on screen.
export const notifyMessage = (name, text, peerId) => {
  if (AppState.currentState === 'active') return false;
  return safe(() => M.showMessage(String(name), String(text), String(peerId)), false);
};

export async function ensurePermissions() {
  if (Platform.OS !== 'android') return;
  try {
    if (Platform.Version >= 33) await PermissionsAndroid.request('android.permission.POST_NOTIFICATIONS');
    await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
  } catch (e) {
    // ignore
  }
}
