import AsyncStorage from '@react-native-async-storage/async-storage';

// Keeps secrets (encryption keys, gateway passwords) in the Android Keystore through expo-secure-store.
// Old values saved in plain AsyncStorage are moved over the first time they are read.
let SS = null;
try { SS = require('expo-secure-store'); } catch (e) { SS = null; }

export async function getSecure(key) {
  if (SS) {
    try {
      const v = await SS.getItemAsync(key);
      if (v != null) return v;
    } catch (e) { /* fall back below */ }
  }
  const old = await AsyncStorage.getItem(key);
  if (old != null && SS) {
    try {
      await SS.setItemAsync(key, old);
      await AsyncStorage.removeItem(key);
    } catch (e) { /* keep the old copy */ }
  }
  return old;
}

export async function setSecure(key, value) {
  if (SS) {
    try {
      await SS.setItemAsync(key, value);
      await AsyncStorage.removeItem(key);
      return;
    } catch (e) { /* fall back below */ }
  }
  await AsyncStorage.setItem(key, value);
}
