import BackgroundService from 'react-native-background-actions';
import { Linking, PermissionsAndroid, Platform } from 'react-native';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const task = async () => { while (BackgroundService.isRunning()) { await sleep(5000); } };

export const isRunning = () => { try { return BackgroundService.isRunning(); } catch (e) { return false; } };

export async function ensureMic() {
  if (Platform.OS !== 'android') return true;
  try {
    const r = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
    return r === PermissionsAndroid.RESULTS.GRANTED;
  } catch (e) { return false; }
}

export async function startService() {
  if (Platform.OS !== 'android' || isRunning()) return isRunning();
  try {
    await BackgroundService.start(task, {
      taskName: 'LocalNet',
      taskTitle: 'LocalNet Connect',
      taskDesc: 'Ready for messages and calls on your Wi-Fi',
      taskIcon: { name: 'ic_launcher', type: 'mipmap' },
      color: '#246bfd',
      linkingURI: 'localnet://',
    });
  } catch (e) {}
  return isRunning();
}

export async function stopService() { try { await BackgroundService.stop(); } catch (e) {} }

export function openBatterySettings() {
  Linking.sendIntent('android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS').catch(() => Linking.openSettings());
}
