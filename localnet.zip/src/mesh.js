// Multi-hop routing between phones and gateways (distance-vector, in the style of DSDV).
//
// Every node has an id. Neighbours are the nodes it can reach directly (same Wi-Fi, Wi-Fi Direct, a gateway link).
// Nodes tell their neighbours which ids they can reach and how many hops away; a packet for a far node is passed
// from neighbour to neighbour until it arrives. The packet body is end-to-end encrypted by the caller, so the
// phones that carry it cannot read it. Only a device that is on two networks at once (a phone on Wi-Fi + Wi-Fi
// Direct, or a gateway with two interfaces) can bridge two different subnets.
export const MAX_HOPS = 6;
export const ADV_MS = 30000;
export const ROUTE_TTL = 100000;
const SEEN_TTL = 300000;
const SEEN_MAX = 800;
const ADV_MAX = 60;

export function createMesh({ selfId, neighbors, send, deliver, now = Date.now }) {
  const routes = new Map();   // dst -> { next, hops, seq, at }
  const seen = new Map();     // mid -> time
  const withdrawn = new Set(); // destinations that became unreachable: neighbours are told once
  let timer = null;
  let advTimer = null;
  let n = 0;

  const nbrSet = () => new Set(neighbors());
  const newMid = () => selfId.slice(0, 6) + now().toString(36) + (n++).toString(36) + Math.random().toString(36).slice(2, 8);

  function expire() {
    const t = now();
    const set = nbrSet();
    for (const [d, r] of routes) {
      if (t - r.at > ROUTE_TTL || !set.has(r.next)) { routes.delete(d); withdrawn.add(d); }
    }
    for (const [m, at] of seen) if (t - at > SEEN_TTL) seen.delete(m);
    while (seen.size > SEEN_MAX) seen.delete(seen.keys().next().value);
  }

  async function advertise() {
    expire();
    const seq = Math.floor(now() / 1000);          // survives restarts, grows with time
    const set = nbrSet();
    for (const nb of set) {
      const list = [{ d: selfId, h: 0, s: seq }];
      for (const [d, r] of routes) {
        if (r.next === nb) continue;               // split horizon: do not tell a node about routes through itself
        if (list.length >= ADV_MAX) break;
        list.push({ d, h: r.hops, s: r.seq });
      }
      for (const d of withdrawn) if (list.length < ADV_MAX + 10) list.push({ d, h: 99, s: 0 });   // 99 = unreachable
      try { await send(nb, { t: 'mesh-adv', r: list }); } catch (e) { /* neighbour gone */ }
    }
    withdrawn.clear();
  }

  function onAdv(from, frame) {
    if (!nbrSet().has(from) || !Array.isArray(frame.r)) return;
    const t = now();
    for (const e of frame.r.slice(0, ADV_MAX)) {
      if (!e || typeof e.d !== 'string' || e.d === selfId) continue;
      const cur0 = routes.get(e.d);
      if (Number(e.h) >= 99) {                       // the neighbour lost its way to e.d
        if (cur0 && cur0.next === from) { routes.delete(e.d); withdrawn.add(e.d); }
        continue;
      }
      const hops = Number(e.h) + 1;
      const seq = Number(e.s);
      if (!Number.isFinite(hops) || !Number.isFinite(seq) || hops > MAX_HOPS) continue;
      const cur = routes.get(e.d);
      if (!cur || seq > cur.seq || (seq === cur.seq && hops < cur.hops) || (cur.next === from && seq >= cur.seq)) {
        routes.set(e.d, { next: from, hops, seq, at: t });
      }
    }
  }

  async function forward(pkt) {
    const set = nbrSet();
    const r = routes.get(pkt.dst);
    const next = set.has(pkt.dst) ? pkt.dst : r && r.next;
    if (!next || !set.has(next)) return false;
    let ok = false;
    try { ok = !!(await send(next, pkt)); } catch (e) { ok = false; }
    if (!ok && r && r.next === next) { routes.delete(pkt.dst); withdrawn.add(pkt.dst); }   // broken: wait for a new route
    return ok;
  }

  return {
    hasRoute(dst) {
      expire();
      return nbrSet().has(dst) || routes.has(dst);
    },
    hops(dst) {
      if (nbrSet().has(dst)) return 1;
      const r = routes.get(dst);
      return r ? r.hops : 0;
    },
    table() {
      expire();
      return Array.from(routes, ([d, r]) => ({ d, next: r.next, hops: r.hops }));
    },
    // body: opaque, already end-to-end encrypted. Resolves true when the next hop accepted it.
    sendTo(dst, body) {
      return forward({ t: 'mesh-d', mid: newMid(), src: selfId, dst, ttl: MAX_HOPS, body });
    },
    // frame arrived from a neighbour
    receive(from, frame) {
      if (!frame || typeof frame !== 'object') return false;
      if (frame.t === 'mesh-adv') { onAdv(from, frame); return true; }
      if (frame.t !== 'mesh-d' || typeof frame.mid !== 'string' || typeof frame.dst !== 'string' || typeof frame.src !== 'string') return false;
      if (seen.has(frame.mid)) return true;                    // already handled (loop / duplicate)
      seen.set(frame.mid, now());
      if (frame.dst === selfId) {
        try { deliver(frame.src, frame.body, frame.mid, from); } catch (e) { /* ignore */ }
        return true;
      }
      const ttl = Number(frame.ttl) - 1;
      if (ttl > 0) forward({ ...frame, ttl });
      return true;
    },
    advertise,
    start() {
      if (timer) return;
      timer = setInterval(advertise, ADV_MS);
      advertise();
    },
    // call when the set of neighbours changed: advertises soon (debounced)
    changed() {
      if (advTimer) return;
      advTimer = setTimeout(() => { advTimer = null; advertise(); }, 1500);
    },
    stop() {
      clearInterval(timer);
      clearTimeout(advTimer);
      timer = null;
      advTimer = null;
      routes.clear();
      seen.clear();
    },
  };
}
