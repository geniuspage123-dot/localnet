import nacl from 'tweetnacl';
import * as Crypto from 'expo-crypto';
import AsyncStorage from '@react-native-async-storage/async-storage';

// End-to-end encryption (X25519 + XSalsa20-Poly1305). Only the two phones in a chat can read a message,
// even when it travels through other phones.
nacl.setPRNG((x, n) => {
  const r = Crypto.getRandomBytes(n);
  for (let i = 0; i < n; i++) x[i] = r[i];
});

const toB64 = (u8) => Buffer.from(u8).toString('base64');
const fromB64 = (s) => new Uint8Array(Buffer.from(String(s), 'base64'));

let keys = null;

export async function loadKeys() {
  if (keys) return keys;
  try {
    const raw = await AsyncStorage.getItem('ln_keys');
    if (raw) {
      const k = JSON.parse(raw);
      keys = { pk: fromB64(k.pk), sk: fromB64(k.sk), pkB64: k.pk };
      return keys;
    }
  } catch (e) { /* create new keys below */ }
  const kp = nacl.box.keyPair();
  keys = { pk: kp.publicKey, sk: kp.secretKey, pkB64: toB64(kp.publicKey) };
  try {
    await AsyncStorage.setItem('ln_keys', JSON.stringify({ pk: toB64(kp.publicKey), sk: toB64(kp.secretKey) }));
  } catch (e) { /* keys stay in memory for this session */ }
  return keys;
}

export const ready = () => !!keys;
export const myPublicKey = () => (keys ? keys.pkB64 : '');

// bytes: Uint8Array -> { n, c } (base64 strings)
export function encryptTo(theirPkB64, bytes) {
  const nonce = nacl.randomBytes(24);
  const boxed = nacl.box(bytes, nonce, fromB64(theirPkB64), keys.sk);
  return { n: toB64(nonce), c: toB64(boxed) };
}

// returns Uint8Array, or null when the message cannot be opened
export function decryptFrom(theirPkB64, n, c) {
  try {
    return nacl.box.open(fromB64(c), fromB64(n), fromB64(theirPkB64), keys.sk);
  } catch (e) {
    return null;
  }
}

export const utf8 = (str) => new Uint8Array(Buffer.from(String(str), 'utf8'));
export const text = (bytes) => Buffer.from(bytes).toString('utf8');
export const bytesFromB64 = fromB64;
export const b64FromBytes = toB64;
