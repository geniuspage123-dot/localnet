import './polyfill';
import { AppRegistry } from 'react-native';
import { registerRootComponent } from 'expo';
import App from './App';
import * as net from './src/net';

// Runs with no screen. Android starts it (via LocalNetService) when it had killed the app process and
// restarted the background service: it brings the sockets, gateway links and encryption back up.
AppRegistry.registerHeadlessTask('LocalNetKeepAlive', () => async () => {
  try { await net.init(); } catch (e) { /* ignore */ }
  await new Promise(() => {});   // never ends; Android stops it together with the service
});

registerRootComponent(App);
