package expo.modules.localnetservice

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Small persistent store that the service can read even when the JS side is not running. */
object Store {
  private const val PREFS = "localnet_native"
  private val lock = Any()

  private fun sp(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

  fun setIdentity(c: Context, id: String, name: String, username: String, session: Boolean) {
    sp(c).edit().putString("id", id).putString("name", name).putString("username", username).putBoolean("session", session).apply()
  }

  fun id(c: Context): String = sp(c).getString("id", "") ?: ""
  fun name(c: Context): String = sp(c).getString("name", "") ?: ""
  fun username(c: Context): String = sp(c).getString("username", "") ?: ""
  fun session(c: Context): Boolean = sp(c).getBoolean("session", false) && id(c).isNotEmpty()

  fun room(c: Context): String = sp(c).getString("room", "") ?: ""
  fun setRoom(c: Context, room: String) {
    sp(c).edit().putString("room", room).apply()
  }

  fun known(c: Context): List<String> {
    val s = sp(c).getString("known", "") ?: ""
    return if (s.isEmpty()) emptyList() else s.split(",").filter { it.isNotBlank() }
  }

  fun setKnown(c: Context, ips: List<String>) {
    sp(c).edit().putString("known", ips.joinToString(",")).apply()
  }

  private fun inbox(c: Context) = File(c.applicationContext.filesDir, "ln_inbox.jsonl")

  /** Lines that arrived while the JS side was not running. */
  fun enqueue(c: Context, line: String) {
    synchronized(lock) {
      try {
        val f = inbox(c)
        if (f.exists() && f.length() > 1_000_000) f.delete()
        f.appendText(line + "\n", Charsets.UTF_8)
      } catch (e: Exception) {
        // best effort
      }
    }
  }

  fun drain(c: Context): List<String> {
    synchronized(lock) {
      return try {
        val f = inbox(c)
        if (!f.exists()) {
          emptyList()
        } else {
          val l = f.readLines(Charsets.UTF_8).filter { it.isNotBlank() }
          f.delete()
          l
        }
      } catch (e: Exception) {
        emptyList()
      }
    }
  }

}

/** Connects the always-on native service with the JS app (when JS is alive). */
object Bridge {
  private val lock = Any()
  @Volatile var emitter: ((String) -> Unit)? = null
  @Volatile var ready = false
  @Volatile var lockMode = false

  /** JS calls this once its listeners are installed. Returns everything that was queued meanwhile. */
  fun attach(c: Context): List<String> {
    synchronized(lock) {
      ready = true
      return Store.drain(c)
    }
  }

  fun detach() {
    synchronized(lock) { ready = false }
  }

  /** true = JS got it live. false = it was written to the inbox for later. */
  fun dispatchOrQueue(c: Context, line: String): Boolean {
    synchronized(lock) {
      val e = emitter
      if (ready && e != null) {
        try {
          e(line)
          return true
        } catch (ex: Exception) {
          ready = false
        }
      }
      Store.enqueue(c, line)
      return false
    }
  }

  fun emitIfReady(line: String) {
    val e = emitter
    if (ready && e != null) {
      try { e(line) } catch (ex: Exception) { }
    }
  }
}

class LineReader(private val ins: InputStream) {
  private val chunk = ByteArray(16384)
  private var pos = 0
  private var lim = 0
  private val acc = ByteArrayOutputStream()
  private val nl = '\n'.code.toByte()

  /** Next line (without the newline), or null when the stream ends. */
  fun next(): String? {
    acc.reset()
    while (true) {
      if (pos >= lim) {
        val n = ins.read(chunk)
        if (n < 0) return null
        pos = 0
        lim = n
      }
      var i = pos
      while (i < lim && chunk[i] != nl) i++
      acc.write(chunk, pos, i - pos)
      if (acc.size() > Transport.MAX_LINE) throw IOException("line too long")
      if (i < lim) {
        pos = i + 1
        return acc.toString("UTF-8")
      }
      pos = lim
    }
  }
}

object Transport {
  const val UDP_PORT = 45454
  const val TCP_PORT = 45455
  const val MAX_LINE = 8_000_000

  /** Sends one encrypted line. If ackId is not empty, waits for the matching encrypted ack. */
  fun send(ip: String, plain: String, ackId: String, timeoutMs: Int): Boolean {
    var s: Socket? = null
    try {
      val line = Crypto.encrypt(plain)
      if (line.isEmpty()) return false
      s = Socket()
      s.tcpNoDelay = true
      s.connect(InetSocketAddress(ip, TCP_PORT), minOf(timeoutMs, 4000))
      s.soTimeout = timeoutMs
      val out = s.getOutputStream()
      out.write((line + "\n").toByteArray(Charsets.UTF_8))
      out.flush()
      if (ackId.isEmpty()) return true
      val reply = LineReader(s.getInputStream()).next() ?: return false
      val dec = Crypto.decrypt(reply) ?: return false
      val d = JSONObject(dec)
      return d.optString("t") == "ack" && d.optString("id") == ackId
    } catch (e: Exception) {
      return false
    } finally {
      try { s?.close() } catch (e: Exception) { }
    }
  }
}
