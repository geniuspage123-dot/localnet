package expo.modules.localnetservice

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import org.json.JSONArray
import java.io.File
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.Executors

/**
 * Pure native network engine: UDP discovery + TCP receiver.
 * It lives inside the foreground service, so it keeps working when the app screen is closed
 * or swiped away (the JS side is not needed to receive messages and calls).
 */
class Engine(private val ctx: Context, private val sink: Sink) {
  interface Sink {
    fun onPeer(d: JSONObject)
    fun onData(d: JSONObject)
  }

  @Volatile private var running = false
  @Volatile private var udp: DatagramSocket? = null
  @Volatile private var server: ServerSocket? = null
  private val pool = Executors.newCachedThreadPool()
  private val known = CopyOnWriteArraySet<String>()
  // In-memory loop guard for store/forward relay attempts.
  private val relayed = Collections.synchronizedMap(LinkedHashMap<String, Long>())
  private val maxRelayHops = 4
  // Durable best-effort store-and-forward queue. Entries survive service/process restarts.
  private val pendingRelay = LinkedHashMap<String, JSONObject>()
  private val pendingFile = File(ctx.filesDir, "ln_relay_queue.json")
  private val maxPendingRelay = 500
  var onBeat: (() -> Unit)? = null

  fun addKnown(ip: String) {
    if (ip.isNotBlank()) known.add(ip)
  }

  fun setKnown(list: List<String>) {
    known.clear()
    list.forEach { addKnown(it) }
  }

  fun start() {
    if (running) return
    running = true
    setKnown(Store.known(ctx))
    loadPendingRelay()
    daemon { udpLoop() }
    daemon { tcpLoop() }
    daemon { beatLoop() }
  }

  fun stop() {
    running = false
    try { udp?.close() } catch (e: Exception) { }
    try { server?.close() } catch (e: Exception) { }
    pool.shutdownNow()
  }

  private fun daemon(block: () -> Unit) {
    val t = Thread { block() }
    t.isDaemon = true
    t.start()
  }

  private fun clean(ip: String): String {
    var s = ip.replace("::ffff:", "")
    val i = s.indexOf('%')
    if (i >= 0) s = s.substring(0, i)
    return s
  }

  private fun hello(r: Int): String =
    JSONObject()
      .put("t", "hi")
      .put("id", Store.id(ctx))
      .put("name", Store.name(ctx))
      .put("username", Store.username(ctx))
      .put("r", r)
      .toString()

  private fun sendUdp(plain: String, addr: String) {
    val s = udp ?: return
    try {
      val enc = Crypto.encrypt(plain)
      if (enc.isEmpty()) return
      val data = enc.toByteArray(Charsets.UTF_8)
      s.send(DatagramPacket(data, data.size, InetAddress.getByName(addr), Transport.UDP_PORT))
    } catch (e: Exception) {
      // network may be switching, next beat tries again
    }
  }

  private fun sleepQuiet(ms: Long) {
    try { Thread.sleep(ms) } catch (e: InterruptedException) { }
  }

  /* ---------------- discovery ---------------- */

  private fun udpLoop() {
    while (running) {
      var sock: DatagramSocket? = null
      try {
        sock = DatagramSocket(null)
        sock.reuseAddress = true
        sock.broadcast = true
        sock.bind(InetSocketAddress(InetAddress.getByName("0.0.0.0"), Transport.UDP_PORT))
        udp = sock
        val buf = ByteArray(8192)
        val pkt = DatagramPacket(buf, buf.size)
        while (running) {
          pkt.length = buf.size
          sock.receive(pkt)
          handleHello(String(pkt.data, 0, pkt.length, Charsets.UTF_8), pkt.address?.hostAddress ?: "")
        }
      } catch (e: Exception) {
        // socket closed or network changed: rebuild below
      } finally {
        try { sock?.close() } catch (e: Exception) { }
        udp = null
      }
      if (running) sleepQuiet(1500)
    }
  }

  private fun handleHello(text: String, rawIp: String) {
    try {
      val plain = Crypto.decrypt(text.trim()) ?: return
      val d = JSONObject(plain)
      if (d.optString("t") != "hi") return
      val id = d.optString("id")
      if (id.isEmpty() || id == Store.id(ctx)) return
      val ip = clean(rawIp)
      if (ip.isEmpty()) return
      d.put("ip", ip)
      if (d.optInt("r", 0) != 1) sendUdp(hello(1), ip)
      sink.onPeer(d)
    } catch (e: Exception) {
      // ignore garbage
    }
  }

  private fun beatLoop() {
    while (running) {
      try {
        val targets = LinkedHashSet<String>()
        targets.add("255.255.255.255")
        targets.addAll(broadcastAddresses())
        targets.addAll(known)
        val h = hello(0)
        for (t in targets) sendUdp(h, t)
        retryPendingRelay()
        onBeat?.invoke()
      } catch (e: Exception) {
      }
      sleepQuiet(3000)
    }
  }

  /* ---------------- receiving ---------------- */

  private fun tcpLoop() {
    while (running) {
      var ss: ServerSocket? = null
      try {
        ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(Transport.TCP_PORT))
        server = ss
        while (running) {
          val s = ss.accept()
          try {
            pool.execute { handleConn(s) }
          } catch (e: Exception) {
            try { s.close() } catch (x: Exception) { }
          }
        }
      } catch (e: Exception) {
      } finally {
        try { ss?.close() } catch (e: Exception) { }
        server = null
      }
      if (running) sleepQuiet(1500)
    }
  }

  private fun handleConn(s: Socket) {
    try {
      s.soTimeout = 30000
      s.tcpNoDelay = true
      val ip = clean(s.inetAddress?.hostAddress ?: "")
      val rd = LineReader(s.getInputStream())
      val out = s.getOutputStream()
      while (running) {
        val line = rd.next() ?: break
        val plain = Crypto.decrypt(line) ?: continue
        val d = try { JSONObject(plain) } catch (e: Exception) { continue }
        handle(d, ip, out)
      }
    } catch (e: Exception) {
    } finally {
      try { s.close() } catch (e: Exception) { }
    }
  }

  private fun handle(d: JSONObject, ip: String, out: OutputStream) {
    if (d.optString("from").isEmpty()) return
    val t = d.optString("t")
    val id = d.optString("id")

    // Relay text/voice packets for another user through peers we have discovered.
    // This is best-effort multi-hop forwarding, not a guarantee of end-to-end delivery.
    if (d.optString("to") != Store.id(ctx)) {
      if ((t == "msg" || t == "voice") && id.isNotEmpty()) {
        val hops = d.optInt("_lnHops", 0)
        val relayKey = d.optString("from") + ":" + id
        if (hops >= maxRelayHops || !markRelaySeen(relayKey)) return
        d.put("_lnHops", hops + 1)
        val forwarded = forwardToPeers(d, ip)
        // If no peer is reachable, durably queue it and ACK only after queueing succeeds.
        if (forwarded || queueRelay(d)) ack(out, id)
      }
      return
    }

    d.put("ip", ip)
    d.put("rx", System.currentTimeMillis())
    if (t == "msg" && id.isNotEmpty()) {
      sink.onData(d)
      ack(out, id)
    } else if (t == "voice" && id.isNotEmpty()) {
      val data = d.optString("data")
      val safe = id.filter { it.isLetterOrDigit() || it == '_' || it == '-' }
      if (data.isEmpty() || safe.isEmpty()) return
      try {
        val f = File(ctx.filesDir, "vn_$safe.m4a")
        if (!f.exists()) f.writeBytes(Base64.decode(data, Base64.DEFAULT))
        d.remove("data")
        d.put("path", f.absolutePath)
        sink.onData(d)
        ack(out, id)
      } catch (e: Exception) {
        // Invalid or incomplete voice payload; do not acknowledge it.
      }
    } else if (t.startsWith("call-")) {
      // Call signalling remains direct-only; relaying WebRTC signalling requires reverse routes.
      sink.onData(d)
    }
  }


  private fun loadPendingRelay() {
    synchronized(pendingRelay) {
      try {
        if (!pendingFile.exists()) return
        val arr = JSONArray(pendingFile.readText(Charsets.UTF_8))
        for (i in 0 until arr.length()) {
          val d = arr.optJSONObject(i) ?: continue
          val id = d.optString("id")
          val key = d.optString("from") + ":" + id
          if (id.isNotBlank() && pendingRelay.size < maxPendingRelay) pendingRelay[key] = JSONObject(d.toString())
        }
      } catch (_: Exception) {
        // Corrupt queue should not prevent network service startup.
      }
    }
  }

  private fun persistPendingRelayLocked() {
    try {
      val arr = JSONArray()
      pendingRelay.values.forEach { arr.put(it) }
      val tmp = File(ctx.filesDir, "ln_relay_queue.tmp")
      tmp.writeText(arr.toString(), Charsets.UTF_8)
      if (!tmp.renameTo(pendingFile)) {
        pendingFile.writeText(arr.toString(), Charsets.UTF_8)
        tmp.delete()
      }
    } catch (_: Exception) { }
  }

  private fun queueRelay(d: JSONObject): Boolean {
    val id = d.optString("id")
    if (id.isBlank()) return false
    val key = d.optString("from") + ":" + id
    synchronized(pendingRelay) {
      if (pendingRelay.containsKey(key)) return true
      if (pendingRelay.size >= maxPendingRelay) {
        // Drop the oldest item rather than allowing unbounded storage growth.
        val oldest = pendingRelay.keys.firstOrNull()
        if (oldest != null) pendingRelay.remove(oldest)
      }
      pendingRelay[key] = JSONObject(d.toString())
      persistPendingRelayLocked()
      return pendingRelay.containsKey(key)
    }
  }

  private fun retryPendingRelay() {
    val snapshot = synchronized(pendingRelay) { pendingRelay.map { it.key to JSONObject(it.value.toString()) } }
    if (snapshot.isEmpty()) return
    for ((id, packet) in snapshot) {
      val sent = forwardToPeers(packet, "")
      if (sent) {
        synchronized(pendingRelay) {
          if (pendingRelay.remove(id) != null) {
            persistPendingRelayLocked()
          }
        }
      }
    }
  }

  private fun markRelaySeen(id: String): Boolean {
    synchronized(relayed) {
      val now = System.currentTimeMillis()
      val it = relayed.entries.iterator()
      while (it.hasNext()) if (now - it.next().value > 10 * 60 * 1000L) it.remove()
      if (relayed.containsKey(id)) return false
      relayed[id] = now
      while (relayed.size > 1000) relayed.remove(relayed.keys.first())
      return true
    }
  }

  private fun forwardToPeers(d: JSONObject, incomingIp: String): Boolean {
    val targets = known.toList().filter { it.isNotBlank() && (incomingIp.isBlank() || clean(it) != clean(incomingIp)) }
    if (targets.isEmpty()) return false
    var sent = false
    for (target in targets) {
      try {
        if (Transport.send(target, d.toString(), "", 1800)) sent = true
      } catch (e: Exception) { }
    }
    return sent
  }

  private fun ack(out: OutputStream, id: String) {
    try {
      val enc = Crypto.encrypt(JSONObject().put("t", "ack").put("id", id).toString())
      if (enc.isEmpty()) return
      out.write((enc + "\n").toByteArray(Charsets.UTF_8))
      out.flush()
    } catch (e: Exception) {
    }
  }

  companion object {
    /** Real broadcast address of every Wi-Fi / Wi-Fi Direct / hotspot interface (never mobile data). */
    fun broadcastAddresses(): List<String> {
      val out = ArrayList<String>()
      try {
        val ifs = NetworkInterface.getNetworkInterfaces() ?: return out
        for (nif in Collections.list(ifs)) {
          if (!nif.isUp || nif.isLoopback) continue
          for (ia in nif.interfaceAddresses) {
            val b = ia.broadcast ?: continue
            val h = b.hostAddress ?: continue
            out.add(h)
          }
        }
      } catch (e: Exception) {
      }
      return out
    }

    fun localIps(): List<String> {
      val out = ArrayList<String>()
      try {
        val ifs = NetworkInterface.getNetworkInterfaces() ?: return out
        for (nif in Collections.list(ifs)) {
          if (!nif.isUp || nif.isLoopback) continue
          for (ia in nif.interfaceAddresses) {
            if (ia.broadcast == null) continue
            val h = ia.address?.hostAddress ?: continue
            out.add(h)
          }
        }
      } catch (e: Exception) {
      }
      return out
    }
  }
}
