# LocalNet Connect — Bayanin aikin relay

Wannan ZIP ya ƙunshi source code na LocalNet Connect da gwajin farko na relay.

## Abubuwan da aka ƙara/inganta
- Saƙonnin rubutu da voice notes na iya ƙoƙarin wucewa ta wayoyin da aka gano.
- An ƙara iyakar hops da kariyar rage saƙon da yake zagayawa ba iyaka.
- Idan babu peer da za a iya kai wa saƙo, ana iya adana shi a fayil na cikin app sannan a sake gwadawa.
- An iyakance adadin saƙonnin relay da ake ajiyewa zuwa 500.
- Sabis na Android yana iya karɓar wasu saƙonni a bayan fage ya nuna sanarwa idan JavaScript/UI ba ya aiki.

## Abubuwan da ba a tabbatar ba tukuna
- Ba a gina APK ba a wannan yanayin, kuma ba a gwada source a ainihin wayoyi ba.
- Relay ba cikakken mesh na gari ba ne tukuna; yana dogara da hanyar sadarwa da IPs da wayoyin suka gano.
- ACK ba ya tabbatar da cewa mai karɓa na ƙarshe ya karɓi saƙo; end-to-end receipts suna buƙatar ƙarin aiki.
- Kiran murya ta wayoyi masu relay da yawa bai gama aiki ba; kiran yanzu yana dogaro da haɗin kai tsaye.
- Idan Wi-Fi da Bluetooth duk a kashe suke kuma babu wata hanyar sadarwa, wayar ba za ta iya yin relay ba.

## Gwajin da ya kamata a yi
A gina development APK sannan a gwada wayoyi A, B, C: A ya aika wa C ta hannun B. A gwada app a bayan fage, allon a kulle, kashe/kunnawa na hanyar sadarwa, da sake kunna service.
