# LocalNet Connect – relay implementation status

This source contains a **best-effort, multi-hop text/voice-note relay prototype** in the native Android `Engine.kt`.

## Implemented in source
- Relays `msg` and `voice` packets to known peer IPs other than the peer that sent the packet.
- Adds a hop limit and an in-memory duplicate/loop guard keyed by sender + message ID.
- Persists relay packets in an app-private JSON file when no next peer is reachable, then retries them from the foreground service heartbeat.
- Bounds the pending relay queue to 500 entries so offline queuing cannot grow without limit.
- Queues incoming data in the native inbox when the JavaScript UI is not attached; the service can display notifications for incoming messages/voice notes.
- Keeps call signalling direct-only; multi-hop real-time calls are not implemented.

## Important limitations
- This is **not a verified production mesh network**. Relay can only use peer IPs that are discoverable and reachable on the current network topology.
- The current hop ACK confirms only that the relay accepted or forwarded a packet, not that the final recipient received it. End-to-end delivery receipts and reliable per-recipient retry semantics remain to be implemented.
- The queue is best-effort. A packet may be retried or duplicated; receiving clients should deduplicate by message ID.
- Wi-Fi Direct does not automatically create a city-wide multi-hop mesh. Standard Android phones cannot relay via Wi-Fi if Wi-Fi is off and cannot relay via Bluetooth if Bluetooth is off.
- Android version/manufacturer settings can restrict background execution, Wi-Fi discovery, and autostart. A foreground service and user-granted permissions are necessary but do not guarantee uninterrupted operation.
- **No Android Gradle build or real-device test has been run in this environment.** Do not treat this source as release-ready until it builds and passes tests on at least three phones.

## Suggested verification
1. Build a development APK with Android/Expo tooling.
2. Install the same build on phones A, B and C on a network where A can reach B and B can reach C.
3. Send text A → C and confirm C receives it through B.
4. Repeat with B's app backgrounded and screen locked.
5. Turn off B's available radios to confirm relay stops (it should); turn them back on and verify reconnect/retry.
6. Test duplicate packets, queue persistence after service/process restart, and large voice notes.
7. Separately test direct calls; do not assume calls relay across multiple hops.
