# LocalNet Connect v1.10.0 - canje-canje

## Sabo: src/gateway.js
- Haɗin TCP na dindindin zuwa Gateways (port 45460, newline-JSON). Duba bayanin protocol a saman fayil ɗin.
- Neman Gateway: sweep na subnet (Wi-Fi, hotspot 192.168.43.x, Wi-Fi Direct 192.168.49.x), .1/.254 na farko; ana tuna Gateways (ln_gateways) kuma ana haɗuwa kai tsaye.
- Auto-reconnect: backoff 1s→30s, ping/pong kowane 10s, watchdog yana gano barci (sleep gap), AppState 'active', canjin hanyar sadarwa.
- Tsaro: gw-hello/gw-hi kawai plain (public key); komai bayan haka encrypted (X25519+XSalsa20). Ana pin ɗin public key na Gateway (TOFU); idan ya canza -> "KEY CHANGED", ba a haɗuwa. Babu plain-text fallback.

## src/net.js
- Gateways suna bayyana a matsayin contacts (gw:true); aika/karɓar saƙo ta gateway.js.
- Lafiyar sockets: UDP/TCP server suna sake tashi da kansu idan sun mutu; gano barci (tick gap) -> restartSockets + gateway.wake().
- AppState 'active' -> wakeUp().

## src/direct.js
- resetWaits()/wake(): bayan barci ko dawowar app, ana manta cooldown/jitter ɗin da suka tsufa a nemi/join group nan take.

## Android (modules/localnet-service)
- LocalNetService: farawa da connectedDevice kawai (microphone type daga background yana jefa SecurityException a Android 14+, wanda tsohon code ke kashe service ɗin da shi); ana ƙara microphone a callMode() kawai.
- Sticky restart: yana karanta prefs; idan mai amfani ya fita (logout) ba a sake tada shi.
- bindWifi(): requestNetwork(TRANSPORT_WIFI, ba tare da INTERNET ba) + bindProcessToNetwork -> Android ba zai bar Wi-Fi na Gateway mara internet ba.
- WakeLock renew ba tare da gibi ba.
- Sabon: openAutoStartSettings (Xiaomi/Tecno/Infinix/Oppo/Vivo/Huawei/Samsung).

## modules/localnet-direct/LanAudio.kt
- WifiLock (LOW_LATENCY) + PARTIAL_WAKE_LOCK nasa na kira (an sakin su a stop(), lock na CPU yana da iyaka ta awa 4).
- Audio threads suna da URGENT_AUDIO priority.

## crypto.js / bridge.js
- Ba a taɓa su ba: tsarin encryption ɗin yana nan yadda yake.

## Iyakoki (a sani)
- Idan Android ya kashe process ɗin gaba ɗaya, JS (sockets) yana mutuwa; service ɗin zai sake tashi kuma ya nuna "Tap to reopen". Cikakken magani shi ne HeadlessJS task (ba a yi shi ba tukuna).
- Ba a gina/gwada Kotlin a nan ba (babu Gradle); an gwada gateway.js da mock server (discovery, handshake, ack, reconnect).
