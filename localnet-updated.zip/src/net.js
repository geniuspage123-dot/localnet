import dgram from 'react-native-udp';
import TcpSocket from 'react-native-tcp-socket';
import * as Network from 'expo-network';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { AppState } from 'react-native';
import * as native from './native';
import * as crypto from './crypto';
import * as gateway from './gateway';

const UDP_PORT = 45454;
const TCP_PORT = 45455;
const BEAT_MS = 3000;
export const ONLINE_MS = 10000;

let me = null;
let contacts = {};
let messages = {};
let ready = false;
let activePeer = null;
let started = false;
let session = false;
let server = null;
let tickTimer = null;
let signalHandler = null;
let appHooked = false;
let myIp = '';
let directUp = false;
let directOwner = '';
let lastTyping = 0;
let carry = [];
const CARRY_TTL = 48 * 3600 * 1000;
const CARRY_MAX = 100;
const CARRY_BYTES = 12 * 1024 * 1024;
let udp = null;
let lastTickAt = 0;
let lastSubKey = '';
let snapshot = { me: null, contacts: {}, messages: {}, ready: false, session: false, myIp: '', direct: false, carrying: 0 };
const listeners = new Set();

export const genId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const cleanIp = (ip) => String(ip || '').replace('::ffff:', '');

function publish() {
  snapshot = { me, contacts: { ...contacts }, messages: { ...messages }, ready, session, myIp, direct: directUp, carrying: carry.length };
  listeners.forEach((f) => f());
}
export const subscribe = (f) => { listeners.add(f); return () => listeners.delete(f); };
export const getSnapshot = () => snapshot;
export const getContact = (id) => contacts[id];
export const setSignalHandler = (f) => { signalHandler = f; };
export const addLocalMessage = (peerId, msg) => addMessage(peerId, msg);

let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(async () => {
    saveTimer = null;
    try {
      await AsyncStorage.setItem('ln_contacts', JSON.stringify(contacts));
      await AsyncStorage.setItem('ln_messages', JSON.stringify(messages));
    } catch (e) {}
  }, 500);
}

const hash = (str) => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0; return String(h); };

export async function init() {
  try {
    const p = await AsyncStorage.getItem('ln_account');
    const c = await AsyncStorage.getItem('ln_contacts');
    const m = await AsyncStorage.getItem('ln_messages');
    const ss = await AsyncStorage.getItem('ln_session');
    me = p ? JSON.parse(p) : null;
    contacts = c ? JSON.parse(c) : {};
    messages = m ? JSON.parse(m) : {};
    session = !!(me && ss === '1');
    const cq = await AsyncStorage.getItem('ln_carry');
    carry = cq ? JSON.parse(cq).map((x) => ({ env: x.env, at: x.at })) : [];
  } catch (e) {}
  try { await crypto.loadKeys(); } catch (e) {}
  ready = true;
  publish();
  if (!appHooked) {
    appHooked = true;
    AppState.addEventListener('change', (st) => { if (st === 'active') { markViewed(); wakeUp(); } });
  }
  if (session) start();
}

export async function register({ name, username, password }) {
  const n = String(name || '').trim();
  const u = String(username || '').trim().toLowerCase().replace(/\s+/g, '');
  if (!n || !u || !password) return 'Please fill in all fields.';
  if (String(password).length < 4) return 'Password must be at least 4 characters.';
  if (me) return 'An account already exists on this phone. Please log in.';
  me = { id: genId(), name: n, username: u, ph: hash(u + ':' + password) };
  session = true;
  try {
    await AsyncStorage.setItem('ln_account', JSON.stringify(me));
    await AsyncStorage.setItem('ln_session', '1');
  } catch (e) {}
  publish();
  start();
  return null;
}

export async function login({ username, password }) {
  const u = String(username || '').trim().toLowerCase();
  if (!me || me.username !== u || me.ph !== hash(u + ':' + password)) return 'Invalid username or password.';
  session = true;
  try { await AsyncStorage.setItem('ln_session', '1'); } catch (e) {}
  publish();
  start();
  return null;
}

export async function logout() {
  session = false;
  stop();
  try { await AsyncStorage.setItem('ln_session', '0'); } catch (e) {}
  publish();
}

function start() {
  if (started || !me) return;
  started = true;
  startServer();
  startUdp();
  gateway.setHandler({ onAlive: touchGateway, onMessage: handleGatewayMessage });
  gateway.start({ id: me.id, name: me.name });
  lastTickAt = Date.now();
  tickTimer = setInterval(tick, BEAT_MS);
  tick();
}

function stop() {
  gateway.stop();
  lastSubKey = '';
  clearInterval(tickTimer);
  tickTimer = null;
  try { udp && udp.close(); } catch (e) {}
  try { server && server.close(); } catch (e) {}
  udp = null;
  server = null;
  started = false;
}

const hello = (r) => JSON.stringify({ t: 'hi', id: me.id, name: me.name, username: me.username, r, pk: crypto.myPublicKey() });

function sendUdp(text, addr) {
  try { udp.send(text, undefined, undefined, UDP_PORT, addr, () => {}); } catch (e) {}
}

function startUdp() {
  try {
    const u = dgram.createSocket({ type: 'udp4', reusePort: true });
    udp = u;
    u.on('error', () => { if (udp === u) { try { u.close(); } catch (e) {} udp = null; } });
    u.on('close', () => { if (udp === u) udp = null; });
    u.on('message', (buf, rinfo) => {
      try {
        const d = JSON.parse(buf.toString());
        if (d.t === 'typing' && d.id && contacts[d.id]) {
          contacts[d.id] = { ...contacts[d.id], typingAt: Date.now() };
          publish();
          setTimeout(publish, 4200);
          return;
        }
        if (d.t !== 'hi' || !d.id || d.id === me.id) return;
        touchContact(d.id, d.name, cleanIp(rinfo.address), d.username, d.pk);
        if (d.r !== 1) sendUdp(hello(1), cleanIp(rinfo.address));
      } catch (e) {}
    });
    u.bind(UDP_PORT, () => { try { u.setBroadcast(true); } catch (e) {} });
  } catch (e) {}
}

// Re-open the sockets (after the phone slept, or when one of them died).
function restartSockets() {
  try { udp && udp.close(); } catch (e) {}
  try { server && server.close(); } catch (e) {}
  udp = null;
  server = null;
  startServer();
  startUdp();
}

// Called when the app comes back to the front or the phone woke up.
function wakeUp() {
  if (!started) return;
  restartSockets();
  gateway.wake();
  tick();
}

async function tick() {
  if (started && me) {
    const t = Date.now();
    const slept = lastTickAt && t - lastTickAt > BEAT_MS * 3;
    lastTickAt = t;
    if (slept) { restartSockets(); gateway.wake(); }
    else {
      if (!udp) startUdp();
      if (!server) startServer();
    }
  }
  if (udp && me) {
    const targets = new Set(['255.255.255.255', '192.168.43.255']);
    const subs = ['192.168.43'];
    try {
      const ip = await Network.getIpAddressAsync();
      const p = String(ip).split('.');
      if (p.length === 4 && ip !== '0.0.0.0' && ip.indexOf('192.168.49.') !== 0) {
        myIp = ip;
        if (subs.indexOf(p.slice(0, 3).join('.')) < 0) subs.push(p.slice(0, 3).join('.'));
        p[3] = '255';
        targets.add(p.join('.'));
      } else {
        myIp = '';
      }
    } catch (e) { myIp = ''; }
    if (directUp) {
      targets.add('192.168.49.255');
      if (directOwner) targets.add(directOwner);
      subs.push('192.168.49');
    }
    // gateways are looked for on every network the phone is part of (Wi-Fi, hotspot, Wi-Fi Direct)
    const subKey = subs.join(',');
    if (subKey !== lastSubKey) { lastSubKey = subKey; gateway.networkChanged(subs); }
    targets.forEach((a) => sendUdp(hello(0), a));
    // direct hello to everyone we know: works even when broadcasts are filtered
    Object.values(contacts).forEach((c) => { if (c.ip && !c.gw) sendUdp(hello(0), c.ip); });
    autoRetry();
    carryForward();
  }
  publish();
}

function touchContact(id, name, ip, username, pk) {
  const old = contacts[id];
  const wasOffline = !old || Date.now() - old.lastSeen > ONLINE_MS;
  contacts[id] = { id, name: name || (old && old.name) || 'Unknown', username: username || (old && old.username) || '', ip: ip || (old && old.ip), lastSeen: Date.now(), typingAt: old && old.typingAt, pk: (old && old.pk) || pk || '' };
  if (!old || old.ip !== contacts[id].ip || old.name !== contacts[id].name || old.pk !== contacts[id].pk) save();
  publish();
  if (wasOffline) retryFailed(id);
}

function startServer() {
  try {
    const srv = TcpSocket.createServer((socket) => {
      let buf = '';
      socket.on('data', (data) => {
        buf += data.toString('utf8');
        if (buf.length > 4000000) { try { socket.destroy(); } catch (e) {} return; }
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i);
          buf = buf.slice(i + 1);
          handleLine(line, socket);
        }
      });
      socket.on('error', () => {});
    });
    server = srv;
    srv.on('error', () => { if (server === srv) { try { srv.close(); } catch (e) {} server = null; } });
    srv.on('close', () => { if (server === srv) server = null; });
    srv.listen({ port: TCP_PORT, host: '0.0.0.0', reuseAddress: true });
  } catch (e) {}
}

// ---- Gateways (see gateway.js): they appear as contacts flagged gw:true
function touchGateway(g) {
  const old = contacts[g.id];
  const next = { id: g.id, name: g.name || 'Gateway', username: 'gateway', ip: g.ip, lastSeen: Date.now(), typingAt: old && old.typingAt, pk: g.pk, gw: true };
  contacts[g.id] = next;
  const wasOffline = !old || Date.now() - old.lastSeen > ONLINE_MS;
  if (!old || old.ip !== next.ip || old.name !== next.name || old.pk !== next.pk) save();
  publish();
  if (wasOffline) retryFailed(g.id);
}

function handleGatewayMessage(g, d) {
  if (!d || d.t !== 'msg' || !d.id) return;
  const text = String(d.text || '');
  const isNew = !(messages[g.id] || []).some((m) => m.id === d.id);
  addMessage(g.id, { id: d.id, kind: 'text', mine: false, text, ts: d.ts || Date.now(), read: viewing(g.id) });
  gateway.sendEncrypted(g.id, { t: 'ack', ref: d.id });
  if (isNew) incoming(g.id, text, d.id);
}

async function deliverGateway(peerId, msg) {
  if (msg.kind !== 'text') { setStatus(peerId, msg.id, 'failed'); return; }
  const ok = await gateway.sendEncrypted(peerId, { t: 'msg', id: msg.id, text: msg.text, ts: msg.ts }, 6000);
  setStatus(peerId, msg.id, ok ? 'delivered' : 'failed');
}

export const gatewayScan = () => gateway.scan();
export const gatewayAdd = (ip, port) => gateway.addManual(ip, port);
export const gatewayRemove = (id) => { gateway.remove(id); delete contacts[id]; delete messages[id]; save(); publish(); };
export const gatewaySubscribe = gateway.subscribe;
export const gatewaySnapshot = gateway.getSnapshot;

function handleLine(line, socket) {
  let d;
  try { d = JSON.parse(line); } catch (e) { return; }
  // Private: only accept anything addressed to this device.
  if (!d || d.to !== me.id || !d.from) return;
  const ip = cleanIp(socket.remoteAddress);
  if (d.t === 'msg' && d.id) {
    touchContact(d.from, d.fromName, ip, d.fromUsername);
    const isNew = !(messages[d.from] || []).some((m) => m.id === d.id);
    addMessage(d.from, { id: d.id, kind: 'text', mine: false, text: String(d.text || ''), ts: d.ts || Date.now(), read: viewing(d.from) });
    ack(socket, d.id);
    if (isNew) incoming(d.from, String(d.text || ''), d.id);
  } else if (d.t === 'emsg' && d.id && d.n && d.c && d.c.length < 4000000) {
    receiveEncrypted(d, socket, ip);
  } else if (d.t === 'carry' && d.env) {
    if (acceptCarry(d.env)) ack(socket, d.env.id);
  } else if (d.t === 'read' && Array.isArray(d.ids)) {
    const set = new Set(d.ids);
    messages[d.from] = (messages[d.from] || []).map((m) => (m.mine && set.has(m.id) ? { ...m, status: 'read' } : m));
    save();
    publish();
  } else if (d.t === 'voice' && d.id && d.data && d.data.length < 3000000) {
    touchContact(d.from, d.fromName, ip, d.fromUsername);
    receiveVoice(d, socket);
  } else if (typeof d.t === 'string' && d.t.indexOf('call-') === 0) {
    touchContact(d.from, d.fromName, ip, d.fromUsername);
    if (signalHandler) { try { signalHandler(d); } catch (e) {} }
  }
}

function ack(socket, id) {
  try { socket.write(JSON.stringify({ t: 'ack', id }) + '\n'); } catch (e) {}
}

async function receiveVoice(d, socket) {
  try {
    if (!(messages[d.from] || []).some((m) => m.id === d.id)) {
      const dest = FileSystem.documentDirectory + 'vn_' + d.id + '.m4a';
      await FileSystem.writeAsStringAsync(dest, d.data, { encoding: FileSystem.EncodingType.Base64 });
      addMessage(d.from, { id: d.id, kind: 'voice', mine: false, uri: dest, dur: d.dur || 0, ts: d.ts || Date.now(), read: viewing(d.from) });
      incoming(d.from, '🎤 Voice note', d.id);
    }
    ack(socket, d.id);
  } catch (e) {}
}

const viewing = (id) => activePeer === id && AppState.currentState === 'active';

function incoming(peerId, text, msgId) {
  if (viewing(peerId)) { if (msgId) sendSignal(peerId, { t: 'read', ids: [msgId] }); return; }
  const c = contacts[peerId];
  native.notifyMessage(c ? c.name : 'LocalNet', text, peerId);
}

function addMessage(peerId, msg) {
  const list = messages[peerId] || [];
  if (list.some((m) => m.id === msg.id)) return;
  messages[peerId] = [...list, msg];
  save();
  publish();
}

function setStatus(peerId, msgId, status) {
  messages[peerId] = (messages[peerId] || []).map((m) => (m.id === msgId && !(m.status === 'read' && status === 'delivered') ? { ...m, status, failedAt: status === 'failed' ? Date.now() : m.failedAt } : m));
  save();
  publish();
}

function patchMessage(peerId, msgId, patch) {
  messages[peerId] = (messages[peerId] || []).map((m) => (m.id === msgId ? { ...m, ...patch } : m));
  save();
  publish();
}

// A contact we only know from a relayed message (no address yet)
function ensureContact(id, name, username, pk) {
  const old = contacts[id];
  if (!old) {
    contacts[id] = { id, name: name || 'Unknown', username: username || '', ip: '', lastSeen: 0, pk: pk || '' };
  } else if (!old.pk && pk) {
    contacts[id] = { ...old, pk };
  } else {
    return;
  }
  save();
  publish();
}

// Builds what goes on the wire. Messages are encrypted when the other phone has a public key.
async function buildPayload(peerId, msg) {
  const c = contacts[peerId];
  const base = { id: msg.id, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId, ts: msg.ts };
  const secure = !!(c && c.pk && crypto.ready());
  if (msg.kind === 'voice') {
    const data = await FileSystem.readAsStringAsync(msg.uri, { encoding: FileSystem.EncodingType.Base64 });
    if (secure) {
      try {
        const e = crypto.encryptTo(c.pk, crypto.bytesFromB64(data));
        return { ...base, t: 'emsg', k: 'voice', dur: msg.dur, fpk: crypto.myPublicKey(), n: e.n, c: e.c };
      } catch (err) { /* send without encryption */ }
    }
    return { ...base, t: 'voice', dur: msg.dur, data };
  }
  if (secure) {
    try {
      const e = crypto.encryptTo(c.pk, crypto.utf8(JSON.stringify({ text: msg.text })));
      return { ...base, t: 'emsg', k: 'text', fpk: crypto.myPublicKey(), n: e.n, c: e.c };
    } catch (err) { /* send without encryption */ }
  }
  return { ...base, t: 'msg', text: msg.text };
}

async function receiveEncrypted(d, socket, ip) {
  try {
    if (d.via) ensureContact(d.from, d.fromName, d.fromUsername, d.fpk);
    else touchContact(d.from, d.fromName, ip, d.fromUsername, d.fpk);
    const known = contacts[d.from];
    const pk = (known && known.pk) || d.fpk;
    if (!(messages[d.from] || []).some((m) => m.id === d.id)) {
      const bytes = pk ? crypto.decryptFrom(pk, d.n, d.c) : null;
      if (!bytes) { ack(socket, d.id); return; }
      if (d.k === 'voice') {
        const dest = FileSystem.documentDirectory + 'vn_' + d.id + '.m4a';
        await FileSystem.writeAsStringAsync(dest, crypto.b64FromBytes(bytes), { encoding: FileSystem.EncodingType.Base64 });
        addMessage(d.from, { id: d.id, kind: 'voice', mine: false, uri: dest, dur: d.dur || 0, ts: d.ts || Date.now(), read: viewing(d.from) });
        incoming(d.from, '🎤 Voice note', d.id);
      } else {
        const body = JSON.parse(crypto.text(bytes));
        const text = String((body && body.text) || '');
        addMessage(d.from, { id: d.id, kind: 'text', mine: false, text, ts: d.ts || Date.now(), read: viewing(d.from) });
        incoming(d.from, text, d.id);
      }
    }
    ack(socket, d.id);
  } catch (e) { /* ignore */ }
}

// One short TCP exchange that waits for an "ack"
function tcpSend(ip, payload, timeoutMs, cb) {
  let done = false;
  let client = null;
  const finish = (ok) => {
    if (done) return;
    done = true;
    try { client && client.destroy(); } catch (e) {}
    cb(ok);
  };
  try {
    client = TcpSocket.createConnection({ host: ip, port: TCP_PORT }, () => {
      client.write(JSON.stringify(payload) + '\n');
    });
    let buf = '';
    client.on('data', (x) => { buf += x.toString('utf8'); if (buf.indexOf('"ack"') >= 0) finish(true); });
    client.on('error', () => finish(false));
    client.on('close', () => finish(false));
    setTimeout(() => finish(false), timeoutMs);
  } catch (e) { finish(false); }
}

function carrySave() {
  AsyncStorage.setItem('ln_carry', JSON.stringify(carry.map((x) => ({ env: x.env, at: x.at })))).catch(() => {});
}

// Relay: this phone keeps an encrypted message for another phone and hands it over when they meet.
// The content cannot be read here, only the sender and receiver ids are visible.
function acceptCarry(env) {
  if (!env || env.t !== 'emsg' || !env.id || !env.to || env.to === me.id) return false;
  if (carry.some((x) => x.env.id === env.id)) return true;
  if (!env.c || env.c.length > 2500000) return false;
  let bytes = carry.reduce((n, x) => n + (x.env.c ? x.env.c.length : 0), 0);
  while (carry.length >= CARRY_MAX || bytes + env.c.length > CARRY_BYTES) {
    const old = carry.shift();
    if (!old) break;
    bytes -= old.env.c ? old.env.c.length : 0;
  }
  carry.push({ env, at: Date.now() });
  carrySave();
  publish();
  return true;
}

function carryForward() {
  const now = Date.now();
  const before = carry.length;
  carry = carry.filter((x) => now - x.at < CARRY_TTL);
  if (carry.length !== before) carrySave();
  carry.forEach((x) => {
    if (x.busy) return;
    const c = contacts[x.env.to];
    if (!c || !c.ip || now - c.lastSeen > ONLINE_MS) return;
    x.busy = true;
    tcpSend(c.ip, { ...x.env, via: true }, 30000, (ok) => {
      x.busy = false;
      if (ok) {
        carry = carry.filter((y) => y !== x);
        carrySave();
        publish();
      }
    });
  });
}

// Origin side: when the receiver is not reachable, ask up to two nearby phones to carry the message.
async function handoff(peerId, msg) {
  const carriers = Object.values(contacts)
    .filter((x) => x.id !== peerId && x.ip && Date.now() - x.lastSeen <= ONLINE_MS)
    .slice(0, 2);
  if (!carriers.length) return;
  patchMessage(peerId, msg.id, { carrying: true, carryTries: (msg.carryTries || 0) + 1 });
  let env = null;
  try { env = await buildPayload(peerId, msg); } catch (e) { env = null; }
  if (!env || env.t !== 'emsg') {
    patchMessage(peerId, msg.id, { carrying: false, carryTries: 9 });
    return;
  }
  let ok = 0;
  let left = carriers.length;
  carriers.forEach((x) => {
    tcpSend(x.ip, { t: 'carry', from: me.id, to: x.id, env }, 30000, (r) => {
      if (r) ok += 1;
      left -= 1;
      if (left === 0) patchMessage(peerId, msg.id, { carrying: false, carried: ok > 0 });
    });
  });
}

async function deliver(peerId, msg) {
  const c = contacts[peerId];
  if (!c || !c.ip) { setStatus(peerId, msg.id, 'failed'); return; }
  if (c.gw) { deliverGateway(peerId, msg); return; }
  let payload;
  try {
    payload = await buildPayload(peerId, msg);
  } catch (e) { setStatus(peerId, msg.id, 'failed'); return; }
  let done = false;
  let client = null;
  const finish = (st) => {
    if (done) return;
    done = true;
    setStatus(peerId, msg.id, st);
    try { client && client.destroy(); } catch (e) {}
  };
  try {
    client = TcpSocket.createConnection({ host: c.ip, port: TCP_PORT }, () => {
      client.write(JSON.stringify(payload) + '\n');
    });
    let buf = '';
    client.on('data', (x) => { buf += x.toString('utf8'); if (buf.indexOf('"ack"') >= 0) finish('delivered'); });
    client.on('error', () => finish('failed'));
    client.on('close', () => finish('failed'));
    setTimeout(() => finish('failed'), msg.kind === 'voice' ? 25000 : 6000);
  } catch (e) { finish('failed'); }
}

export function sendSignal(peerId, obj) {
  const c = contacts[peerId];
  if (!c || !c.ip || !me || c.gw) return;
  let client = null;
  try {
    client = TcpSocket.createConnection({ host: c.ip, port: TCP_PORT }, () => {
      client.write(JSON.stringify({ ...obj, from: me.id, fromName: me.name, fromUsername: me.username, to: peerId }) + '\n');
      setTimeout(() => { try { client.destroy(); } catch (e) {} }, 1500);
    });
    client.on('error', () => {});
  } catch (e) {}
}

export function sendMessage(peerId, text) {
  const t = String(text || '').trim();
  if (!t || !contacts[peerId]) return;
  const msg = { id: genId(), kind: 'text', mine: true, text: t, ts: Date.now(), status: 'sending' };
  addMessage(peerId, msg);
  deliver(peerId, msg);
}

export async function sendVoice(peerId, uri, dur) {
  if (!contacts[peerId]) return;
  let dest = uri;
  try {
    dest = FileSystem.documentDirectory + 'vn_' + genId() + '.m4a';
    await FileSystem.copyAsync({ from: uri, to: dest });
  } catch (e) { dest = uri; }
  const msg = { id: genId(), kind: 'voice', mine: true, uri: dest, dur, ts: Date.now(), status: 'sending' };
  addMessage(peerId, msg);
  deliver(peerId, msg);
}

export function retry(peerId, msgId, auto) {
  const m = (messages[peerId] || []).find((x) => x.id === msgId);
  if (!m || m.kind === 'call' || m.status === 'sending' || m.status === 'delivered' || m.status === 'read') return;
  messages[peerId] = (messages[peerId] || []).map((x) => (x.id === msgId ? { ...x, tries: auto ? (x.tries || 0) + 1 : 0 } : x));
  setStatus(peerId, msgId, 'sending');
  deliver(peerId, m);
}

function autoRetry() {
  const now = Date.now();
  Object.values(contacts).forEach((c) => {
    const online = now - c.lastSeen <= ONLINE_MS;
    (messages[c.id] || []).forEach((m) => {
      if (!m.mine || m.kind === 'call' || m.status !== 'failed') return;
      if (online) {
        if ((m.tries || 0) < 5 && now - (m.failedAt || 0) > 8000) retry(c.id, m.id, true);
      } else if (!c.gw && !m.carried && !m.carrying && (m.carryTries || 0) < 3 && c.pk && now - (m.failedAt || 0) > 3000) {
        handoff(c.id, m);
      }
    });
  });
}

function retryFailed(peerId) {
  (messages[peerId] || []).filter((m) => m.mine && m.status === 'failed').forEach((m) => retry(peerId, m.id));
}

export function setActive(id) {
  activePeer = id;
  markViewed();
}

function markViewed() {
  const id = activePeer;
  if (!id || AppState.currentState !== 'active' || !messages[id]) return;
  const unread = messages[id].filter((m) => !m.mine && !m.read && m.kind !== 'call');
  if (!unread.length) { native.dismissMessages(id); return; }
  const ids = unread.map((m) => m.id);
  messages[id] = messages[id].map((m) => (m.mine || m.kind === 'call' ? m : { ...m, read: true }));
  save();
  publish();
  if (ids.length) sendSignal(id, { t: 'read', ids });
  native.dismissMessages(id);
}

export function sendTyping(peerId) {
  const c = contacts[peerId];
  if (!c || !c.ip || c.gw || !udp || !me || Date.now() - lastTyping < 2500) return;
  lastTyping = Date.now();
  sendUdp(JSON.stringify({ t: 'typing', id: me.id }), c.ip);
}

export async function updateName(name) {
  const n = String(name || '').trim();
  if (!n || !me) return;
  me = { ...me, name: n };
  try { await AsyncStorage.setItem('ln_account', JSON.stringify(me)); } catch (e) {}
  publish();
  tick();
}

export function deleteMessage(peerId, msgId) {
  messages[peerId] = (messages[peerId] || []).filter((m) => m.id !== msgId);
  save();
  publish();
}

export function clearChat(peerId) {
  messages[peerId] = [];
  save();
  publish();
}

export const isDirect = () => directUp;
export const carryCount = () => carry.length;

export function markCallsRead() {
  let changed = false;
  Object.keys(messages).forEach((id) => {
    if ((messages[id] || []).some((m) => m.kind === 'call' && !m.mine && !m.read)) {
      messages[id] = messages[id].map((m) => (m.kind === 'call' ? { ...m, read: true } : m));
      changed = true;
    }
  });
  if (changed) {
    save();
    publish();
  }
}

export const onlineCount = () => Object.values(contacts).filter((c) => Date.now() - c.lastSeen < ONLINE_MS).length;

export function setDirectGroup(g) {
  directUp = !!(g && g.formed);
  directOwner = (g && g.owner) || '';
  publish();
}
