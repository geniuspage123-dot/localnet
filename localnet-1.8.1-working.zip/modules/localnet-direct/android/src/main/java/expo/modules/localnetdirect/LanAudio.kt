package expo.modules.localnetdirect

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketTimeoutException

// Plain voice over UDP between two phones on the same local network (used for Direct Wi-Fi calls,
// where the normal WebRTC engine cannot use the Wi-Fi Direct network).
// 16 kHz, 16-bit, mono, 20 ms per packet.
object LanAudio {
  private const val RATE = 16000
  private const val FRAME_SAMPLES = 320
  private const val FRAME_BYTES = FRAME_SAMPLES * 2

  @Volatile private var running = false
  @Volatile private var muted = false
  @Volatile private var lastRx = 0L
  @Volatile private var tx = 0
  @Volatile private var rx = 0

  private var socket: DatagramSocket? = null
  private var record: AudioRecord? = null
  private var track: AudioTrack? = null
  private var sendThread: Thread? = null
  private var recvThread: Thread? = null

  fun setMuted(m: Boolean) {
    muted = m
  }

  fun rxAgeMs(): Int {
    if (!running) return -1
    val age = System.currentTimeMillis() - lastRx
    return if (age > 1000000L) 1000000 else age.toInt()
  }

  fun stats(): String = "" + tx + ":" + rx

  @Synchronized
  fun start(peerIp: String, port: Int): Boolean {
    stop()
    try {
      val s = DatagramSocket(null)
      s.reuseAddress = true
      s.bind(InetSocketAddress(port))
      s.soTimeout = 500
      val remote = InetSocketAddress(InetAddress.getByName(peerIp), port)

      val minIn = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val rec = AudioRecord(
        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
        RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT,
        maxOf(minIn, FRAME_BYTES * 4)
      )
      if (rec.state != AudioRecord.STATE_INITIALIZED) {
        rec.release()
        s.close()
        return false
      }
      try {
        if (AcousticEchoCanceler.isAvailable()) {
          AcousticEchoCanceler.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }
      try {
        if (NoiseSuppressor.isAvailable()) {
          NoiseSuppressor.create(rec.audioSessionId)?.setEnabled(true)
        }
      } catch (e: Exception) { }

      val minOut = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
      val trk = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setSampleRate(RATE)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(maxOf(minOut, FRAME_BYTES * 6))
        .setTransferMode(AudioTrack.MODE_STREAM)
        .build()

      socket = s
      record = rec
      track = trk
      muted = false
      tx = 0
      rx = 0
      lastRx = System.currentTimeMillis()
      running = true
      rec.startRecording()
      trk.play()

      val sender = Thread {
        val shorts = ShortArray(FRAME_SAMPLES)
        val bytes = ByteArray(FRAME_BYTES)
        while (running) {
          val n = rec.read(shorts, 0, FRAME_SAMPLES)
          if (n <= 0) {
            try { Thread.sleep(5) } catch (e: InterruptedException) { }
            continue
          }
          var i = 0
          while (i < n) {
            val v = if (muted) 0 else shorts[i].toInt()
            bytes[i * 2] = (v and 0xFF).toByte()
            bytes[i * 2 + 1] = ((v shr 8) and 0xFF).toByte()
            i++
          }
          try {
            s.send(DatagramPacket(bytes, n * 2, remote))
            tx++
          } catch (e: Exception) { }
        }
      }

      val receiver = Thread {
        val buf = ByteArray(2048)
        val shorts = ShortArray(1024)
        val pkt = DatagramPacket(buf, buf.size)
        while (running) {
          try {
            pkt.length = buf.size
            s.receive(pkt)
            if (pkt.address != null && pkt.address.hostAddress != peerIp) continue
            val ns = pkt.length / 2
            if (ns > 0) {
              var i = 0
              while (i < ns) {
                shorts[i] = ((buf[i * 2].toInt() and 0xFF) or (buf[i * 2 + 1].toInt() shl 8)).toShort()
                i++
              }
              trk.write(shorts, 0, ns)
              rx++
              lastRx = System.currentTimeMillis()
            }
          } catch (e: SocketTimeoutException) {
            // no packet in the last 500 ms
          } catch (e: Exception) {
            if (!running) break
          }
        }
      }
      sender.start()
      receiver.start()
      sendThread = sender
      recvThread = receiver
      return true
    } catch (e: Exception) {
      stop()
      return false
    }
  }

  @Synchronized
  fun stop() {
    running = false
    try { socket?.close() } catch (e: Exception) { }
    try { record?.stop() } catch (e: Exception) { }
    try { sendThread?.join(300) } catch (e: Exception) { }
    try { recvThread?.join(300) } catch (e: Exception) { }
    try { record?.release() } catch (e: Exception) { }
    try { track?.stop() } catch (e: Exception) { }
    try { track?.release() } catch (e: Exception) { }
    socket = null
    record = null
    track = null
    sendThread = null
    recvThread = null
  }
}
